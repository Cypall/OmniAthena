<?php
require 'memory.php';
if (!$POST_action && !$GET_action) {
	require 'header.inc';
	echo"
			<font size='1' color='#F9F2E8'>p</font><table align='center' cellpadding='0' cellspacing='0' width='600' bgcolor='#F7EBDB' bordercolordark='black' bordercolorlight='black' style='border-collapse:collapse;'>
			<tr>
				<td bgcolor='#F5E3CC' style='margin:2px; border-top-width:1px; border-right-width:1px; border-left-width:1px; border-top-color:black; border-right-color:black; border-left-color:black; border-top-style:solid; border-right-style:solid; border-left-style:solid;'>
					<center><font size='1'><b>Please login to the Control Panel</b></font></center>
				</td>
			</tr>
			<tr>
				<td style='border-right-width:1px; border-bottom-width:1px; border-left-width:1px; border-right-color:black; border-bottom-color:black; border-left-color:black; border-right-style:solid; border-bottom-style:solid; border-left-style:solid;'>
					<form action=\"login.php\" method=\"POST\">
					<font size='1' color='#F9F2E8'>p</font><table align=\"center\" border=\"0\">
					<tr>
						<td class=\"mytext\">User:</td>
						<td><input type=\"text\" class=\"myctl\" name=\"user\"></td>
					</tr>
					<tr>
						<td class=\"mytext\">Password:</td>
						<td><input type=\"password\" class=\"myctl\" name=\"pass\"></td>
					</tr>
					<table align=\"center\" border=\"0\">
						<tr>
							<td colspan=2>
								<center><input type=submit class=\"myctl\" value=\"login\"></center>
							</td>
							<input type=\"hidden\" name=\"action\" value=\"login\">
						</tr>
						<tr>
							<td class=\"mytext\"><a href=\"register.php\"><img src='images/register.gif'></a></td>
							<td class=\"mytext\">&nbsp;&nbsp;<a href=\"lost_pass.php\"><img src='images/lost.gif'></a></td>
						</tr>
					</table>
					</form>
				</td>
			</tr>
		";
	
}
elseif ($POST_action == "login") {
	$access_level = authenticate($POST_user, md5($POST_pass));
	if ($access_level > 0) {
		if ($save_type == 1) {
			setcookie("login", $_POST['user'], time()+60*60*24*30);
			setcookie("password", md5($_POST['pass']), time()+60*60*24*30);
			setcookie("level", md5($access_level . $passphrase), time()+60*60*24*30);
		}
		else {
			$_SESSION['login'] = $_POST['user'];
			$_SESSION['password'] = md5($_POST['pass']);
			$_SESSION['level'] = $access_level;
		}
		require 'header.inc';
		if ($access_level > 1) {
			// Adds to the login log
			add_access_entry("Logged in as $POST_user", 2);
		}
		redir("index.php", "You are now logged in");
		exit();
	}
	else {
		require 'header.inc';
		redir("index.php", "The login you entered is incorrect");
	}
}
elseif ($GET_action == "logout") {
	if ($save_type == 1) {
		setcookie("login");
		setcookie("password");
		setcookie("level");
	}
	else {
		session_unset();
	}
	require 'header.inc';
	redir("login.php","You are now logged out");
}
require 'footer.inc';
?>
