<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
// Checks if action has been performed
if (!$GET_edit && !$GET_del && $POST_finish == "") {
	if ($STORED_level > 1) {
		// Displays User announcement options
		EchoHead(80);
		echo "
	<tr class=myheader>
		<td colspan=5>User Announcements</td>
	</tr>
	<tr class=myheader>
		<td>Options</td>
		<td>Post ID</td>
		<td>Date</td>
		<td>Message</td>
		<td>Poster</td>
	</tr>
	    	";
		$query = "SELECT * FROM user_announce";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			$post_id = $line[0];
			echo "
	<tr class=mycell>
		<td>
			<a href=\"edit_announcement.php?type=1&edit=$post_id\">Edit</a>
			-
			<a href=\"edit_announcement.php?type=1&del=$post_id\">Delete</a>
		</td>
	    		";
			foreach ($line as $col_value) {
				echo "
	    	<td>
	    		$col_value 
	    	</td>
	    			";
			}
			echo "
	   	</tr>
	    		";
		}
		echo "
	</table>
	    	";
		// Displays GM announcement options
		EchoHead(80);
		echo "
	<tr class=myheader>
		<td colspan=5>GM Announcements</td>
	</tr>
	<tr class=myheader>
		<td>Options</td>
		<td>Post ID</td>
		<td>Date</td>
		<td>Message</td>
		<td>Poster</td>
	</tr>
	    	";
		$query = "SELECT * FROM gm_announce";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			$post_id = $line[0];
			echo "
	<tr class=mycell>
	    	<td>
	    		<a href=\"edit_announcement.php?type=2&edit=$post_id\">Edit</a>
	    		-
	    		<a href=\"edit_announcement.php?type=2&del=$post_id\">Delete</a>
	    	</td>
	    		";
			foreach ($line as $col_value) {
				echo "
	    	<td>
	    		$col_value 
	    	</td>
	    			";
			}
			echo "
	   	</tr>
	    		";
		}
		echo "
	</table>
	    	";
	}
	if ($STORED_level == 3) {
		// Displays Admin announcement options
		EchoHead(80);
		echo "
	<tr class=myheader>
		<td colspan=5>Admin Announcements</td>
	</tr>
	<tr class=myheader>
		<td>Options</td>
		<td>Post ID</td>
		<td>Date</td>
		<td>Message</td>
		<td>Poster</td>
	</tr>
	    	";
		$query = "SELECT * FROM admin_announce";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			$post_id = $line[0];
			echo "
	<tr class=mycell>
		<td>
		<a href=\"edit_announcement.php?type=3&edit=$post_id\">Edit</a>
		-
		<a href=\"edit_announcement.php?type=3&del=$post_id\">Delete</a>
		</td>
	    		";
			foreach ($line as $col_value) {
				echo "
	<td>
		$col_value 
	</td>
	    			";
			}
			echo "
	</tr>
	    		";
		}
		echo "
</table>
	    	";
	}
}
else {
	switch ($GET_type) {
		case 1:
		$table = "user_announce";
		break;
		case 2:
		$table = "gm_announce";
		break;
		case 3:
		$table = "admin_announce";
		break;
	}
	if ($STORED_level == 2 && $GET_type == 3) {
		// GM trying to edit admin message
		redir("index.php", "You are trying to edit the wrong message type!");
	}
	if ($POST_finish == "Save Changes") {
		$query = "UPDATE $POST_table
    		SET date = '$POST_date',
    		message = '$POST_message',
    		poster = '$POST_poster'
    		WHERE post_id = '$POST_post_id'";
		$result = execute_query($query);
		add_admin_entry("Edited an Announcement");
		redir("index.php", "Announcement Edited!");
	}
	if ($GET_edit != "") {
		echo "<p>
<table class=\"mytable\" border=1 width=800 cellspacing=0>
	<tr class=myheader>
		<td colspan=5>Edit Announcement</td>
	</tr>
	<tr class=myheader>
		<td>Options</td>
		<td>Post ID</td>
		<td>Date</td>
		<td>Message</td>
		<td>Poster</td>
	</tr>
	    	";
		$query = "SELECT * FROM $table WHERE post_id = $GET_edit";
		$result = execute_query($query);
		$line = mysql_fetch_row($result);
		$post_id = $line[0];
		$date = $line[1];
		$message = $line[2];
		$poster = $line[3];
		echo "
	<tr>
	<form action=\"edit_announcement.php\" method=\"POST\">
		<input type =\"hidden\" name=\"post_id\" class=\"myctl\" value=\"$post_id\">
		<input type=\"hidden\" name=\"table\" class=\"myctl\" value=\"$table\">
		<td>
			<input type=\"submit\" name=\"finish\" class=\"myctl\" value=\"Save Changes\">
		</td>
		<td>
			$post_id
		</td>
		<td>
			<input type=\"text\" name=\"date\" class=\"myctl\" value=\"$date\">
		</td>
		<td>
			<textarea rows=10 cols=80 name=\"message\" class=\"myctl\">$message</textarea>
		</td>
		<td>
			<input type=\"text\" name=\"poster\" class=\"myctl\" value=\"$poster\">
		</td>
	</form>
	</tr>
</table>
    		";
		
	}
	if ($GET_del != "") {
		$query = "DELETE FROM $table WHERE post_id = $GET_del";
		$result = execute_query($query);
		if (mysql_affected_rows($result) > 0) {
			add_admin_entry("Deleted an announcement");
			redir("index.php", "Announcement successfully deleted!");
		}
		else {
			redir("index.php", "Announcement could not be deleted!");
		}
	}
}
require 'footer.inc';
?>