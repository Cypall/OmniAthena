<?php

function getmicrotime() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}

function validate_string($string) {
	global $validchars;
	$valid = true;
	for ($i = 0; $i < strlen($string); $i++) {
		if (strpos($validchars, strtolower(substr($string, $i, 1))) === false){
			$valid = false;
		}
	}
	return $valid;
}
function execute_query($input_query, $page_source = 'none.php', $skip_debug = false) {
	global $debug_message, $queries, $link, $execute_query, $log_select, $log_update, $log_delete,
	$log_query, $debug, $passphrase;
	
	$start_time = getmicrotime();
	$analyze_query = strtolower($input_query); // analyzes the query for illegal inputs
	// disables the use of UNION SELECT
	if (strstr($analyze_query, 'union') == true) {
		add_exploit_entry("Attempted to inject a UNION SELECT into a query");
		redir("index.php", "Invalid query to be executed");
		exit();
	}
	if ($execute_query) {
		$result = mysql_query($input_query, $link) or die("Query ($input_query) failed : " . mysql_error());
		$queries++;
	}
	$log_query = false;
	
	// Logs the query if debug is not skipped.
	if (!$skip_debug) {
		// Logs each query (SELECT, UPDATE, DELETE)
		if (strstr($analyze_query, 'select') != false && $log_select) {
			$debug_message .= "Logging: ";
			$log_query = true;
		}
		elseif (strstr($analyze_query, 'update') != false && $log_update) {
			$debug_message .= "Logging: ";
			$log_query = true;
		}
		elseif (strstr($analyze_query, 'delete') != false && $log_delete) {
			$debug_message .= "Logging: ";
			$log_query = true;
		}
		else {
			$debug_message .= "Executing: ";
			$log_query = false;
		}
	}
	$execute_time = (getmicrotime() - $start_time);
	if ($debug && !$skip_debug) {
		$debug_message .= "($page_source) ";
		$debug_message .= "$input_query Execution Time: $execute_time seconds.<br>";
	}
	
	if ($log_query && !$skip_debug) {
		// sticks the logs in another directory, where users are less likely
		// to find it.
		$prefix = md5($passphrase);
		$log_entry = convert_full_date(time());
		$log = fopen("{$prefix}queries.txt", "a");
		$message = "{$_SERVER['REMOTE_ADDR']} ($log_entry): $input_query \r\n";
		fwrite($log, $message);
		fclose($log);
	}
	return $result;
}

function is_server_online() {
	//Server Check
	$fp1 = @fsockopen ($accip, $accport, $errno, $errstr, 2);
	$fp2 = @fsockopen ($charip, $charport, $errno, $errstr, 2);
	$fp3 = @fsockopen ($mapip, $mapport, $errno, $errstr, 2);
	if (!$fp1 or !$fp2 or !$fp3) {
		return false;
	}
	else {
		return true;
	}
	fclose($fp1);
	fclose($fp2);
	fclose($fp3);
}

function is_ignored($account_id) {
	$query = "SELECT account_id FROM `ladder_ignore` WHERE account_id = '$account_id'";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return true;
	}
	else {
		return false;
	}
}

function is_banned($account_id) {
	$query = "SELECT account_id FROM `login` WHERE account_id = '$account_id' AND level = '-1'";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return true;
	}
	else {
		return false;
	}
}

function is_gm($account_id) {
	$query = "SELECT account_id FROM `gm` WHERE account_id = '$account_id'";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return true;
	}
	else {
		return false;
	}
}

function is_admin($account_id) {
	$query = "SELECT account_id FROM `admin` WHERE account_id = '$account_id'";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return true;
	}
	else {
		return false;
	}
}

// Determines if character is a GM
function is_a_gm($input_character_name) {
	$input_character_name = addslashes($input_character_name);
	$query = "SELECT name FROM `char` WHERE name = '$input_character_name'";    //searches for name of that char #
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return false;
	}
	else {
		$query = "SELECT login.userid FROM `char`, `login` WHERE login.account_id = char.account_id
        AND char.name = '$input_character_name'";    //searches for name of that char #
		$result = execute_query($query, 'functions.php');
		while ($line = mysql_fetch_array($result)) {
			foreach ($line as $col_value) {
				$account_id = UserID_To_AccountID($col_value);
				if ($account_id == 0) {
					return false;
				}
				if (is_gm($account_id) == true) {
					return true;
				}
				if (is_admin($account_id) == true) {
					return true;
				}
				return false;
			}
		}
	}
}

function isalphanumeric($test) {
	return !(preg_match("/[^a-z,A-Z,0-9 ]/", $test));
}

function authenticate ($login_username, $login_password) {
	/* Returns the following privileges:
	0: Fail
	1: User
	2: GM
	3: Admin
	*/
	global $use_md5;
	$ip = $_SERVER['REMOTE_ADDR'];
	if ($cp_protect && $login_username == 'CP' && $ip != '127.0.0.1') {
		add_access_log('Tried to login as CP/CP. Login was rejected!', 2);
		return 0;
	}
	if ($login_username == 's1' or $login_username == 's2' or $login_username == 's3' or $login_username == 's4' or $login_username == 's5') {
		return 0;
	}
	$query = "SELECT * FROM `login` WHERE userid = '$login_username'";
	$result = execute_query($query, 'functions.php', false);
	if (mysql_num_rows($result) == 0) {
		return 0;
	}
	else {
		while ($line = mysql_fetch_array($result)) {
			if ($use_md5) {
				if ($line['user_pass'] != $login_password) {
					return 0;
				}
			}
			else {
				
				if (md5($line['user_pass']) != $login_password) {
					return 0;
				}
			}
			$account_id = $line['account_id'];
			$account_name = AccountID_To_UserID($account_id);
			// Checks user privilege
			if (is_admin($account_id)) {
				return 3;
			}
			elseif (is_gm($account_id)) {
				return 2;
			}
			else {
				return 1;
			}
		}
	}
}

function privilege_string($access_level) {
	switch($access_level) {
		case 1:
			return "Normal";
		case 2:
			return "GM";
		case 3:
			return "Admin";
	}
}

function determine_class ($class_index) {
	if ($class_index > 4000) {
		$class = explode("\r\n",file_get_contents("class_advanced.def"));
		return $class[$class_index - 4001];
	}
	else {
		$class = explode("\r\n",file_get_contents("class.def"));
		return $class[$class_index];
	}
}

function determine_castle ($castle_index) {
	$castle_name = explode("\r\n",file_get_contents("guild_castles.def"));
	return $castle_name[$castle_index];
}

// The following functions are for logging purposes

function add_access_entry($log_action, $type) {
	// Different arguements
	// 1: Went to a page that they weren't allowed to be.
	// 2: Logged in as a GM/Admin
	global $STORED_login;
	$log_entry = time();
	switch ($type) {
		case 1:
		$log_source = $STORED_login;
		break;
		case 2;
		$log_source = $_SERVER['REMOTE_ADDR'];
		break;
	}
	$query = "INSERT into `access_log` (`Date`, `User/IP`, `Action`) VALUES('$log_entry', '$log_source', '$log_action');";
	$result = execute_query($query, 'functions.php');
}

function add_admin_entry($log_action) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	$query = "INSERT into `admin_log` (`Date`, `User`, `Action`) VALUES('$log_entry', '$log_account', '$log_action');";
	$result = execute_query($query, 'functions.php');
}

function add_ban_entry($banned_account, $log_reason) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	$log_reason = "Banned: " . $log_reason;
	$query = "INSERT into `ban_log` (Date, set_account_id, ban_account_id, reason) VALUES('$log_entry', '$log_account', '$banned_account', '$log_reason');";
	$result = execute_query($query, 'functions.php');
}

function add_exploit_entry($log_action) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	if ($log_account == "") {
		$log_account = $_SERVER['REMOTE_ADDR'];
	}
	$query = "INSERT into `exploit_log` (`Date`, `User/IP`, `Action`) VALUES('$log_entry', '$log_account', '$log_action');";
	$result = execute_query($query, 'functions.php');
}

function add_money_entry($from, $to, $log_action) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	$query = "INSERT into `money_log` (`Date`, `From`, `To`, `Action`) VALUES('$log_entry', '$from', '$to', '$log_action');";
	$result = execute_query($query, 'functions.php');
}

function add_unban_entry($unbanned_account, $log_reason) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	$log_reason = "Unbanned: " . $log_reason;
	$query = "INSERT into `ban_log` (Date, set_account_id, ban_account_id, reason) VALUES('$log_entry', '$log_account', '$unbanned_account', '$log_reason');";
	$result = execute_query($query, 'functions.php');
}


function add_user_entry($log_action) {
	global $STORED_login;
	$log_entry = time();
	$log_account = $STORED_login;
	$query = "INSERT into `user_log` (Date, User, Action) VALUES('$log_entry', '$log_account', '$log_action');";
	$result = execute_query($query, 'functions.php');;
}

// End logging functions

function GetUserCount() {
	// returns the number of users online
	$query = "SELECT * FROM `sstatus`";
	$result = execute_query($query, 'functions.php', false);
	if (mysql_num_rows($result) > 0) {
		$row = mysql_fetch_array($result);
		return $row['user'];
	}
	else {
		return 0;
	}
}

function GetAccountCount() {
	// returns the number of accounts that are not for the server
	$query = "SELECT * FROM `login` WHERE sex <> 'S'";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return mysql_num_rows($result);
	}
	else {
		return 0;
	}
}

function GetCharacterCount() {
	// returns the number of characters on server
	$query = "SELECT * FROM `char`";
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) > 0) {
		return mysql_num_rows($result);
	}
	else {
		return 0;
	}
}

function is_online ($input_account_id) {
	// returns whether or not account is online
	$result = mysql_query("SELECT * FROM `char` WHERE online = '1' AND account_id = '$input_account_id'");
	if (mysql_num_rows($result) > 0) {
		return true;
	}
	else {
		return false;
	}
	
}



function GetGuildCount() {
	// returns the number of users online
	$result = mysql_query("SELECT * FROM `guild`");
	if (mysql_num_rows($result) > 0) {
		return mysql_num_rows($result);
	}
	else {
		return 0;
	}
}

function ItemName_To_ItemID ($input_item_name) {
	global $athena_db;
	// Converts Item Name to Item #
	if ($athena_db['item_db']) {
		$query = "SELECT ID, Name FROM `item_db` WHERE Name = '$input_item_name'";	//searches if item name is in DB
	}
	else {
		$query = "SELECT ItemID, ItemName FROM `athenaitem` WHERE ItemName = '$input_item_name'";	//searches if item name is in DB
	}
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return 0;
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['ItemID'];
	}
}

function ItemID_To_ItemName ($input_item_ID) {
	// Converts Item # to Item Name
	$query = "SELECT ItemID, ItemName FROM `athenaitem` WHERE ItemID = '$input_item_ID'";	//searches if item ID is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		if ($input_item_ID == 0 or $input_item_ID == 2 or $input_item_ID == 255) {
			return "";
		}
		elseif ($input_item_ID > 1280) {
			return "";
		}
		else {
			return "Unknown Item $input_item_ID";
		}
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['ItemName'];
	}
}

function CharName_To_CharID ($input_char_name) {
	// Converts Char Name to Char ID
	$input_char_name = addslashes($input_char_name);
	$query = "SELECT char_id, name FROM `char` WHERE name = '$input_char_name'";	//searches if character name is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return 0;
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['char_id'];
	}
}

function CharID_To_CharName ($input_char_id) {
	// Converts Char ID to Char Name
	$query = "SELECT char_id, name FROM `char` WHERE char_id = '$input_char_id'";	//searches if character ID is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return "";
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['name'];
	}
}

function AccountID_To_UserID($input_account_id) {
	// Converts Account ID to Account Name
	$query = "SELECT account_id, userid FROM `login` WHERE account_id = '$input_account_id'";	//searches if item is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return "";
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['userid'];
	}
}

function UserID_To_AccountID($input_user_id) {
	// Converts Account Name to Account ID
	$input_user_id = addslashes($input_user_id);
	$query = "SELECT account_id, userid FROM `login` WHERE userid = '$input_user_id'";	//searches if item is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return 0;
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['account_id'];
	}
}

function GuildID_To_GuildName($input_guild_id) {
	// Converts Account ID to Account Name
	$query = "SELECT * FROM `guild` WHERE guild_id = '$input_guild_id'";    //searches if item is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return "";
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['name'];
	}
}

function GuildName_To_GuildID($input_guild_name) {
	// Converts Account Name to Account ID
	$input_guild_name = addslashes($input_guild_name);
	$query = "SELECT * FROM `guild` WHERE name = '$input_guild_name'";    //searches if item is in DB
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return 0;
	}
	else {
		$line = mysql_fetch_array($result);
		return $line['guild_id'];
	}
}

function CharCount($input_account_id) {
	$query = "SELECT account_id FROM `char`
    WHERE account_id = '$input_account_id'
    ";  // checks how many characters on that account
	$result = execute_query($query, 'functions.php');
	return mysql_num_rows($result);
}

function characters_on_account ($input_account_id, $char_slot) {
	$query = "SELECT * FROM `login`
    WHERE account_id = '$input_account_id'
    ";  //searches for name of that char #
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return "";
	}
	else {
		// Selects the character names from the char table
		$query = "SELECT char_id FROM `char`
        WHERE char_num = '$char_slot'
        AND account_id = '$input_account_id'
        ";	//searches for name of that char #
		$result = execute_query($query, 'functions.php');
		if (mysql_num_rows($result) > 0) {
			$line = mysql_fetch_array($result);
			return $line['char_id'];
		}
		else {
			return "";
		}
	}
}

function account_of_character ($input_character_name) {
	// character name, returns account name
	$input_character_name = addslashes($input_character_name);
	$query = "SELECT name FROM `char` WHERE name = '$input_character_name'";	//searches for name of that char #
	$result = execute_query($query, 'functions.php');
	if (mysql_num_rows($result) == 0) {
		return "";
	}
	else {
		$query = "SELECT login.userid FROM `char`, `login` WHERE login.account_id = char.account_id
    	AND char.name = '$input_character_name'";	//searches for name of that char #
		$result = execute_query($query, 'functions.php');
		$line = mysql_fetch_array($result);
		return $line['userid'];
	}
}

function display_character_data ($input_character_id) {
	// displays the information about the characters in an account
	$query = "SELECT name, class, base_level, job_level, zeny FROM `char` WHERE char_id = '$input_character_id'";	// checks if item exists
	$result = execute_query($query, 'functions.php');
	/* Printing results in HTML */
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>\n";
		foreach ($line as $col_value) {
			{
				if ($line[1] == $col_value) {
					$col_value = determine_class($col_value);
					echo "<td>$col_value</td>\n";
				}
				elseif ($line[0] == $col_value) {
					echo "<td><a href='char_manage.php?search=$col_value'>$col_value</a></td>\n";
				}
				else {
					echo "<td>$col_value</td>\n";
				}
			}
		}
		echo "</tr>\n";
	}
}

function clear_character($character_id) {
	// input char #, clears everything associated with character
	// Following Sections clean the database of any trace of the account.
	// Looking at the queries, you can see that it's very thorough, and that the only
	// way to reverse this process is to restore a backup of the database.
	
	$query = "DELETE FROM `cart_inventory` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Cart Items Deleted!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `inventory` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Inventory Deleted!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `memo` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Memos Deleted!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `pet` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Pets Deleted!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `skill` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Skills Deleted!";
		echo "<br>\n";
	}
	// Guild/Party Clearing
	
	// Start Guild Clear
	// Check if that character is guild master
	$query = "SELECT * FROM `guild` WHERE master = '$delete_char'";
	$result = execute_query($query);
	$line = mysql_fetch_array($result);
	if (mysql_num_rows($result) > 0) {
		// Deleted Character Owns A Guild
		// First, Determine Guild ID that he/she owns
		$delete_guild_id = $line['guild_id'];
		// Get all members in the guild
		$query = "SELECT char_id FROM `guild_member` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		// Go through each member of that guild, set their guild_id to 0
		while ($line = mysql_fetch_array($result)) {
			$guild_member_id = $line['char_id'];
			$query = "UPDATE `char` SET guild_id = '0' WHERE char_id = '$guild_member_id'";
			$result = execute_query($query);
		}
		// Delete all data associated with that guild.
		$query = "DELETE FROM `guild` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Guild Deleted!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_alliance` WHERE guild_id = '$delete_guild_id'
            OR alliance_id = '$guild_id_to_delete'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Alliances Cleared!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_castle` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Castles Cleared!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_expulsion` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Expel List Cleared!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_member` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Member List Cleared!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_position` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Position List Cleared!";
			echo "<br>\n";
		}
		$query = "DELETE FROM `guild_skill` WHERE guild_id = '$delete_guild_id'";
		$result = execute_query($query);
		if (mysql_affected_rows() > 0) {
			echo "Guild Skills Cleared!";
			echo "<br>\n";
		}
	}
	else {
		// Deleted Account Does not own a Guild
		// See if character is in a guild
		$query = "SELECT * FROM `guild_member` WHERE char_id = '$delete_char_id'";
		$result = execute_query($query);
		if (mysql_num_rows($result) > 0) {
			// Character is in guild
			// Set that character's guild id to 0
			$query = "UPDATE `char` SET guild_id = '0' WHERE char_id = '$delete_char_id'";
			$result = execute_query($query);
			// Delete all guild data associated with that player.
			$query = "DELETE FROM `guild_member` WHERE char_id = '$delete_char_id'";
			if (mysql_affected_rows() > 0) {
				echo "Member Removed from Guild!";
				echo "<br>\n";
			}
		}
	}
	// End Guild clearing
	
	// Start Party Clear
	
	// Check if character is party master
	$query = "SELECT * FROM `party` WHERE leader_id = '$delete_char_id'";
	$result = execute_query($query);
	$line = mysql_fetch_array($result);
	if (mysql_num_rows($result) > 0) {
		// Deleted char owns a party
		// Determine party ID that they own
		$delete_party_id = $line['party_id'];
		
		// Go through each member of that party, set their party to 0
		$party_member_id = $line['char_id'];
		$query = "UPDATE `char` SET party_id = '0' WHERE char_id = '$party_member_id'
		AND party_id = '$delete_party_id'";
		$result = execute_query($query);
		// Delete party
		$query = "DELETE FROM `party` WHERE party_id = '$delete_party_id'";
		$result = execute_query($query);
	}
	else {
		// Deleted Account Does not own a party
		// See if character is in a party
		$query = "SELECT * FROM `char` WHERE char_id = '$delete_char_id' AND party_id > 0";
		$result = execute_query($query);
		if (mysql_num_rows($result) > 0) {
			// Character is in party
			// Set that character's party id to 0
			$query = "UPDATE `char` SET party_id = '0' WHERE char_id = '$delete_char_id'";
			$result = execute_query($query);   echo "<br>\n";
		}
	}
	// End Party clearing
	
	// Delete the character
	$query = "DELETE FROM `char` WHERE char_id = '$delete_char_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Character Deleted!";
		echo "<br>\n";
	}
	add_admin_entry("Deleted Character $GET_delete", "");
}

function clear_account($account_id) {
	// input account #, clears everything associated with account
	
	for ($i = 0; $i < 6; $i++) {
		// goes though each character on the account
		$delete_char_id = characters_on_account($account_id, $i);    // Obtains the characters on that account
		$delete_char = CharID_To_CharName($delete_char_id);    // Obtains the # of the char to clear
		if ($delete_char_id > 0) {
			// If Character is not ""
			echo "Deleting Information related to Character " . $delete_char;
			echo "<br>";
			clear_character($delete_char_id);
		}
	}
	$query = "DELETE FROM `storage` WHERE account_id = '$account_id'";
	$result = execute_query($query, 'functions.php');
	if (mysql_affected_rows() > 0) {
		echo "Storage Deleted!";
		echo "<br>\n";
	}
	// Final step of the cleaning process, delete the account
	$query = "DELETE FROM `login` WHERE account_id = '$account_id'";
	$result = execute_query($query, 'functions.php');
	if (mysql_affected_rows() > 0) {
		echo "Account Deleted!";
		echo "<br>\n";
	}
	echo "<p>";
}

// Following functions go into the `[table]_announce` table, and obtain the proper message, and return it

function get_announcement($table, $read_index, $input_command) {
	global $max_announce;
	$query = "SELECT $input_command FROM `$table` ORDER by post_id DESC LIMIT $max_announce";
	//$result = execute_query($query, 'functions.php');
	$result = execute_query($query, 'functions.php');
	while ($line = mysql_fetch_array($result)) {
		$index++;
		if ($index == $read_index) {
			if ($input_command == "date") {
				return convert_date(stripslashes($line[$input_command]));
			}
			else {
				return stripslashes($line[$input_command]);
			}
		}
	}
	
}

function convert_date($input_number) {
        return date("M j @ g:ia", $input_number);
}

function convert_full_date($input_number) {
        return date("M j @ g:i:s", $input_number);
}
// End Message Functions

// Ban/Unban Functions

function display_ban ($account_name) {		
	// displays the ban confirmation
	$query = "SELECT * FROM `login`
		WHERE userid = '$account_name'
		";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Account $account_name doesn't exist!";
	}
	else {
		$query = "SELECT * FROM `login`
	        WHERE userid = '$account_name'
	        AND level = 1 or level = 0
	        ";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Account is already banned!";
		}
		else {
			echo "You are going to ban $account_name. Please list a reason below.<br>\n
	    		Note: Actions will be logged, so a good reason would be useful.<br>\n
	    		<form action=\"ban.php\" method=\"POST\">
	    		Reason: <input type=\"text\" class=\"myctl\" name=\"reason\" size=50><p>\n
	    		There will be no confirmation screen, be absolutely sure that you are going to ban.<p>\n
	    		<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Ban This Account!\"><br>\n
	            	<input type=\"hidden\" class=\"myctl\" name=\"account_name\" value=\"$account_name\">
	    		</form>";
		}
	}
}

function display_unban ($account_name) {	
	// displays the unban confirmation
	$query = "SELECT * FROM `login`
	    WHERE userid = '$account_name'
	    ";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Account $account_name doesn't exist!";
	}
	else {
		$query = "SELECT * FROM `login`
	        WHERE userid = '$account_name'
	        AND level = -1
	        ";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Account not banned!";
		}
		else {
			echo "
			You are going to unban $account_name. Please list a reason below.<br>\n
			Note: Actions will be logged, so a good reason would be useful<br>\n
			<form action=\"unban.php\" method=\"POST\">
			Reason: <input type=\"text\" class=\"myctl\" name=\"reason\" size=50><p>\n
			There will be no confirmation screen, be absolutely sure that you are going to ban.<p>\n
			<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Unban This Account!\"><br>\n
			<input type=\"hidden\" class=\"myctl\" name=\"account_name\" value=\"$account_name\">
			</form>
			";
		}
	}
}

// End Ban/Unban Functions

// Guild Functions

function ShowGuildInfo($guild_id) {
	$guild_name = GuildID_To_GuildName($guild_id);
	// Looks at Alliances/Antagonists
	$query = "SELECT opposition, name FROM `guild_alliance` WHERE guild_id = '$guild_id'";
	$result = execute_query($query);
	echo "	
<br>
<table class=\"mytable\" border=1 width=\"800\" cellspacing=0 cellpadding=0 align=\"center\">
	<tr class=mytitle>
		<td colspan=5>Guild Information for: $guild_name</td>
	</tr>
	<tr class=mytitle>
		<td colspan=5>Alliances/Enemies</td>
	</tr>
	<tr class=myheader>
		<td colspan=3>Status</td>
		<td colspan=2>Guild</td>
	</tr>
            ";
	if (mysql_num_rows($result) > 0) {
		while ($line = mysql_fetch_row($result)) {
			echo "<tr>";
			$current_row = 0;
			foreach ($line as $col_value) {
				$current_row++;
				if ($current_row == 1) {
					if ($col_value == '0') {
						$col_value = "Alliance";
					}
					else {
						$col_value = "Enemy";
					}
				}
				echo "<td>$col_value</td>";
			}
			echo "</tr>";
		}
	}
	else {
		echo "
	<tr class=mycell>
		<td colspan=5>None</td>
	</tr>
		";
	}
	// Looks at Member List
	$query = "SELECT name, class, lv, exp, position
        FROM `guild_member` WHERE guild_id = '$guild_id'";
	$result = execute_query($query);
	echo "
	<tr>
			<tr class=mytitle>
				<td colspan=5>Guild Members</td>
			</tr>
			<tr class=myheader>    
				<td>Member Name</td>
				<td>Class</td>
				<td>Level</td>
				<td>EXP Donated</td>
				<td>Position</td>
			</tr>
        ";
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>\n";
		$current_row = 0;
		foreach ($line as $col_value) {
			$current_row++;
			if ($current_row == 2) {
				$col_value = determine_class($col_value);
			}
			elseif ($current_row == 5) {
				$col_value = GetGuildPosition($guild_id, $col_value);
			}
			echo "<td>$col_value</td>";
		}
		echo "</tr>";
	}
	echo "	
	</tr>
</table>
	";
}

function GetGuildPosition($guild_id, $position_id) {
	$query = "SELECT position, name FROM `guild_position`
	WHERE guild_id = '$guild_id'
	AND position = '$position_id'";
	$result = execute_query($query);
	$line = mysql_fetch_row($result);
	return $line[1];
}

// End Guild Functions
?>