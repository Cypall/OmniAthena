<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
$query = "SELECT * FROM `ipbanlist`";
$result = execute_query($query);
EchoHead(80);
echo "
	<tr class=mytitle>
		<td colspan=5>Table ipbanlist</td>
	</tr>
	<tr class=myheader>
		<td>IP</td>
		<td>Ban Time</td>
		<td>Unban Time</td>
		<td>Reason</td>
	</tr>
        ";
if (mysql_num_rows($result) == 0) {
	echo "
	<tr class=mycell>
		<td colspan=5>None</td>
	</tr>
</table>
	";
}
else {
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr class=mycell>\n";
		foreach ($line as $col_value) {
			echo "<td>$col_value</td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
}

$query = "SELECT userid FROM `login` WHERE level = '-1'";
$result = execute_query($query);
EchoHead();
echo "
	<tr class=mytitle>
		<td>Ban List for $server_name</td>
	</tr>

	<tr class=myheader>
		<td>Ban ID</td>
	</tr>

";
if (mysql_num_rows($result) == 0) {
	echo "
	<tr class=mycell>
		<td colspan=5>None</td>
	</tr>
	";
}
else {
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr class=mycell>\n";
		foreach ($line as $col_value) {
			echo "<td><a href=\"account_manage.php?search=$col_value\">$col_value</a></td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
}
require 'footer.inc';
?>