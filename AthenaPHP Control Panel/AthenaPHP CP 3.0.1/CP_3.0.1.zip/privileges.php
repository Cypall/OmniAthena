<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

EchoHead(40);
echo "
	<tr class=mytitle>
		<td colspan=3 class=myheader>Current Page Privileges</td>
	</tr>
	<tr class=myheader>
		<td>Page</td>
		<td>Access Level</td>
	</tr>
";
foreach ($access as $index => $data) {
	switch ($data) {
		case 1:
		$display_string = "Normal Users";
		$display_link = "";
		break;
		case 2:
		$display_string = "GM";
		$display_link = "gm_privilege.php";
		break;
		case 3:
		$display_string = "Admin";
		$display_link = "admin_privilege.php";
		break;
	}
	echo "
	<tr class=mycell>
		<td><a href=\"$index\">$index</a></td>
		<td><a href=\"$display_link\">$display_string</a></td>
	</tr>
	";
}
echo "</table>";
require 'footer.inc';
?>