<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
// Credits to Nucleo
// Selects all users, besides GMs, and selects thier last login time
$query = "SELECT account_id, lastlogin, logincount FROM `login`";
//    WHERE logincount > '0'";
$result = execute_query($query);
EchoHead(80);
echo "
<tr class=mytitle>
	<td colspan=4>Last Logins of Each Account</td>
</tr>
<tr class=myheader>
	<td>Account</td>
	<td>Last Login</td>
	<td>Login Count</td>
	<td>Delete?</td>
</tr>
";

if (mysql_num_rows($result) == 0) {
	echo "
<tr>
	<td colspan=4>None</td>
</tr>
	";
}

while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$list_account = $line['account_id'];
	$list_account_name = AccountID_To_UserID($list_account);
	$last_login = $line['lastlogin'];
	$login_count = intval($line['logincount']);
	$last_date = substr($line['lastlogin'], 0, 10);
	$last_date = $line['lastlogin'];
	$difference = strtotime("now") - strtotime($last_date);
	// Time duration to display
	$days = floor($difference / 86400);
	$hours = floor(($difference - ($days * 86400)) / 3600);
	$minutes = floor(($difference - ($days * 86400) - ($hours * 3600)) / 60);
	$seconds = floor(($difference - ($days * 86400) - ($hours * 3600) - ($minutes * 60)));
	if ($last_date == 0) {
		// Displays 0's if the account has never been logged in.
		$days = 0;
		$hours = 0;
		$minutes = 0;
		$seconds = 0;
	}
	if ($days >= $inactive_days) {
		$bold_tag = "<b>";
		$bold_close = "</b>";
	}
	else {
		$bold_tag = "";
		$bold_close = "";
	}
	echo "
<tr class=mycell>
	<td>$bold_tag<a href=\"account_manage.php?account=$list_account\">$list_account_name$bold_tag</td>
	<td>$bold_tag$days day(s), $hours hour(s), $minutes minute(s), $seconds second(s)$bold_tag</td>
	<td>$bold_tag$login_count$bold_tag</td>
	<td>$bold_tag<a href=\"account_manage.php?deleteaccount=$list_account\">Delete</a>$bold_tag</td>
</tr>
	";
}
echo "</table>";

$query = "SELECT account_id, char_id, name FROM `char` WHERE name REGEXP '[$banned_characters]'
ORDER BY char_id";
$result = execute_query($query);
EchoHead(80);
echo "
<tr class=mytitle>
	<td colspan=4>Illegal ASCII Character Names (No $banned_characters)</td>
</tr>
<tr class=myheader>
	<td>Account</td>
	<td>Character Name</td>
	<td>Delete?</td>
</tr>
";
if (mysql_num_rows($result) == 0) {
	echo "
<tr class=mycell>
	<td colspan=4>None</td>
</tr>
	";
}
while ($line = mysql_fetch_row($result)) {
	echo "<tr class=mycell>";
	$list_char = $line[1];
	foreach ($line as $display_index => $col_value) {
		if ($display_index == 0) {
			$col_value = AccountID_To_UserID($col_value);
		}
		elseif ($display_index == 1) {
			continue;
		}
		echo "<td><xmp>$col_value</xmp></td>";
	}
	echo "<td><a href=\"char_manage.php?option=deletechar&char_id=$list_char\">Delete</a></td>";
	echo "</tr>";
}
require 'footer.inc';
?>