<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
$query = "SELECT * FROM `ladder_ignore` ORDER BY account_id";
$result = execute_query($query);
if ($GET_remove > 0) {
	$query = "DELETE FROM `ladder_ignore` WHERE account_id = $GET_remove";
	$result = execute_query($query);
	redir("ladder_ignore.php", "Removed account $GET_remove from ladder ignore!");
	exit();
}
if (mysql_num_rows($result) == 0) {
	echo "No accounts are ignored from ladder!";
}
else {
	EchoHead(80);
	echo "
	<tr class=mytitle>
		<td colspan=3>Ignored From Ladder</td>
	</tr>
	<tr class=myheader>
		<td>Account ID</td>
		<td>Account Name</td>
		<td>Remove</td>
	</tr>
        ";
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>\n";
		foreach ($line as $col_value) {
			echo "<td>$col_value</td>\n";
			$col_value = AccountID_To_UserID($col_value);
			$display = "<a href=\"account_manage.php?search=" . $col_value . "\">$col_value</a>";
			echo "<td>$display</td>\n";
			echo "<td><a href=\"ladder_ignore.php?remove={$line[0]}\">Remove</a></td>";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
}
require 'footer.inc';
?>