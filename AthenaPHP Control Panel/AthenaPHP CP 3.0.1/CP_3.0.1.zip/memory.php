<?php
// This is the function that calls on all the actions to be executed on each action
include_once 'config.php'; // loads config variables

// Makes sure that a passphrase has been set.
if (!$passphrase) {
	echo "
	<br>
	<br>
	<table border=1 bgcolor=#F9F2E8 width=\"400\" height=\"75\" cellpadding=0 cellspacing=0 align=center>
		<tr>
		</tr>
		<tr align=\"center\">
			<td class=mytext>
				<b>A Passphrase has not been set in config.php! You must set one up before
				you can use this script.</b>
			</td>
		</tr>
		<tr>
			<td></td>
		</tr>
	</table>";
	exit();
}

// Connects to database
$link = mysql_connect($db_host, $db_username, $db_password);
mysql_select_db($db_name, $link);
include_once 'functions.php'; // declares functions

// Checks PHP Versions
$current = phpversion();
if (substr($current, 0, 1) < 4) {
	die("You are currently running PHP Version $current. The Control Panel is only compatible with versions 4 and above. Please download the new version at <a href=\"http://www.php.net\">http://www.php.net</a>");
}

// Sets up config of the PHP host
ini_set('SMTP', $smtp_host);
ini_set('sendmail_from', $sendmail_from);
ini_set('register_globals', 'Off');

error_reporting(E_ALL ^ E_NOTICE); // General Use
//error_reporting(E_ALL);	// Debugging
//error_reporting('NONE');	// None

if ($save_type == 2) {
	ini_set('session.use_cookies' , 0);
	ini_set('session.use_trans_sid' , 1);
	ini_set('session.name' , 'sessid');
	ini_set('magic_quotes_gbc', 'On');
	ini_set('magic_quotes_runtime', 'On');
	session_start();
	$session_id = session_id();
}
include_once 'extract.inc';

// Stores some global variables
$account_id = UserID_To_AccountID($STORED_login);
$privilege = privilege_string($STORED_level);

function logged_in () {
	// Determines if user is logged in, redirects to start if not
	global $save_type, $STORED_login;
	$logged_in = c_logged_in();
	if ($logged_in == 0)	{
		// not logged in, sends them to start
		if ($save_type == 1) {
			setcookie("login");
			setcookie("password");
			setcookie("level");
		}
		else {
			session_unset();
		}
		redir("login.php","You must be logged in to access this page");
		exit();
	}
	else {
		// verifies the access level
		$valid_cookie = valid_access_level($STORED_login); // checks that level is correct
		if ($valid_cookie == 0) {
			redir("login.php", "Your cookie settings are not valid. Please re-log again.");
			if ($save_type == 1) {
				setcookie("login");
				setcookie("password");
				setcookie("level");
			}
			else {
				session_unset();
			}
			exit();
		}
	}
}

function c_logged_in() {
	global $STORED_login, $STORED_password, $use_md5, $passphrase;
	
	// No cookie exists.
	if ($STORED_login == "") {
		return 0;
	}
	else {
		// Determines if user/password matches
		$query = "SELECT user_pass FROM login WHERE userid = '$STORED_login'";
		$result = execute_query($query, 'memory.php', true);
		if (mysql_num_rows($result) > 0) {
			$line = mysql_fetch_array($result);
			if ($use_md5) {
				$compare_pass = $line['user_pass'];
			}
			else {
				$compare_pass = md5($line['user_pass']);
			}
			if ($compare_pass == $STORED_password) {
				$logged_in = 1;
			}
			else {
				$logged_in = 0;
			}
		}
		else {
			$logged_in = 0;
		}
	}
	return $logged_in;
}

function check_auth ($input_string) {
	global $access, $STORED_login, $STORED_level;
	$position = strrpos($input_string, '/');
	$page_string = substr($input_string, $position + 1);
	if ($access[$page_string] == 0) {
		redir("index.php", "Access Controls for this page has not been set.");
		exit();
	}
	else {
		if ($STORED_level < $access[$page_string]) {
			add_user_entry("Tried to access $input_string", 1);
			redir("index.php", "Access Denied for " . $STORED_login);
			exit();
		}
	}
}

function valid_access_level($account_name) {
	// makes sure that access level has not been tampered with
	global $STORED_login, $STORED_password, $STORED_level, $passphrase, $privilege;
	$access_level = authenticate($STORED_login, $STORED_password);
	if ($access_level != $STORED_level) {
		return false;
	}
	return true;
}

function redir($page,$msg,$time=5) {
	if ($page == 'index.php') {
		$page = 'home.php';
	}
        echo "
	<head><meta http-equiv=\"refresh\" content='$time;url=$page'></head>
	<br>
	<table bgcolor='#F7EBDB' width='250' cellpadding=0 cellspacing=0 align=center style='border-collapse:collapse;'>
		<tr>
			<td style='border-top-width:1px; border-right-width:1px; border-left-width:1px; border-top-color:rgb(231,214,192); border-right-color:rgb(231,214,192); border-left-color:rgb(231,214,192); border-top-style:dashed; border-right-style:dashed; border-left-style:dashed;'>&nbsp;</td>
		</tr>
		<tr align=\'center\'>
			<td class=mytext style='border-right-width:1px; border-left-width:1px; border-right-color:rgb(231,214,192); border-left-color:rgb(231,214,192); border-right-style:dashed; border-left-style:dashed;'>
			<p align='center'><b><font face='Verdana'><span style='font-size:8pt;'>$msg</span></font></b><font face='Verdana'><span style='font-size:8pt;'><br>To continue, please </span></font><a href='$page'><font face='Verdana'><span style='font-size:8pt;'>click here</span></font></a><font face='Verdana'><span style='font-size:8pt;'><br></span></font>
			</td>
		</tr>
		<tr>
			<td style='border-right-width:1px; border-bottom-width:1px; border-left-width:1px; border-right-color:rgb(231,214,192); border-bottom-color:rgb(231,214,192); border-left-color:rgb(231,214,192); border-right-style:dashed; border-bottom-style:dashed; border-left-style:dashed;'>&nbsp;</td>
		</tr>
	</table>
        ";
}

function EchoHead($width = "") {
	echo "
	<p>
	<table width='$width%' class=mytable cellspacing=0 cellpadding=0 align='center' style='border-collapse:collapse;'>
	";
}

function EchoFoot() {
	echo "
	<tr>
		<td colspan=10><br>
		</td>
	</tr>
	</table>
	";
}
?>