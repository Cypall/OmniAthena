<?php
require 'config.php';
if ($frames == true) {
	echo "
<FRAMESET cols=\"50, 200\">
	<FRAME src=\"menu.php\">
	<FRAME name=\"home\" src=\"home.php\">
</FRAMESET>
	";
}
else {
	require 'home.php';
}
?>
