<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

EchoHead(50);
echo "
	<tr class=mytitle>
		<td>Current Tables for Viewing</td>
	</tr>
	<tr class=myheader>
		<td>You can view the following tables for more information:</td>
	</tr>
";
// Checks which SQL DBs are enabled
foreach($athena_db as $db_index => $enabled) {
	if ($enabled) {
		echo "
	<tr class=mycell>
		<td>
			<a href=\"view_db.php?view=$db_index\">$db_index</a>
		</td>
	</tr>
		";
	}
}
echo "
</table>
";

if ($GET_view != "") {
	// Checks that the database is allowed to be viewed
	if ($athena_db[$GET_view]) {
		if (!$GET_ID) {
			display_athena_table($GET_view);
		}
		else {
			if ($GET_view == "mob_db") {
				display_monster_table($GET_ID);
			}
			elseif ($GET_view == "item_db") {
				display_item_table($GET_ID);
			}
		}
	}
	else {
		// Does not allow user to view tables that they do not have access to
		redir("view_db.php", "You cannot view this table!");
		exit();
	}
}

function display_athena_table($display_table) {
	global $exp_rate, $jexp_rate;
	// Disable time limit
	set_time_limit(0);
	// First, show the table header
	EchoHead(100);
	$query = "SHOW FIELDS FROM `$display_table`";
	$result = execute_query($query, "view_db.php");
	$columns = mysql_num_rows($result);
	
	
	// Display Table for mob_db
	if ($display_table == "mob_db") {
		echo "
		<tr class=mytitle>
			<td colspan=$columns>Viewing: $display_table ({$exp_rate}x EXP/{$jexp_rate}x JEXP Rates)</td>
		</tr>
		";
		echo "
		<tr class=myheader>
			<td>Name</td>
			<td>Level</td>
			<td>HP</td>
			<td>EXP</td>
			<td>JEXP</td>
			<td>ATK1</td>
			<td>ATK2</td>
			<td>DEF</td>
			<td>Size</td>
		</tr>
		";
		
		$query = "SELECT ID, Name, LV, HP, EXP, JEXP, ATK1, ATK2, DEF, Scale
		FROM `mob_db` ORDER BY ID";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			echo "<tr class=mycell>";
			foreach ($line as $display_index => $col_value) {
				if ($display_index == 1) {
					$col_value = "<a href=\"view_db.php?view=mob_db&ID={$line[0]}\">$col_value</a>";
				}
				elseif ($display_index == 4) {
					$col_value *= $exp_rate;
				}
				elseif ($display_index == 5) {
					$col_value *= $jexp_rate;
				}
				elseif ($display_index == 9) {
					switch ($col_value) {
						case 0:
							$col_value = "S";
							break;
						case 1:
							$col_value = "M";
							break;
						case 2:
							$col_value = "L";
							break;
					}
				}
				if ($display_index > 0) {
					echo "<td>$col_value</td>";
				}
			}
			echo "</tr>";
		}
	}
	// Display Table for item_db
	elseif ($display_table == "item_db") {
		echo "
		<tr class=mytitle>
			<td colspan=$columns>Viewing: $display_table</td>
		</tr>
		";
		echo "
		<tr class=myheader>
			<td>Name</td>
			<td>Price</td>
			<td>Weight</td>
			<td>ATK</td>
			<td>DEF</td>
			<td>Slots</td>
		</tr>
		";
		
		$query = "SELECT ID, Name, Price, Weight, ATK, DEF, Slot
		FROM `item_db` ORDER BY ID";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			echo "<tr class=mycell>";
			foreach ($line as $display_index => $col_value) {
				if ($display_index == 1) {
					$col_value = "<a href=\"view_db.php?view=item_db&ID={$line[0]}\">$col_value</a>";
				}
				if ($display_index > 0) {
					echo "<td>$col_value</td>";
				}
			}
			echo "</tr>";
		}
	}
	else {
		echo "
		<tr class=mytitle>
			<td colspan=$columns>Viewing: $display_table</td>
		</tr>
		";
		// Display Table if the table is not item_db or mob_db
		echo "
		<tr class=myheader>
		";
		while ($line = mysql_fetch_row($result)) {
			echo "
			<td>{$line[0]}</td>
			";
		}
		echo "
		</tr>
		";
		// Prints off the data
		$query = "SELECT * FROM `$display_table`";
		$result = execute_query($query);
		while ($line = mysql_fetch_row($result)) {
			echo "
			<tr class=mycell>
			";
			foreach($line as $col_value) {
				echo "<td>$col_value</td>";
			}
			echo "
			</tr>
			";
		}
	}
	echo "
	</table>
	";
}

function display_monster_table ($input_monster_id) {
	global $drop_rate;
	// Get Monster Name
	$query = "SELECT Name FROM `mob_db` WHERE ID = $input_monster_id";
	$result = execute_query($query);
	$line = mysql_fetch_row($result);
	$monster_name = $line[0];
	if (!is_numeric($input_monster_id)) {
		return 0;
	}
	EchoHead(100);
	echo "
	<tr class=mytitle>
		<td colspan=16>Drop List Information for $monster_name ({$drop_rate}x Drop Rates, odds listed out of 10000)</td>
	</tr>
	<tr class=myheader>
	";
	for ($i = 1; $i <= 8; $i++) {
		echo "<td>Item $i</td>";
		echo "<td>Item $i Chance</td>";
	}
	echo "
	</tr>
	";
	
	$query = "SELECT Drop1id, Drop1per, Drop2id, Drop2per, Drop3id, Drop3per, Drop4id, Drop4per,
	Drop5id, Drop5per, Drop6id, Drop6per, Drop7id, Drop7per, Drop8id, Drop8per
	FROM `mob_db` WHERE ID = $input_monster_id";
	$result = execute_query($query);
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>";
		foreach ($line as $display_index => $col_value) {
			if ($display_index % 2 == 0) {
				$item_id = $col_value;
				$item_name = ItemID_To_ItemName($col_value);
				$col_value = "<a href=\"view_db.php?view=item_db&ID=$item_id\">$item_name</a>";
			}
			elseif ($display_index % 2 == 1) {
				$col_value *= $drop_rate;
				if ($col_value > 10000) {$col_value = 10000;}
			}
			echo "<td>$col_value</td>";
		}
		echo "</tr>";
	}
	echo "
	</table>
	";
}

function display_item_table ($input_item_id) {
	global $drop_rate;
	// Get Item Name
	$query = "SELECT Name FROM `item_db` WHERE ID = $input_item_id
	";
	$result = execute_query($query);
	$line = mysql_fetch_row($result);
	$item_name = $line[0];
	
	EchoHead(100);
	echo "
	<tr class=mytitle>
		<td colspan=17>Item Drop Information for $item_name ({$drop_rate}x Drop Rates, odds listed out of 10000)</td>
	</tr>
	<tr class=myheader>
		<td>Monster</td>
	";
	for ($i = 1; $i <= 8; $i++) {
		echo "<td>Item $i</td>";
		echo "<td>Item $i Chance</td>";
	}
	echo "
	</tr>
	";
	
	$query = "SELECT ID, Name, Drop1id, Drop1per, Drop2id, Drop2per, Drop3id, Drop3per, Drop4id, Drop4per,
	Drop5id, Drop5per, Drop6id, Drop6per, Drop7id, Drop7per, Drop8id, Drop8per
	FROM `mob_db` 
	WHERE Drop1id = $input_item_id
	OR Drop2id = $input_item_id
	OR Drop3id = $input_item_id
	OR Drop4id = $input_item_id
	OR Drop5id = $input_item_id
	OR Drop6id = $input_item_id
	OR Drop7id = $input_item_id
	OR Drop8id = $input_item_id
	";
	$result = execute_query($query);
	
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>";
		foreach ($line as $display_index => $col_value) {
			if ($col_value == $input_item_id) {
				$highlight_index = ($display_index / 2);
			}
		}
		foreach ($line as $display_index => $col_value) {
			if ($display_index == 1) {
				$col_value = "<a href=\"view_db.php?view=mob_db&ID={$line[0]}\">$col_value</a>";
			}
			if (($display_index - 0) % 2 == 0) {
				$item_id = $col_value;
				$item_name = ItemID_To_ItemName($col_value);
				$col_value = "<a href=\"view_db.php?view=item_db&ID=$item_id\">$item_name</a>";
			}
			elseif (($display_index - 0) % 2 == 1 && $display_index != 1) {
				$col_value *= $drop_rate;
				if ($col_value > 10000) {$col_value = 10000;}
			}
			if ($display_index > 0) {
				if (($display_index == $highlight_index * 2) or ($display_index == $highlight_index * 2 + 1)) {
					echo "<td bgcolor='#F5E0BC'>$col_value</td>";
				}
				else {
					echo "<td>$col_value</td>";
				}
			}
		}
		echo "</tr>";
	}
}

require 'footer.inc';
?>