<?php

function display_item ($item_id) {
	// displays all instances of an item
	$query = "SELECT ItemID FROM `athenaitem` WHERE ItemID = '$item_id'";    // checks if item exists
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Item does not exist.";
	}
	else {
		// Searches for the item in inventory
		$query = "SELECT char_id, amount, nameid, refine, card0, card1, card2, card3 FROM `inventory`
        WHERE nameid = '$item_id'
        OR card0 = '$item_id'
        OR card1 = '$item_id'
        OR card2 = '$item_id'
        OR card3 = '$item_id'
        ";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Nobody has this Item!";
		}
		else {
			/* Printing results in HTML */
			EchoHead(80);
			echo "
	<tr class=myheader>
		<td colspan=7>Items on Server:</td>
	</tr>
	<tr class=myheader>
		<td>Character Name</td>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            ";
			while ($line = mysql_fetch_row($result)) {
				$char_name = CharID_To_CharName($line[0]);
				if (is_a_gm($char_name)) {
					$gm_char = true;
				}
				else {
					$gm_char = false;
				}
				echo "<tr class=mycell>\n";
				$current_row = 0;
				foreach ($line as $col_value) {
					$current_row++;
					if ($current_row == 1) {
						$character = CharID_To_CharName($col_value);
						$col_value = "<a href=item_manage.php?s_action=Search+Character&char=$character>$character</a>";
					}
					elseif ($current_row == 4) {
						$col_value = "";
					}
					elseif ($current_row == 3) {
						$refine_value = $line[3];
						$card0 = $line[5];
						$card1 = $line[6];
						$equip_id = $col_value;
						$display = convert_equip($equip_id, $refine_value, $card0, $card1);
						if ($display == "") {
							$display = "Unknown Item $equip_id";
						}
						$item = ItemID_To_ItemName($equip_id);
						$col_value = "<a href=item_manage.php?item=$item>$display</a>";
					}
					elseif ($current_row == 2) {
					}
					else {
						$item = ItemID_To_ItemName($col_value);
						$col_value = "<a href=item_manage.php?item=$item>$item</a>";
					}
					if ($col_value != "") {
						if ($gm_char) {
							echo "<td><b>$col_value</b></td>\n";
						}
						else {
							echo "<td>$col_value</td>\n";
						}
						
						$col_value = "";
					}
				}
				echo "</tr>\n";
			}
			echo "</table>\n";
		}
	}
	$query = "SELECT ItemID FROM `athenaitem` WHERE ItemID = '$item_id'";    // checks if item exists
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
	}
	else {
		// Searches for the item in storage
		$query = "SELECT account_id, amount, nameid, refine, card0, card1, card2, card3 FROM `storage`
        WHERE nameid = '$item_id'
        OR card0 = '$item_id'
        OR card1 = '$item_id'
        OR card2 = '$item_id'
        OR card3 = '$item_id'
        ";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "<br>Nobody has this Item in Storage!";
		}
		else {
			/* Printing results in HTML */
			EchoHead(100);
			echo "
	<tr class=myheader>
		<td colspan=7>Items on Server:</td>
	</tr>
	<tr class=myheader>
		<td>Account Name</td>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            ";
			while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
				echo "<tr class=myheader>\n";
				foreach ($line as $col_value) {
					if ($line['account_id'] == $col_value) {
						$col_value = AccountID_To_UserID($col_value);
						$col_value = "<a href=\"account_manage.php?search=$col_value\">$col_value</a>";
					}
					elseif ($line['refine'] == $col_value) {
						$col_value = "";
					}
					elseif ($line['nameid'] == $col_value) {
						$refine_value = $line['refine'];
						$card0 = $line['card0'];
						$card1 = $line['card1'];
						$equip_id = $col_value;
						$display = convert_equip($equip_id, $refine_value, $card0, $card1);
						if ($display == "") {
							$display = "Unknown Item $equip_id";
						}
						$item = ItemID_To_ItemName($equip_id);
						$col_value = "<a href=item_manage.php?item=$item>$display</a>";
					}
					elseif ($line['amount'] == $col_value) {
					}
					else {
						$item = ItemID_To_ItemName($col_value);
						$col_value = "<a href=item_manage.php?item=$item>$item</a>";
					}
					if ($col_value != "") {
						echo "<td>$col_value</td>\n";
						$col_value = "";
					}
				}
				echo "</tr>\n";
			}
			echo "</table>\n";
		}
	}
	$query = "SELECT ItemID FROM `athenaitem` WHERE ItemID = '$item_id'";    // checks if item exists
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
	}
	else {
		// Searches for the item in cart
		$query = "SELECT char_id, amount, nameid, refine, card0, card1, card2, card3 FROM `cart_inventory`
        WHERE nameid = '$item_id'
        OR card0 = '$item_id'
        OR card1 = '$item_id'
        OR card2 = '$item_id'
        OR card3 = '$item_id'
        ";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "<br>Nobody has this Item in Cart!";
		}
		else {
			/* Printing results in HTML */
			EchoHead(100);
			echo "
	<tr class=myheader>
		<td colspan=7>Items in Cart:</td>
	</tr>
	<tr class=myheader>
		<td>Account Name</td>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            ";
			while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
				echo "<tr class=mycell>\n";
				foreach ($line as $col_value) {
					if ($line['char_id'] == $col_value) {
						$col_value = CharID_To_CharName($col_value);
					}
					elseif ($line['refine'] == $col_value) {
						$col_value = "";
					}
					elseif ($line['nameid'] == $col_value) {
						$refine_value = $line['refine'];
						$card0 = $line['card0'];
						$card1 = $line['card1'];
						$equip_id = $col_value;
						$display = convert_equip($equip_id, $refine_value, $card0, $card1);
						if ($display == "") {
							$display = "Unknown Item $equip_id";
						}
						$item = ItemID_To_ItemName($equip_id);
						$col_value = "<a href=item_manage.php?item=$item>$display</a>";
					}
					elseif ($line['amount'] == $col_value) {
					}
					else {
						$item = ItemID_To_ItemName($col_value);
						$col_value = "<a href=item_manage.php?item=$item>$item</a>";
					}
					if ($col_value != "") {
						echo "<td>$col_value</td>\n";
						$col_value = "";
					}
				}
				echo "</tr>\n";
			}
			echo "</table>\n";
		}
	}
}

function display_char_items ($char_id) {
	// Takes the char ID, and prints out their inventory and cart
	$query = "SELECT char_id FROM `char` WHERE char_id = '$char_id'";        // checks if character exists
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "No such character.";
	}
	else {
		// Selects the items in character's inventory
		$query = "SELECT amount, nameid, refine, card0, card1, card2, card3 FROM `inventory` WHERE char_id = '$char_id'";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Character has no items.";
		}
		else {
			$char_name = CharID_To_CharName($char_id);
			/* Printing results in HTML */
			EchoHead(100);
			echo "
	<tr class=myheader>
		<td colspan=7>$char_name's Items:</td>
	</tr>
	<tr class=myheader>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            ";
			while ($line = mysql_fetch_row($result)) {
				echo "<tr class=mycell>\n";
				$current_row = 0;
				foreach ($line as $col_value) {
					$current_row++;
					if ($current_row == 3) {
						$col_value = "skip";    // don't print this value, is needed for later purposes
					}
					elseif ($current_row == 2) {
						// converts the item in nameid
						$equip_id = $line[1];    // obtains the equip name
						$refine_value = $line[2];    // obtains the refine level
						$card0 = $line[3];        // obtains card 0
						$card1 = $line[4];        // obtains card 1
						$display = convert_equip($equip_id, $refine_value, $card0, $card1);
						if ($display == "") {
							$display = "Unknown Item $equip_id";
						}
						$item = ItemID_To_ItemName($equip_id);
						$col_value = "<a href=item_manage.php?item=$item>$display</a>";
					}
					elseif ($current_row == 1) {    // don't print anything
					}
					else {
						$item = ItemID_To_ItemName($col_value);    // convert the item that isn't in nameid
						$col_value = "<a href=item_manage.php?item=$item>$item</a>";
					}
					if ($col_value != "skip") {
						echo "<td>$col_value</td>\n";
					}
				}
				echo "</tr>\n";
			}
			echo "</table>\n";
			
			// Searches the Cart
			$query = "SELECT amount, nameid, refine, card0, card1, card2, card3 FROM `cart_inventory` WHERE char_id = '$char_id'";
			$result = execute_query($query);
			if (mysql_num_rows($result) == 0) {
				echo "<br>Character cannot use a cart, or cart is empty.<br>";
			}
			else {
				echo "<br>";
				echo CharID_To_CharName($char_id) . "'s Cart Items:<p>\n";
				/* Printing results in HTML */
				EchoHead(100);
				echo "
	<tr class=myheader>
		<td colspan=7>$char_name's Cart Items:</td>
	</tr>
	<tr class=myheader>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            	";
				while ($line = mysql_fetch_row($result)) {
					echo "<tr class=mycell>\n";
					$current_row = 0;
					foreach ($line as $col_value) {
						$current_row++;
						if ($current_row == 1) {    // don't print anything
						}
						elseif ($current_row == 2) {
							// converts the item in nameid
							$refine_value = $line[2];    // obtains the refine level
							$card0 = $line[3];        // obtains card 0
							$card1 = $line[4];        // obtains card 1
							$equip_id = $col_value;    // obtains the equip name
							$display = convert_equip($equip_id, $refine_value, $card0, $card1);
							if ($display == "") {
								$display = "Unknown Item $equip_id";
							}
							$item = ItemID_To_ItemName($equip_id);
							$col_value = "<a href=item_manage.php?item=$item>$display</a>";
						}
						elseif ($current_row == 3) {
							$col_value = "skip";    // don't print this value, is needed for later purposes
						}
						else {
							$item = ItemID_To_ItemName($col_value);    // convert the item that isn't in nameid
							$col_value = "<a href=item_manage.php?item=$item>$item</a>";
						}
						if ($col_value != "skip") {
							echo "<td>$col_value</td>\n";
						}
					}
					echo "</tr>\n";
				}
				echo "</table>\n";
			}
		}
	}
}

function display_storage_items ($account_id) {
	// Displays the storage of the account id
	$query = "SELECT account_id FROM `login` WHERE account_id = '$account_id'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Account does not exist.";
	}
	else {
		$query = "SELECT amount, nameid, refine, card0, card1, card2, card3 FROM `storage` WHERE account_id = '$account_id'";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Storage is empty.";
		}
		else {
			echo "Items in Storage:<p>\n";
			/* Printing results in HTML */
			EchoHead(100);
			echo "
	<tr class=myheader>
		<td colspan=6>Items in Storage:</td>
	</tr>
	<tr class=myheader>
		<td>Quantity</td>
		<td>Item</td>
		<td>Card 1</td>
		<td>Card 2</td>
		<td>Card 3</td>
		<td>Card 4</td>
	</tr>
            ";
			while ($line = mysql_fetch_row($result)) {
				echo "<tr class=mycell>\n";
				$current_row = 0;
				foreach ($line as $col_value) {
					$current_row++;
					if ($current_row == 3) {
						$col_value = "skip";    // don't print this value, is needed for later purposes
					}
					elseif ($current_row == 2) {
						// converts the item in nameid
						$refine_value = $line[2];    // obtains the refine level
						$card0 = $line[3];        // obtains card 0
						$card1 = $line[4];        // obtains card 1
						$equip_id = $col_value;    // obtains the equip name
						$display = convert_equip($equip_id, $refine_value, $card0, $card1);
						if ($display == "") {
							$display = "Unknown Item $equip_id";
						}
						$item = ItemID_To_ItemName($equip_id);
						$col_value = "<a href=item_manage.php?item=$item>$display</a>";
						
					}
					elseif ($current_row == 1) {    // don't print anything
					}
					else {
						$item = ItemID_To_ItemName($col_value);    // convert the item that isn't in nameid
						$col_value = "<a href=item_manage.php?item=$item>$item</a>";
					}
					if ($col_value != "skip") {
						echo "<td>$col_value</td>\n";
					}
				}
				echo "</tr>\n";
			}
			echo "</table>\n";
		}
	}
}

function convert_equip ($weapon_id, $refine, $card0, $card1) {
	// This is the function that is used to convert the different numbers
	// Into Upgrade Level (+5), VS Level (Very Very Strong), and element (Fire)
	// Never figured out how to obtain the name of the forger, but for admin purposes,
	// that is not really that useful.
	//first, determine upgrade level
	$refine_expression = $refine;
	// Since VS/Elemental Armors CANNOT have cards in them, a 255 in Card0 signifies that
	// the following weapon is VS/Elemental, since card 255 does not exist
	if ($card0 != 255) {
		// Card0 is not 255, therefore, cannot be a VS/Elemental Weapon
		if ($refine > 0) {
			// Refine level is > 0
			$final_expression = "+" . $refine . " ";		// add in upgrade
		}
		return $final_expression .= ItemID_To_ItemName($weapon_id);	//return the standard item name
	}
	
	// determine if there are any VVS in them
	$star_crumb_level = intval($card1 / 1280);		// Athena uses card1 \ 1280 for level of star crumbs
	if ($star_crumb_level > 0) {
		for ($i = 1; $i < $star_crumb_level + 1; $i++) {
			$star_crumb_expression .= "Very ";	// Adds the appropriate # of 'Very's'
		}
		$star_crumb_expression .= "Strong ";	// Adds the "Strong"
	}
	// determine element
	$element_type = $card1 % 1280;					// Athena uses card1 MOD 1280 for element
	if ($element_type > 0) {
		// Weapon is elemental
		switch ($element_type) {
			case 1:
			$element_expression = "Ice ";
			break;
			case 2:
			$element_expression = "Earth ";
			break;
			case 3:
			$element_expression = "Fire ";
			break;
			case 4:
			$element_expression = "Wind ";
			break;
		}
	}
	$equip_name = ItemID_To_ItemName($weapon_id);		// The Name of the Actual Equip is obtained
	// without any modifiers
	if ($refine > 0) {
		$final_expression = "+" . $refine . " ";		// add in upgrade
	}
	if ($star_crumb_level > 0) {
		$final_expression .= $star_crumb_expression;		// Add V
	}
	if ($element_type > 0) {
		$final_expression .= $element_expression;		// Add Element
	}
	$final_expression .= $equip_name;	// Add Weapon Name
	return $final_expression;		// Returns the final expression (+5 Very Very Strong Fire Damascus)
}

?>