<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

// Makes sure that the user is on the right guild page, otherwise, kicks them out
$query = "SELECT master FROM guild WHERE guild_id = '$GET_guild_id'";
$result = execute_query($query);
if (mysql_num_rows($result) > 0) {
	$line = mysql_fetch_array($result);
	$guildmaster_name = $line['master'];
	// Checks if the account is the master of the current guild.
	if (account_of_character($guildmaster_name) != $STORED_login) {
		add_exploit_login("Tried to access another guild that was not theirs.");
		redir("index.php", "This is not your guild!");
		exit();
	}
}
else {
	redir("index.php", "Invalid Guild");
	exit();
}

// Determines root location, and adds the emblem folder to destination
if ($slash_mode == 1) {
	$end_position = strrpos($_SERVER['SCRIPT_FILENAME'], "\\");
	$emblem_folder = substr($_SERVER['SCRIPT_FILENAME'], 0, $end_position + 1) . "emblem\\";
}
else {
	$end_position = strrpos($_SERVER['SCRIPT_FILENAME'], "/");
	$emblem_folder = substr($_SERVER['SCRIPT_FILENAME'], 0, $end_position + 1) . "emblem/";
}

// Adds the image name to destinations
$destination = $emblem_folder . "$GET_guild_id.bmp";
if (!$POST_upload) {
	if (file_exists($destination)) {
		echo "Here is your current logo:<br>";
		echo "<img src=\"emblem\\$GET_guild_id.bmp\"><p>";
		echo "You can upload another one, if you wish.";
	}
	else {
		echo "You do not have an emblem uploaded! You can upload one below:";
	}
	display_upload_form();
}
else {
	if(!empty($_FILES["binFile"])) {
		if($_FILES['binFile']['name'] == '') {
			redir("upload_emblem.php", "You did not select a photo to upload");
			exit();
		}
		elseif($_FILES['binFile']['size'] == 0) {
			redir("upload_emblem.php", "There appears to be a problem with the logo your are uploading");
			exit();
		}
		elseif($_FILES['binFile']['size'] > $POST_MAX_FILE_SIZE) {
			redir("upload_emblem.php", "The photo you selected is too large");
			exit();
		}
		elseif(!getimagesize($_FILES['binFile']['tmp_name'])) {
			redir("upload_emblem.php", "You did not upload a proper image file!");
			exit();
		}
		else {
			$image_data = getimagesize($_FILES['binFile']['tmp_name']);
			$width = $image_data[0];
			$height = $image_data[1];
			if ($width != 24 or $height != 24) {
				//require 'header.inc';
				redir("upload_emblem.php", "The image must be 24x24!");
			}
			else {
				// The source of the upload
				$uploadfile = $uploaddir. $_FILES['binFile']['name'];
				// Uploads the file to final position
				if (move_uploaded_file($_FILES['binFile']['tmp_name'], $destination)) {
					redir("upload_emblem.php", "Upload file success!");
				}
				else {
					redir("upload_emblem.php", "There was a problem uploading your file.");
					print_r($_FILES);
				}
			}
			
		}
		exit();
	}
	else {
		redir("index.php", "You did not upload a file!");
		exit();
	}
}
require 'footer.inc';

function display_upload_form() {
	echo '
	<form method="POST" ACTION="" ENCTYPE="multipart/form-data">
		<input type="hidden" NAME="MAX_FILE_SIZE" value="1000000">
		<input type="hidden" NAME="action" value="upload">
		<table border="1" cellspacing=0 class=mytable>
			<tr class=myheader>
				<td>File: </td>
				<td><input type="file" NAME="binFile" class=myctl></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="upload" value="upload" class=myctl></td>
			</tr>
		</table>
	</form> 
	';
}
?>