DROP TABLE `admin_announce`;
DROP TABLE `gm_announce`;
DROP TABLE `user_announce`;
DROP TABLE `admin`;
DROP TABLE `access_log`;
DROP TABLE `admin_log`;
DROP TABLE `anti_bot`;
DROP TABLE IF EXISTS `athenaitem`;
DROP TABLE `ban_log`;
DROP TABLE `gm`;
DROP TABLE `ladder_ignore`;
DROP TABLE `mailbox`;
DROP TABLE `money_log`;
DROP TABLE `register_log`;
DROP TABLE `user_log`;
DELETE FROM `login` WHERE account_id = '20';
    