CREATE TABLE `admin` (
  `account_id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

CREATE TABLE `access_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` bigint(20) NOT NULL default '0',
  `User/IP` text NOT NULL,
  `Action` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

CREATE TABLE `admin_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` text NOT NULL,
  `User` text NOT NULL,
  `Action` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

CREATE TABLE `anti_bot` (
  `reg_id` text NOT NULL,
  `reg_code` int(11) NOT NULL default '0',
  `ctime` int(11) NOT NULL default '0'
) TYPE=MyISAM; 

CREATE TABLE `ban_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` bigint(20) NOT NULL default '0',
  `set_account_id` text NOT NULL,
  `ban_account_id` text NOT NULL,
  `reason` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

CREATE TABLE `gm` (
  `account_id` int(11) NOT NULL default '0'
) TYPE=MyISAM;

CREATE TABLE `ladder_ignore` (
  `account_id` int(11) NOT NULL 
);

CREATE TABLE `mailbox` (
  `msg_id` mediumint(9) NOT NULL auto_increment,
  `time` bigint(20) NOT NULL default '0',
  `from` mediumint(9) NOT NULL default '0',
  `to` mediumint(9) NOT NULL default '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `read_state` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`msg_id`)
) TYPE=MyISAM; 

CREATE TABLE `admin_announce` (
  `post_id` INT NOT NULL AUTO_INCREMENT ,
  `date` TEXT NOT NULL ,
  `message` TEXT NOT NULL ,
  `poster` TEXT NOT NULL ,
  PRIMARY KEY ( `post_id` ) 
);

CREATE TABLE `exploit_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` bigint(20) NOT NULL default '0',
  `User/IP` text NOT NULL,
  `Action` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

CREATE TABLE `gm_announce` (
  `post_id` INT NOT NULL AUTO_INCREMENT ,
  `date` TEXT NOT NULL ,
  `message` TEXT NOT NULL ,
  `poster` TEXT NOT NULL ,
  PRIMARY KEY ( `post_id` ) 
);

CREATE TABLE `user_announce` (
  `post_id` INT NOT NULL AUTO_INCREMENT ,
  `date` TEXT NOT NULL ,
  `message` TEXT NOT NULL ,
  `poster` TEXT NOT NULL ,
  PRIMARY KEY ( `post_id` ) 
);

INSERT INTO `admin_announce` (`post_id`, `date`, `message`, `poster`) VALUES ('0', '1085336655 ', 'Insert Admin Message Here', 'azndragon');
INSERT INTO `gm_announce` (`post_id`, `date`, `message`, `poster`) VALUES ('0', '1085336655 ', 'Insert GM Message Here', 'azndragon');
INSERT INTO `user_announce` (`post_id`, `date`, `message`, `poster`) VALUES ('0', '1085336655 ', 'Insert User Message Here', 'azndragon');

CREATE TABLE `money_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` bigint(20) NOT NULL default '0',
  `From` text NOT NULL,
  `To` text NOT NULL,
  `Action` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

CREATE TABLE `register_log` (
  `account_name` text NOT NULL,
  `ip` int(11) NOT NULL default '0',
  `reg_time` int(11) NOT NULL default '0'
) TYPE=MyISAM; 

CREATE TABLE `user_log` (
  `action_id` int(100) NOT NULL auto_increment,
  `Date` bigint(20) NOT NULL default '0',
  `User` text NOT NULL,
  `Action` text NOT NULL,
  PRIMARY KEY  (`action_id`)
) TYPE=MyISAM;

INSERT into `login` VALUES(20, 'CP', 'CP', '0000-00-00 00:00:00', 'S', 0, 'user@athena', 0);
INSERT into `admin` VALUES(20);