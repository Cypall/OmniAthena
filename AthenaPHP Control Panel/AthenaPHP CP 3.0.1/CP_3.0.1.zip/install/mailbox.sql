CREATE TABLE `mailbox` (
  `msg_id` mediumint(9) NOT NULL auto_increment,
  `time` bigint(20) NOT NULL default '0',
  `from` mediumint(9) NOT NULL default '0',
  `to` mediumint(9) NOT NULL default '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `read_state` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`msg_id`)
) TYPE=MyISAM; 