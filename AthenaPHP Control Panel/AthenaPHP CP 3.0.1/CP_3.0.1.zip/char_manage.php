<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
// determines what page to visit if nothing is being searched
if (!$GET_page) {
	$page = 1;
}
else {
	$page = $GET_page;
}
$size = 30;
$start = ($page * $size) - $size;
if ($GET_option == "search") {
	require 'item_functions.php';
	display_char_items($GET_char_id);
}
// Searches for character if requested
if ($GET_search != "") {
	$search_character = $GET_search;
	$query = "SELECT char_id, account_id, char_num, name, class, base_level, job_level, zeny, str, agi, vit, `int`, dex, luk, max_hp, max_sp
		FROM `char`
		WHERE name LIKE '%" . $search_character . "%'";
	display_char_table($query);
	$query = "SELECT char_id, account_id, char_num, name, class, base_level, job_level, zeny, str, agi, vit, `int`, dex, luk, max_hp, max_sp
        FROM `char`
        ORDER BY `char_id` ASC
        LIMIT $start, $size";
	echo "<p>";
	display_char_table($query);
	$display_table = true;
}
elseif ($GET_option == "deletechar") {
	$name = CharID_To_CharName($GET_char_id);
	echo "Are you sure you want to delete $name?<p>";
	echo "
	<form action=\"$PHP_SELF\" method=\"GET\">
	<input type=\"hidden\" name=\"delcharid\" class=\"myctl\" value=\"$GET_charid\">
	<input type=\"submit\" name=\"delete\" class=\"myctl\" value=\"Delete\">
	</form>
        ";
}
elseif ($POST_finishedit == "Edit This Character!") {
	$query = "UPDATE `char`
        SET char_num = '$POST_char_num',
        name = '$POST_name',
        class = '$POST_class',
        base_level = '$POST_blevel',
        job_level = '$POST_jlevel',
        zeny = '$POST_zeny',
        str = '$POST_str',
        agi = '$POST_agi',
        vit = '$POST_vit',
        `int` = '$POST_int',
        dex = '$POST_dex',
        luk = '$POST_luk',
        max_hp = '$POST_max_hp',
        max_sp = '$POST_max_sp',
        status_point = '$POST_status_point',
        skill_point = '$POST_skill_point',
        last_map = '$POST_last_map',
        last_x = '$POST_last_x',
        last_y = '$POST_last_y',
        save_map = '$POST_save_map',
        save_x = '$POST_save_x',
        save_y = '$POST_save_y'
        WHERE char_id = '$POST_char_id'
        ";
	$result = execute_query($query);
	add_admin_entry("Edited Character Information for $POST_editchar");
	redir("char_manage.php","Character Updated! Bringing you to Character Management");
}
elseif ($GET_delete == "Delete") {
	$delete_char_id = $GET_delchar_id;
	$delete_char = CharID_To_CharName($delete_char_id);
	echo "Deleting Information related to Character " . $delete_char;
	echo "<br>";
	clear_character($delete_char_id);
}
elseif ($GET_option == "editchar" && $GET_char_id != "") {
	$query = "SELECT char_id, account_id, char_num, name, class, base_level, job_level, zeny, str, agi, vit, `int`, dex, luk, max_hp, max_sp, status_point, skill_point, last_map, last_x, last_y, save_map, save_x, save_y
        FROM `char` WHERE char_id = '$GET_charid'";
	display_edit_table($query, $GET_charid);
}
else {
	$query = "SELECT char_id, account_id, char_num, name, class, base_level, job_level, zeny, str, agi, vit, `int`, dex, luk, max_hp, max_sp
    	FROM `char` ORDER by char_id LIMIT $start, $size";
	display_char_table($query);
	$display_table = true;
}

// Gets # of characters on server
$number_of_characters = GetCharacterCount();
$max_pages = intval($number_of_characters / 30) + 1;
if ($display_table) {
	if ($max_pages > 1) {
		for ($i = 1; $i < $max_pages; $i++) {
			echo "<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>-";
		}
		echo "<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>";
	}
	echo "
	<form action=\"$PHP_SELF\" method=\"GET\">
		<table border=0 align=\"center\">
			<tr>
				<td class=\"mytext\" align=\"left\">Search: </td>
				<td><input type=\"text\" name=\"search\" class=\"myctl\"></td>
			</tr>
		</table>
		<table border=0>
			<tr>
				<td align=\"left\"><input type=\"submit\" class=\"myctl\" value=\"Search\"></td>
			</tr>
		</table>
	</form>
	";
}

require 'footer.inc';

function display_char_table($input_query) {
	global $admin_colour, $gm_colour;
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Character Matching was found!";
	}
	else {
		EchoHead(100);
		echo "
	<tr class=myheader>    
		<td>Options</td>
		<td>Character ID</td>
		<td>Account Name</td>
		<td>Slot</td>
		<td>Name</td>
		<td>Class</td>
		<td>Base Level</td>
		<td>Job Level</td>
		<td>Zeny</td>
		<td>STR</td>
		<td>AGI</td>
		<td>VIT</td>
		<td>INT</td>
		<td>DEX</td>
		<td>LUK</td>
		<td>HP</td>
		<td>SP</td>
	</tr>
    	";
		while ($line = mysql_fetch_row($result)) {
			$account = $line[1];
			$char_id = $line[0];
			if (is_admin($account)) {
				$account_type = 'Admin';
			}
			elseif (is_gm($account)) {
				$account_type = 'GM';
			}
			else {
				$account_type = 'Normal';
			}
			echo "<tr class=mycell>\n";
			echo "
		<td>
			<form action=\"char_manage.php\" method=\"GET\">
				<select class=\"myctl\" name=\"option\">
					<option value=editchar>Edit
					<option value=deletechar>Delete
					<option value=search>Items
				</select>
				<input type=\"submit\" value=\"Go\" class=\"myctl\">
				<input type=\"hidden\" name=\"char_id\" value=\"{$line[0]}\">
			</form>
		</td>
			";
			$current_row = 0;
			foreach ($line as $col_value) {
				$current_row++;
				if ($current_row == 2) {
					$col_value = AccountID_To_UserID($col_value);
					$col_value = "<a href=\"account_manage.php?search=" . $col_value . "\">$col_value</a>";
				}
				if ($current_row == 5) {
					$col_value = determine_class($col_value);
				}
				if ($account_type != 'Normal') {
					if ($account_type == 'Admin') {
						echo "<td><font color=#$admin_colour>$col_value</font></td>\n";
					}
					if ($account_type == 'GM') {
						echo "<td><font color=#$gm_colour>$col_value</font></td>\n";
					}
				}
				else {
					echo "<td>$col_value</td>\n";
				}
			}
			echo "</tr>\n";
		}
		echo "</table>\n";
	}
}

function display_edit_table($input_query, $edit_char) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Character Matching was found!";
		return;
	}
	$line = mysql_fetch_row($result);
	$char_id = $line[0];
	$account_id = $line[1];
	$char_num = $line[2];
	$name = $line[3];
	$class = $line[4];
	$blevel = $line[5];
	$jlevel = $line[6];
	$zeny = $line[7];
	$str = $line[8];
	$agi = $line[9];
	$vit = $line[10];
	$int = $line[11];
	$dex = $line[12];
	$luk = $line[13];
	$max_hp = $line[14];
	$max_sp = $line[15];
	$status_point = $line[16];
	$skill_point = $line[17];
	$last_map = $line[18];
	$last_x = $line[19];
	$last_y = $line[20];
	$save_map = $line[21];
	$save_x = $line[22];
	$save_y = $line[23];
	
	echo "
	<b>Editing Character: $edit_char</b><p>
	<form action=\"$PHP_SELF\" method=\"POST\">
		<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">
			<tr>
				<td>Character ID</td>
				<td>$char_id</td>
				<input type=\"hidden\" name=\"char_id\" class=\"myctl\" value=\"$char_id\">
			</tr>
			<tr>
				<td>Account ID</td>
				<td>$account_id</td>
				<input type=\"hidden\" name=\"account_id\" class=\"myctl\" value=\"$account_id\">
			</tr>
			<tr>
				<td>Char Slot</td>
				<td><input type=\"text\" name=\"char_num\" class=\"myctl\" value=\"$char_num\"></td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type=\"text\" name=\"name\" class=\"myctl\" value=\"$name\"></td>
			</tr>
			<tr>
				<td>Class</td>
				<td>
				<select class=\"myctl\" name=\"class\">
    	";
	for ($i = 0; $i < 4023; $i++) {
		if ($i == 13 or $i == 21 or $i == 4014 or $i == 4022) {
			continue;
		}
		if ($i == 24) {
			$i = 4000;
			continue;
		}
		$display_class = determine_class($i);
		if ($i == $class) {
			echo "<option value=\"$i\" selected>$display_class";
		}
		else {
			echo "<option value=\"$i\">$display_class";
		}
		echo "\n";
	}
	
	echo "
				</select>
				</td>
			</tr>
			<tr>
				<td>Base Level</td>
				<td><input type=\"text\" name=\"blevel\" class=\"myctl\" value=\"$blevel\"></td>
			</tr>
			<tr>
				<td>Job Level</td>
				<td><input type=\"text\" name=\"jlevel\" class=\"myctl\" value=\"$jlevel\"></td>
			</tr>
			<tr>
				<td>Zeny</td>
				<td><input type=\"text\" name=\"zeny\" class=\"myctl\" value=\"$zeny\"></td>
			</tr>
			<tr>
				<td>STR</td>
				<td><input type=\"text\" name=\"str\" class=\"myctl\" value=\"$str\"></td>
			</tr>
			<tr>
				<td>AGI</td>
				<td><input type=\"text\" name=\"agi\" class=\"myctl\" value=\"$agi\"></td>
			</tr>
			<tr>
				<td>VIT</td>
				<td><input type=\"text\" name=\"vit\" class=\"myctl\" value=\"$vit\"></td>
			</tr>
			<tr>
				<td>INT</td>
				<td><input type=\"text\" name=\"int\" class=\"myctl\" value=\"$int\"></td>
			</tr>
			<tr>
				<td>DEX</td>
				<td><input type=\"text\" name=\"dex\" class=\"myctl\" value=\"$dex\"></td>
			</tr>
			<tr>
				<td>LUK</td>
				<td><input type=\"text\" name=\"luk\" class=\"myctl\" value=\"$luk\"></td>
			</tr>
			<tr>
				<td>Max HP</td>
				<td><input type=\"text\" name=\"max_hp\" class=\"myctl\" value=\"$max_hp\"></td>
			</tr>
			<tr>
				<td>Max SP</td>
				<td><input type=\"text\" name=\"max_sp\" class=\"myctl\" value=\"$max_sp\"></td>
			</tr>
			<tr>
				<td>Stat Points</td>
				<td><input type=\"text\" name=\"status_point\" class=\"myctl\" value=\"$status_point\"></td>
			</tr>
			<tr>
				<td>Skill Points</td>
				<td><input type=\"text\" name=\"skill_point\" class=\"myctl\" value=\"$skill_point\"></td>
			</tr>
			<tr>
				<td>Position</td>
				<td><input type=\"text\" name=\"last_map\" class=\"myctl\" value=\"$last_map\"></td>
			</tr>
			<tr>
				<td>Co-ordinates</td>
				<td width = \"20\">
				X: <input type=\"text\" name=\"last_x\" class=\"myctl\" value=\"$last_x\" size=4>
				Y: <input type=\"text\" name=\"last_y\" class=\"myctl\" value=\"$last_y\" size=4>
				</td>
			</tr>
			<tr>
				<td>Save Position</td>
				<td><input type=\"text\" name=\"save_map\" class=\"myctl\" value=\"$save_map\"></td>
			</tr>
			<tr>
				<td>Co-ordinates</td>
				<td width = \"20\">
				X: <input type=\"text\" name=\"save_x\" class=\"myctl\" value=\"$save_x\" size=4>
				Y: <input type=\"text\" name=\"save_y\" class=\"myctl\" value=\"$save_y\" size=4>
				</td>
			</tr>
		</table>
		<p>
		<input type=\"submit\" name=\"finishedit\" class=\"myctl\" value=\"Edit This Character!\">
		<input type=\"hidden\" name=\"char_id\" class=\"myctl\" value=\"$char_id\">
	</form>
    ";
}
?>