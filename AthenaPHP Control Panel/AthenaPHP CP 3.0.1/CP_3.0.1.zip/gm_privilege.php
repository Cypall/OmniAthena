<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
if ($GET_addaccount != "") {
	// Checks if account is valid
	$account_name = AccountID_To_UserID($GET_account);
	if ($account_name != "") {
		$query = "SELECT * FROM `gm` WHERE account_id = '$GET_account'";
		$result = execute_query($query);
		if (mysql_num_rows($result) > 0) {
			echo "Account is already a GM!<p>";
		}
		else {
			$query = "INSERT INTO `gm` VALUES('$GET_account')";
			$result = execute_query($query);
			echo "Account Added successfully!<p>";
			add_admin_entry("Added $account_name to GM Privileges", "None");
		}
	}
	else {
		echo "Not a valid account!<p>";
	}
}
elseif ($GET_delaccount != "") {
	// Checks if account is valid
	$account_name = AccountID_To_UserID($GET_delaccount);
	if ($account_name != "") {
		$query = "SELECT * FROM `gm` WHERE account_id = '$GET_account'";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			echo "Account is not a GM!<p>";
		}
		else {
			$query = "DELETE FROM `gm` WHERE account_id = '$GET_account'";
			//$result = execute_query($query);
			echo "Account Removed from GM successfully!<p>";
			//add_admin_entry("Removed $account_name from GM Privileges", "None");
		}
	}
	else {
		echo "Not a valid account!<p>";
	}
}
$query = "SELECT * FROM `gm` ORDER by account_id DESC";
$result = execute_query($query);
echo "
	<a href=\"account_manage.php\">View All Accounts</a><p>
";
EchoHead(50);
echo "
	<tr class=mytitle>
		<td colspan=3 class=myheader>Current GM Access</td>
	</tr>
	<tr class=myheader>
		<td>Account ID</td>
		<td>Account Name</td>
		<td>Action</td>
	</tr>
";

while ($line = mysql_fetch_row($result)) {
	$display_value = $line[0];
	$display_value2 = AccountID_To_UserID($display_value);
	echo "
	<tr class=mycell>
		<td>$display_value</td>
		<td><a href=\"account_manage.php?search=$display_value2\">$display_value2</a></td>
		<td><a href=\"gm_privilege.php?delaccount=$display_value\">Delete</a></td>
	</tr>
        ";
}
echo "
</table>
<p>
Add a New GM
<form action=\"gm_privilege.php\" method=\"GET\">
	<table align=\"center\" border=\"0\">
		<tr>
			<td class=\"mytext\">Account ID to Add:</td>
			<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"account\"></td>\n
			<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"addaccount\" value=\"Add Account\"></td>\n
		</tr>
	</table>
</form>
";

require 'footer.inc';
?>