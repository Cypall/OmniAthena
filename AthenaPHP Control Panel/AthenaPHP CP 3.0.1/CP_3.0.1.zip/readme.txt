**************************************************
*  SQL Athena Control Panel Coded by Azndragon   *
*                  Skin by zack                  *
*                 Version 3.x.x                  *
**************************************************

Latest versions of CP can be located at http://azndragon.ragonline.net/forums
Information about this script can also be located in the RO Emulator Section-->Tools & Programs section on Aegis SUpport Boards.

Note: Cookies MUST be enabled to login properly!

Please support ACP development by reporting bugs!

**************************
* What is the Athena CP? *
**************************

This is a PHP powered script designed for users running the SQL version of eAthena or OmniAthena. It provides user management for the players, as well as advanced server management for the host and GMs.

****************************
* Before Installing the CP *
****************************

If you are upgrading from a previous version, please uninstall your old tables.

In order to properly install the Control Panel, you must have:

SQL Athena already installed, because you need a fully working login table.
PHP & MySQL-enabled Webhost with:
	- PHP 4.3.7 (NOT EasyPHP! Use the standard PHP! EasyPHP is trash.)
	- MySQL 4.0
Highly recommended to use those 2 versions, or problems may arise, depending on how old your version is.
PhpMyAdmin, MySQL CC, or any other program you will use to execute your installer queries.

Not only do you need software, but I strongly recommend that you:

Have good knowledge of SQL and PHP (Syntax, how it works)
Know how to execute SQL queries (Can't install tables without knowing how to execute queries!)
Know proper SQL practice and procedures (table permissions, changing hosts/passwords)
Have general knowledge of how the tables for SQL Athena work (So you know what table does what)
Know how to setup and configure your webserver correctly and securely. (So .php files can be read properly, and secures your webserver from hackers)
Know how to read at a Grade 4 level, at least. (Seriously, some people need to know how to read, or they will not be able to install & config properly)

********************************************************************************************************************
Note: This guide also not guide you through the following things:

- Installing Athena
- Installing & configuring your webhost
- Installing & configuring PHP
- Installing & configuring MySQL
- Installing a MySQL GUI (a common choice)
- Executing Queries

You can search the internet for help on these areas.
********************************************************************************************************************

If you are not proficient in the above requirements, the Athena Control Panel may not be right to you, due to security issues, as well as potential database damage if you do not know what you are doing. Otherwise, carry on.

*********************
* Installing the CP *
*********************

Next, you must extract the contents of the .rar file into your webhost folder, where users can access it through index.php.
Edit the options in config.php according to your preferences.
Open install\install.sql, copy the entire query, and execute it with your chosen SQL program.
Register yourself an admin account on your server, if you havn't already.
Log into the Control Panel, with the login CP/CP.
When logged in, you will need to follow the instructions to set up your admin account with admin privileges.
After this is done, CP/CP login will be deleted, and you may log in with your admin account.
You may add further Admin/GM accounts with your new admin account.

******************************
* How do I uninstall the CP? *
******************************

Simply run the queries in uninstall.sql, which will delete the tables that are for the CP only.

************************************
* How do I Change the CP Settings? *
************************************

There are a few files that you can change to your liking.

config.php - Most of the script options
style.css - The style of the text, and tables
images\acp.jpg - The banner at the top of the page.
class.def & class_advanced.def - The different class names.
guild_castles.def - The names of the different castles.
Do NOT delete the emblem folder, even though it's blank! You will need it for saving guild emblems.

*************************************
* What can the Athena CP do for me? *
*************************************

For ordinary players, the Control Panel offers:

- Announcements for all users
- Server Information (Forums, IRC, rules, # of accounts/players, # of each class)
- Who's Online (oA Only, listing of all players online, with their level, job level, class, and position)
- Full Character Ladder, with sort by level and zeny, as well as top characters of certain classes.
- Guild Ladder, where guilds can be viewed, with details such as master, emblem, guild level, exp donated, as well as information regarding the castles that are owned by guilds.
- Changing Account Options (password, email, gender)
- Changing Character Hairstyle, through a javascript image scroller.
- Money transfer between characters on the same account (oA Only)
- Guild Master can upload emblems for their guild, which will be displayed on the guild ladder. Emblems will be saved in the \emblem folder.
- View Databases that the host will enable. Most common databases to view are the item_db and mob_db.
	Special Features:
	- item_db allows users to view the basic statistics of all items installed on the server.
	- mob_db features a monster table, where user can view the basic monster stats.
	- Both mob_db and item_db have interactive links, which can lead to more detailed information about their 	drops, and will also list other items that they drop. Clicking on a link to an item will display all 	monsters that drop the specific item.

Note: GM/Admin Privileges are based on the default $access config. This can be changed with config.php.

For GMs, their are also able to access:

- Announcements that can only be viewed by GMs and above.
- Account/Character/Guild Management, where they are able to view the information, as well as edit, or delete the associated data. Accounts can be banned/unbanned, as well as ignored/unignored from ladder. Account storage, and character items can also be viewed, but GM/Admin passwords will be censored. Guild castle information can be viewed/edited.
- Add new accounts to the database, with specified information, such as Account ID.
- Single Accounts/Characters can be banned/unbanned.
- Remove accounts/players based on login frequency, or illegal ASCII characters in name, which can be defined in config.php.
- Clear all information associated with currently banned accounts.
- Remove the temporary bans caused by failed password attempts.
- Edit/Delete the current announcements.
- Item Management, which allows for the searching of items, by item name, by account, or by character.
- View the list of all accounts currently ignored from the ladder.
- View Characters/Account associated with a given Character/Account ID/Name.
- View the list of currently banned accounts due to password failures, or otherwise.
- View the logs of accounts banned, money transfer, and user actions.

The highest privilege level, Admin, will be able to access the previous options, and the following:

- Announcements that can only be viewed by Admins.
- All passwords will be visible in Account Management.
- Maintain the list of accounts with GM/Admin Privileges.
- Full SQL dump of the server's current information.
- Full SQL Query access, where any queries can be executed, but requires MySQL login information for extra security.
- View the list of the minimum privilege levels required to access restricted pages.
- View the logs of:
	- Access
	- Admin Actions
	- Bans
	- Possible Exploit Attempts

************
* Security *
************

- HIGHLY recommended to change your passphrase in config.php, as this is what is used to encrypt the cookies.
- Enforce strong passwords for GM, and especially Admin Accounts, because account names WILL be displayed publicly to all users in announcements, as well as GM listings!
- Be wary of who you give Admin access to, because they have tremendous power over the server.
- GMs/Admins should read logs once in a while, to view possible exploits. Example: Access Log allows you to view all IPs that have logged into GM/Admin accounts, and you will be able to see if someone has accessed your login. Exploit log can possibly show if a user is trying to cheat the script, whether by SQL injection, or clever/illegal inputs.
- Backup regularly! You never know when an Admin will suddenly turn on you, a backup would be nice.

*************************
* Browser Compatibility *
*************************

This script has been tested with the latest version of IE, Mozilla, and Opera, and should work fine. It looks ugly with IE, however. Not that you should be using IE anyways. There may be a few layout issues with some browsers, so report any weird activity to me.

********
* FAQs *
********

Q: Will this be made for text servers?
A: No, never will. I despise text-based servers.

Q: I found _____ bug. What do I do?
A: Report it to the forums. Please be thorough in your explanation.

Q: I have a really good idea for the CP! What do I do?
A: Post it in the forums. If I like it, I will add it, and give credit.

******************
* Stuff About Me *
******************

I am azndragon, member of the OmniAthena Development Team. Not only have I coded the Control Panel for SQL Athena Users, I have also coded a character roster system for Aegis servers as well. I have also made a droplist program in VB, as well as PHP, and have made various other programs in VB (Upgrade Simulator, OBB/OVB/OCA/GB Simulator). You can find me in the AgelessAnime forums, Aegis Support Boards, or at my own forums.

*********
* Notes *
*********

- Make sure you read config.php all the way through, and understand what each option does.
- PLEASE leave credit to me at the bottom of the script! I have worked hard on this, and I deserve the credit.
- Please do not ask me about server issues! 99.99% of the time, I am not the owner/GM of the server.

***********
* Credits *
***********

Thanks to the following people:

Nucleo - For helping me with some layout, as well as a few coding sections.
Sandhawk of OmegaRO for providing me with a server to test on.
Development Team of AthenaAdvanced/OmniAthena - Adding features that the CP can use, and just for general support :)
Nexus - For some bug fixes, along with the GZIP feature added to the CP.
zack - For lots of help with layouts and design, especially version 3 update.
kAkEAsHi - Lots of bug testing for version 3 release, as well as offering me a server to test on as well.
Invision Power Board - For their anti-bot code.