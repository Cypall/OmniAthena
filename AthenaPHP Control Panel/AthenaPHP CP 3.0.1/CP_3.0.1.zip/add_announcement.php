<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
// This allows you to edit messages
if ($POST_action == "Add Admin Message") {
	$new_admin_message = $_POST['admin_message'];
	$edit_entry = time();
	$poster = $STORED_login;
	$query = "INSERT INTO `admin_announce` (`date`, `message`, `poster`) VALUES ('$edit_entry', '$new_admin_message', '$poster')";
	$result = execute_query($query);
	echo "Messages Updated!<br>";
}
elseif ($POST_action == "Add GM Message") {
	$new_gm_message = $_POST['gm_message'];
	$edit_entry = time();
	$poster = $STORED_login;
	$query = "INSERT INTO `gm_announce` (`date`, `message`, `poster`) VALUES ('$edit_entry', '$new_gm_message', '$poster')";
	$result = execute_query($query);
	echo "Messages Updated!<br>";
}
elseif ($POST_action == "Add User Message") {
	$new_user_message = $_POST['user_message'];
	$edit_entry = time();
	$poster = $STORED_login;
	$query = "INSERT INTO `user_announce` (`date`, `message`, `poster`) VALUES ('$edit_entry', '$new_user_message', '$poster')";
	$result = execute_query($query);
	echo "Messages Updated!<br>";
}
echo "This section allows you to add an announcement.";
echo "<form action=\"add_announcement.php?edit=true\" method=\"POST\">";

if ($STORED_level > 1) {
	// display GM and normal message
	echo "<p>Message to All Users (seen by everyone): ";
	echo "<p>\n";
	echo "<textarea name = \"user_message\" class=\"myctl\" ROWS=10 COLS=80></textarea><p>\n";
	echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Add User Message\"><br>\n";
	echo "<p>Message to All GMs (seen by GMs and Admins): ";
	echo "<p>\n";
	echo "<textarea name = \"gm_message\" class=\"myctl\" ROWS=10 COLS=80></textarea><p>\n";
	echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Add GM Message\"><br>\n";
}

if ($STORED_level > 2) {
	// display Admin message
	echo "<p>Message to All Admins (seen by Admins): ";
	echo "<p>\n";
	echo "<textarea name = \"admin_message\" class=\"myctl\" ROWS=10 COLS=80></textarea><p>\n";
	echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Add Admin Message\"><br>\n";
}
echo "</form>";
require 'footer.inc';
?>