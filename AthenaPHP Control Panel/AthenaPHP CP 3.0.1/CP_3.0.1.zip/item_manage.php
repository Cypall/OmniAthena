<?php
require 'memory.php';
require 'header.inc';
require 'item_functions.php';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

if ($GET_s_action == "Search Character") {
	if ($GET_charid > 0) {
		display_char_items($GET_charid);
	}
	else {
		display_char_items(CharName_To_CharID($GET_char));
	}
}
elseif ($GET_item != "") {
	display_item(ItemName_To_ItemID($GET_item));
}
elseif ($GET_s_action == "Search Account") {
	if ($GET_accountid > 0) {
		$search_id = $GET_accountid;
	}
	else {
		$search_id = UserID_To_AccountID($GET_account);
	}
	for ($i = 0; $i < 4; $i++) {
		$char[$i] = characters_on_account($search_id, $i);
		if ($char[$i] != "") {
			display_char_items($char[$i]);
		}
	}
	display_storage_items($search_id);
}
require 'footer.inc';
?>