<?php
/* Server Variables */
/* These are the variables that you will use for the configuration.*/

// Version of the CP, don't edit
$version = '3.0.1';

/********************************************
            Mandatory Variables
********************************************/            
// Host of the MySQL Database
$db_host = 'localhost';

// MySQL Username
$db_username = 'ragnarok';

// MySQL Password
$db_password = 'ragnarok';

// Name of MySQL Database
$db_name = 'ragnarok';

// Enter any string that will be used to encrypt the cookies with md5, 5+ characters is recommended.
// Please change this!
$passphrase = "";

/********************************************
         End Mandatory Variables
********************************************/

// Version of Athena, used in a few features
// Supposedly eA doesn't have online column working, which will disable whos_online.php
// as well as money_transfer.php
$athena = 0; // 0 = oA, 1 = non-oA

// What type of slash to use for uploads
// 1 = \ (Ex: C:\uploads - Ideal for webhosts on your computer)
// 2 = / (Ex: var/www/domains/uploads - Ideal for remote hosts that connect to your SQL database)
$slash_mode = 1;

// Use MD5 hashing for passwords?
$use_md5 = false;

// CP Protect on? (If true, only 127.0.0.1 will be able to access CP/CP)
// Not working ATM for some weird reason, I'll get to it later.
$cp_protect = false;

// List of all valid characters that can be used.
// Leave the space in, DO NOT take it out!
$validchars = "abcdefghijklmnopqrstuvwxyz0123456789!@._' ";

// List of all illegal characters that will be picked up in the Illegal ASCII Search in clear.php
$banned_characters = '@<>\\/()';

// Guild war times (Just use the integers after OnClock. (IE. OnClock1600 becomes 1600)
// Note: Be sure to use leading zeros (0820, not 820)
$agit_start = 1200;
$agit_end = 2300;

// Cookies or Sessions? 1 = Cookies, 2 = Sessions
// Sessions requires more advanced config, but requires no config from the user-end
// Using Cookies requires the user to disable cookie-blocking software
// Sessions don't work well currently
$save_type = 1;

// Frames on/off? true/false (Only works with cookies, not sessions)
$frames = false;

// Enable Gzip Compression to minimize traffic ? (Host must support it!)
$do_gzip_compress = true;

// Minimum Level to transfer money
$minimum_transfer = 20;

// Max Announcements to show
$max_announce = 2;

// Query Debugging?
$debug = false;

// If set to true, the script will only echo the queries on the page, but not
// actually execute them.
$execute_query = true;

// Whether or not to log all SELECT, UPDATE, and DELETE statements (queries.txt)
$log_select = false;
$log_update = true;
$log_delete = true;

// Server Name
$server_name = "Athena"; // Only used for ladder and guild ladder

// Enter Rules here, separated by <br> for each. You can add as many as you like.
$server_rules = <<< RULES
	Rule 1<br>
	Rule 2<br>
	Rule 3<br>
	Rule 4<br>
	Rule 5<br>
RULES;

// Website location
$website = 'http://';	

// Forums Link
$forums_location = 'http://';	// Leave blank if you don't have one

// Patch Location
$patch_location = 'http://'; // Location of any patch, leave blank if none

// IRC Channel
$irc = '';	// Location of IRC Channel, leave blank if none

// Location of Control Panel (web address, not computer address)
$cp_location = 'http://';

// Maximum Characters per account
$max_characters = '5';

// Max Players to display on the ladder
$display_limit = 50;

// Max Guilds to display on guild ladder
$display_guild_limit = 10;

/* Config for Registration */
$register = true;			// whether or not registration is enabled
$email_type = 'user';	// use 'default' for the same email for all users, 'user' for user-entered email
$secure_mode = true;		// enables the security code needed for registration

$inactive_days = 10; // Minimum days before an account is considered 'inactive'

//Lowest account ID that can be registered
$lowest_account_id = '2000000';

// Email Settings
$smtp_host = ''; //SMTP host (smtp.host.com)
$sendmail_from = ''; // Email account to send from

/* Colour Settings for Account Management*/
$admin_colour = 'ff0000';	//colour that is displayed for Admin Accounts
$gm_colour = '0000ff';	//colour that is displayed for GM Accounts

// Server Check Information
$check_server = false;	// Whether or not to check server
$accip = "127.0.0.1";    // AccountServer IP
$accport = "6900";      // AccountServer Port
$charip = "127.0.0.1";    // CharacterServer IP
$charport = "6121";    // CharacterServer Port
$mapip = "127.0.0.1";    // MapServer IP
$mapport = "5121";  // MapServer Port

// Access Levels
// Set each value to the MINIMUM access level to access each page. Pages not included
// are either set to 0 or 1 by default, and do not need to be changed.
// 2 = GM and Admin
// 3 = Admin Only

$access['account_manage.php'] = 2;
$access['add_account.php'] = 2;
$access['add_announcement.php'] = 2;
$access['admin_privilege.php'] = 3;
$access['backup_server.php'] = 3;
$access['ban.php'] = 2;
$access['char_manage.php'] = 2;
$access['clear_all_banned.php'] = 2;
$access['clear_banned.php'] = 2;
$access['clear.php'] = 2;
$access['clear_temp_banned.php'] = 2;
$access['edit_announcement.php'] = 2;
$access['gm_privilege.php'] = 3;
$access['guild_manage.php'] = 2;
$access['item_manage.php'] = 2;
$access['item_search.php'] = 2;
$access['ladder_ignore.php'] = 2;
$access['lookup_account.php'] = 2;
$access['lookup_character.php'] = 2;
$access['privileges.php'] = 3;
$access['query.php'] = 3;
$access['unban.php'] = 2;
$access['view_access_log.php'] = 3;
$access['view_admin_log.php'] = 3;
$access['view_ban_list.php'] = 2;
$access['view_ban_log.php'] = 3;
$access['view_exploit_log.php'] = 3;
$access['view_money_log.php'] = 2;
$access['view_user_log.php'] = 2;

// Personal Message System
$max_messages = 50; // Most messages that account is allowed to have.

// SQL DBs for Athena enabled or not, used for viewing databases, 
// you can allow more DBs to be shown by using:
// $athena_db['table_name'] = true;
// Example: $athena_db['char'] = true; 
// Above example should not actually be used, because it's not good to display char table
$athena_db['mob_db'] = true;

// Note: If item_db is enabled, the item conversion will be based off of the item_db table, not athenaitem.
$athena_db['item_db'] = true;

// The following information will be displayed in server_info.php
// as well as being used in monster stats/item drop calculations
$exp_rate = 1;
$jexp_rate = 1;
$drop_rate = 1;

?>