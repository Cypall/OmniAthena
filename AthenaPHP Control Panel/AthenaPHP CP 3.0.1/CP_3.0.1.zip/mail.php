<?php
require 'memory.php';
require 'header.inc';
if (!$GET_action && !$POST_action) {
	$query = "SELECT msg_id, subject, `from`, `time`, `read_state` FROM `mailbox` WHERE `to` = $account_id";
	$result = execute_query($query);
	EchoHead(80);
	echo "
	<tr class=mytitle>
		<td colspan=4>Your Inbox</td>
	</tr>
	<tr class=myheader>
		<td>Subject</td>
		<td>From</td>
		<td>Date</td>
		<td>Action</td>
	</tr>
	";
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>";
		$display_index = 0;
		$msg_id = $line[0];
		$read = $line[4];
		foreach($line as $col_value) {
			$display_index++;
			if ($display_index == 1 or $display_index == 5) {
				continue;
			}
			elseif ($display_index == 2) {
				$col_value = "<a href=\"mail.php?action=read&id=$msg_id\">$col_value</a>";
			}
			elseif ($display_index == 3) {
				$col_value = AccountID_To_UserID($col_value);
			}
			elseif ($display_index == 4) {
				$col_value = convert_date($col_value);
			}
			if ($read == 0) {
				echo "<td><b>$col_value</b></td>";
			}
			else {
				echo "<td>$col_value</td>";
			}
		}
		if ($read == 0) {
			echo "<td><a href=\"mail.php?action=del&id=$msg_id\"><b>Delete</b></a></td>";
		}
		else {
			echo "<td><a href=\"mail.php?action=del&id=$msg_id\">Delete</a></td>";
		}
		echo "</tr>";
	}
	echo "
		</table>
		<br>
		<a href=\"mail.php?action=new\">Compose new message</a>
		";
}
elseif ($GET_action == "new") {
	echo "
		<table border=1 class=\"mytext\" cellspacing=0>
			<form action=\"mail.php\" method=\"POST\">
				<input type=hidden name=\"action\" value=\"send\" class=\"myctl\">
			    	<tr>
			        	<td>To (Character Name)</td>
					<td><input type=\"text\" class=\"myctl\" name=\"to\"></td>
			   	</tr>
				<tr>
			        	<td>Subject</td>
					<td><input type=\"text\" class=\"myctl\" name=\"subject\"></td>
			   	</tr>
				<tr>
			        	<td>Message</td>
					<td align=left><textarea name = \"message\" class=\"myctl\" rows=10 cols=80></textarea></td>
			   	</tr>
				<tr>
					<td colspan=2><input type=\"submit\" class=\"myctl\" name=\"next\" value=\"Send!\"></td>
				</tr>
			</form>
		</table>
		";
}
elseif ($POST_action == "send") {
	$to = $POST_to;
	$to_id = UserID_To_AccountID(Account_Of_Character($to));
	$subject = $POST_subject;
	$message = $POST_message;
	$time = time();
	// Checks if account being sent to is valid
	if ($to_id == "") {
		redir("mail.php", "That account does not exist!", 60);
		exit();
	}
	if ($to == $STORED_login) {
		redir("mail.php", "You cannot send a message to yourself!", 60);
		exit();
	}
	// Checks length of subject
	if (strlen($subject) > 50) {
		redir("mail.php", "Your subject must be not be greater than 50 characters!", 60);
		exit();
	}
	$message_data = explode("\r\n", $message);
	for ($i = 0; $i < sizeof($message_data); $i++) {
		$final_message .= $message_data[$i] . "<br>";
	}
	// Checks that destination inbox is not full
	$query = "SELECT * FROM `mailbox` WHERE `to` = $to_id";
	$result = execute_query($query);
	if (mysql_num_rows($result) > $max_messages) {
		redir("mail.php", "The desination inbox is full! Please try sending the message later.", 60);
		exit();
	}
	$query = "INSERT INTO `mailbox` (`time`, `from`, `to`, subject, message) VALUES ($time, $account_id, $to_id, '$subject', '$final_message')";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		redir("mail.php", "There was an error sending your message. Please try again.", 60);
		exit();
	}
	else {
		redir("mail.php", "Message has been sent to $POST_to!", 60);
		exit();
	}
}
elseif ($GET_action == "read") {
	$query = "SELECT `from`, subject, message FROM `mailbox` WHERE msg_id = $GET_id AND `to` = $account_id";
	$result = execute_query($query);
	$line = mysql_fetch_array($result);
	$from = AccountID_To_UserID($line['from']);
	$subject = $line['subject'];
	$message = $line['message'];
	if (mysql_num_rows($result) > 0) {
		// Sets the read_state to 1, indicating that it's been read before
		$query = "UPDATE `mailbox` SET read_state = 1 WHERE msg_id = $GET_id";
		$result = execute_query($query, 'mail.php', true);
		echo "
			<table border=1 class=\"mytext\" cellspacing=0 width=50%>
			    	<tr>
			        	<td class=myheader>From</td>
					<td class=mycell>$from</td>
			   	</tr>
				<tr>
			        	<td class=myheader>Subject</td>
					<td class=mycell>$subject</td>
			   	</tr>
				<tr>
			        	<td class=myheader>Message</td>
					<td align=left class=mycell>$message</td>
			   	</tr>
			</table>
			";
		echo "<br><a href=\"mail.php?act=del&id=$GET_id\">Delete This Message!</a>";
	}
	else {
		redir("mail.php", "You cannot read the specified message.");
		exit();
	}
}
elseif ($GET_action == "del") {
	$query = "DELETE * FROM `mailbox` WHERE msg_id = $GET_id AND `to` = $account_id";
	$result = execute_query($query);
	if (mysql_affected_rows($result) > 0) {
		redir("mail.php", "Message Deleted!");
		exit();
	}
	else {
		redir("mail.php", "There was an error in deleting the message. It could not be deleted.");
		exit();
	}
}
require 'footer.inc';
?>