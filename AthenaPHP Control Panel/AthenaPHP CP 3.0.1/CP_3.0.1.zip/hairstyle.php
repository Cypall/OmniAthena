<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
if (!$GET_action) {
	// Check if user is logged onto system
	if (is_online($STORED_login)) {
		redir("index.php", "You cannot edit your hairstyle while logged on. Please log off and try again.");
	}
	else {
		$account_id = UserID_To_AccountID($STORED_login);
		$query = "SELECT sex FROM `login` WHERE userid = '$STORED_login'";
		$result = execute_query($query);
		$line = mysql_fetch_array($result, MYSQL_ASSOC);
		$current_gender = strtolower($line['sex']);
		$character_slot = $GET_char;
		$query = "SELECT hair FROM `char`
    		WHERE char_num = '$character_slot'
    		AND account_id = '$account_id'
    		";
		$result = execute_query($query);
		$line = mysql_fetch_array($result);
		
		$current_hair = $line['hair'];
	}
?>
<SCRIPT LANGUAGE="JavaScript">
function changehair() {
	var hairstyle;
	hairstyle = Hair.Style.value;
	document.HairStyle.src= hairstyle;
}
</SCRIPT>
<script language="JavaScript">
<!--
function na_call(str)
{
  eval(str);
}

// -->
</SCRIPT>
<?php
echo "Note: This is only for hair style, not hair colour. Colour can be changed through in-game NPC.";

echo "<form name=\"Hair\" method=\"GET\"><p>";
echo "<select name=\"Style\" class=\"myctl\" size=\"1\" OnChange=\"na_call('changehair()');\">\n";
if ($current_gender == "m") {
	$max = 19;
}
else {
	$max = 21;
}
for ($b = 1; $b < $max; $b++) {
	$load_image = $b - 1;
	if ($b == $current_hair) {
		echo "<option value=\"hair/" . $current_gender . $b . ".gif\" selected>Style $b</option>";
	}
	else {
		echo "<option value=\"hair/" . $current_gender . $b . ".gif\">Style $b</option>";
	}
	echo "\n";
	if ($current_gender == "M" AND $b == 18) {
		break;
	}
}
echo "</select>&nbsp;<br></p>";

echo "<img name=\"HairStyle\" src=\"hair/" . $current_gender . $current_hair . ".gif\"><p>
<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Change Hairstyle\"></center><p>
<input type=\"hidden\" class=\"myctl\" name=\"char\" value=\"$GET_char\">
</form>";
}
else {
	$new_hair_string = $GET_Style;
	$gender_position = strpos($new_hair_string, 'M');
	if ($gender_position > 0) {
		$hair_gender = "M";
	}
	else {
		$hair_gender = "F";
	}
	$gender_position = 5;	//M or F is the 6th letter
	$period_position = strpos($new_hair_string, '.');	// obtains position of .
	$length_of_int = $period_position - $gender_position - 1;
	$new_hair_int = substr($new_hair_string, $gender_position + 1, $length_of_int);
	$query = "SELECT name FROM `char` WHERE account_id = '$account_id' AND char_num = '$character_slot'";	//searches for name of that char #
	$result = execute_query($query);
	$line = mysql_fetch_array($result, MYSQL_ASSOC);
	$character_name = $line['name'];
	$query = "UPDATE `char`
		SET hair = '$new_hair_int'
		WHERE char_num = '$character_slot'
		AND name = '$character_name'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		redir("index.php", "Hair Style Change successful!");
		add_user_entry('Hairstyle Change', 'None');
	}
	else {
		echo "Something went wrong, or you didn't choose a new hairstyle!";
	}
}
require 'footer.inc';
?>