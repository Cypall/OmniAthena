<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
if ($POST_action == "Register Account!") {
	$register_user = $POST_user;        //obtains data
	$register_password = $POST_pass;
	$register_gender = $POST_gender;
	$register_code = $POST_code;
	if ($email_type == 'user') {
		$register_email = $POST_email;
	}
	else {
		$register_email = $default_email;
	}
	// checks lengths of username and password
	if (strlen($register_user) < 4 or strlen($register_user) > 10) {
		echo "Account Name must be between 4 and 10 letters.";
	}
	elseif (strlen($register_password) < 4) {
		echo "Password has to be more than 4 letters.";
	}
	elseif (strlen($register_email) < 6 or strlen($register_email) > 24) {
		echo "Your email must be between 6 and 24 letters.";
	}
	else {
		// checks if legal characters are in username/password
		if (isalphanumeric($register_user) == true AND isalphanumeric($register_password)) {
			$query = "SELECT userid, user_pass FROM login WHERE userid = '$register_user'";    // searches if account already existss
			$result = execute_query($query);
			if (mysql_num_rows($result) > 0) {
				echo "Account Already Exists, please choose another one.";
			}
			else {
				$query = "SELECT account_id FROM `login`
	                WHERE userid != 'CP'
	                ORDER BY account_id DESC LIMIT 1
	                ";    //searches for highest id #
				$result = execute_query($query);
				$line = mysql_fetch_array($result, MYSQL_ASSOC);
				if ($POST_account_id == 0) {
					$last_id = $line['account_id']; //returns the last id registered
					$register_id = $last_id + 1;
					if ($register_id <= $lowest_account_id ) {
						$register_id = $lowest_account_id  + 1;
					}
				}
				else {
					$register_id = $POST_account_id;
					$query = "SELECT * FROM login WHERE account_id = '$register_id'";    // searches if account already existss
					$result = execute_query($query);
					if (mysql_num_rows($result) > 0) {
						echo "That Account ID is already taken!";
						$register_id = 0;
					}
				}
				if ($register_id != 0) {
					$query = "INSERT into `login` VALUES($register_id, '$register_user', '$register_password', '0000-00-00 00:00:00', '$register_gender', 0, '$register_email', 0);";
					$result = execute_query($query);
					if (mysql_affected_rows() > 0) {
						echo "Account Signup Sucessful!<br>\n";
						echo "Your email for character deletion is: " . $register_email;
						if ($forums_location != "") {
							echo "<br>Forums are located at: <a href=\"$forums_location\">$forums_location</a>\n";
						}
						if ($patch_location != "") {
							echo "<br>Patch is located at: <a href=\"$patch_location\">$patch_location</a>\n";
						}
						if ($irc != "") {
							echo "<br>IRC Channel: $irc\n";
						}
					}
					else {
						echo "Account Signup Failed, please contact one of the gamemasters.";
					}
				}
			}
		}
		else {
			echo "Illegal characters detected. Please use A-Z, a-z, 0-9 only.";
		}
		
	}
}
else {
	
	echo "
	<table align=\"center\" class=\"mytext\" border=\"0\">
	<form action=\"add_account.php\" method=\"POST\">
	<tr class=mytitle>
		<td colspan=2>GM Add Account</td>
	</tr>
	<tr>
		<td>Account ID<br>(Enter 0 for no preference): </td>
		<td><input type=\"text\" class=\"myctl\" name=\"account_id\"></td>
	</tr>
	<tr>
		<td>Account Name: </td>
		<td><input type=\"text\" class=\"myctl\" name=\"user\"></td>
	</tr>
	
	<tr>
		<td>Password: </td>
		<td><input type=\"password\" class=\"myctl\" name=\"pass\"></td>
	</tr>
	
	<tr>
		<td>Gender: </td>
		<td>
			<select name=\"gender\" class=\"myctl\">
			<option value=M>Male
			<option value=F>Female
			</select>
		</td>
	</tr>
	";
	
	if ($email_type == 'user') {
		echo "
	<tr>
		<td>Email: </td>
		<td><input type=\"text\" class=\"myctl\" name=\"email\"></td>
	</tr>
		";
	}
	echo "
	<tr>
		<td colspan=2>
			<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Register Account!\">
		</td>
	</tr>
	";
	echo "
	</form>
</table>
	";
}
require 'footer.inc';
?>