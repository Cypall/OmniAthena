<?php
require 'memory.php';
require 'header.inc';
$message = <<< MSG
	This Control Panel was coded by Azndragon. You may email me for comments, suggestions, or support.<br>
	However, DO NOT email me about server issues such as when it will be up, or why registration is closed.<br>
	I do not own this server, I have just coded a tool for it, and I am getting too many emails about server issues.<br>
	If you want to know about server issues, talk to the GMs, not me!<br>
	For those with a legitimate reason to email me, you can contact me at <a href="mailto:azndragon1987@hotmail.com">azndragon1987@hotmail.com</a><br>
	Or, contact me on forums: <a href=http://azndragon.ragonline.net/forums>http://azndragon.ragonline.net/forums</a>
	<br>
	<br>
	<center><b>Information about zack:</b></center>
	My name is zack and I live in the UK (United Kingdom) I am 16 years old, and I like doing/graphics/music etc etc o_O<br>
	I'm a big RO and anime fan, and stuff.. o_O If you need to contact me for anything zack-NOSPAM-@rpg-creation.net *remove -NOSPAM-*<br>
	(that also acts as my msn messenger) or on my AIM, EbilZack, you can also see me at my website, <a href="http://zack.h3nt.net">http://zack.h3nt.net</a> and <a href="http://rpg-creation.net">http://rpg-creation.net</a><br>
	P.S If you didnt know, I created the skin for AthenaCP<br>
MSG;
echo $message;
require 'footer.inc';
?>