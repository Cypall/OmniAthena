<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
if (!$POST_action) {
	if (is_online($STORED_login)) {
		redir("index.php", "You cannot edit your account options while logged on. Please log off and try again.");
	}
	else {
		echo "Here, you can change your password, as well as your gender and email.<p>\n
			<form action=\"\" method=\"POST\">
			<table align=\"center\" border=\"0\">
			<tr>
			<td class=\"mytext\">Old Password:</td>
			<td class=\"mytext\"><input type=\"password\" class=\"myctl\" name=\"old_pass\"></td>\n
			</tr>
			<tr>
			<td class=\"mytext\">New Password:</td>
			<td class=\"mytext\"><input type=\"password\" class=\"myctl\" name=\"new_pass\" size=20></td>\n
			</tr>
			<tr>
			<td class=\"mytext\">Re-enter your new password:</td>
			<td class=\"mytext\"><input type=\"password\" class=\"myctl\" name=\"new_pass2\" size=20></td>\n
			</tr>
			</table>
			<input type=\"submit\" name=\"action\" class=\"myctl\" value=\"Change Password\"><br><br>\n
		";
		
		if ($email_type == 'user') {
			echo "
				<table align=\"center\" border=\"0\">
				<tr>
				<td class=\"mytext\">Enter your new email:</td>
				<td class=\"mytext\"><input type=\"text\" size=24 class=\"myctl\" name=\"new_email\" size=10></td>\n
				</tr>
				</table>
				<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Change Email\"><br><br>\n
				";
		}
		// Determine if there is bard/dancer in account
		$query = "SELECT * FROM `char` WHERE account_id = $account_id AND (class = 19 OR class = 20)";
		$result = execute_query($query);
		if (mysql_num_rows($result) == 0) {
			$disable_gender = false;
		}
		else {
			$disable_gender = true;
		}
		
		$query = "SELECT sex FROM `login` WHERE userid = '$STORED_login'";
		$result = execute_query($query);
		$line = mysql_fetch_array($result, MYSQL_ASSOC);
		$current_gender = $line['sex'];
		echo "<table align=\"center\" border=\"0\">";
		if ($disable_gender) {
			if ($current_gender == "M") {
				$disabled_class = "Bard";
			}
			else {
				$disabled_class = "Dancer";
			}
			
			echo "<td class=\"mytext\">You cannot change genders, because you have a $disabled_class!</td>
				</table>";
		}
		else {
			echo "
				<td class=\"mytext\">Gender:</td>
				<td class=\"mytext\"><select name=\"gender\" class=\"myctl\">";
			if ($current_gender == 'M') {
				echo "<option value=M selected>Male";
				echo "<option value=F>Female";
			}
			else {
				echo "<option value=M>Male";
				echo "<option value=F selected>Female";
			}
			echo "</select>";
			echo "</tr>";
			echo "</table>";
			echo "<input type=\"submit\" name=\"action\" class=\"myctl\" value=\"Change Gender\"><br>\n";
		}
		echo "</form>";
	}
}
elseif ($POST_action == "Change Password") {
	$old_password = $POST_old_pass;
	$new_password = $POST_new_pass;
	$new_password2 = $POST_new_pass;
	if ($use_md5) {
		$old_password = md5($old_password);
	}
	// Confirm Old Password
	$query = "SELECT * FROM `login` WHERE userid = '$STORED_login' AND user_pass = '$old_password'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "You have used the wrong password!";
	}
	else {
		//Checks that new password is repeated correctly
		if ($new_password == $new_password2) {
			//Checks length of password
			if (strlen($new_password) < 4) {
				echo "Password has to be more than 4 letters.";
			}
			else {
				if ($use_md5) {
					$new_password = md5($new_password);
				}
				//All checks have been passed, updating newpassword
				$query = "UPDATE login
					SET user_pass = '$new_password'
					WHERE userid = '$STORED_login'";
				$result = execute_query($query);
				if ($result > 0) {
					echo "Password Change Sucessful!<br>\n";
					echo "Your new password is: " . $new_password;
					add_user_entry("Changed Password");
				}
				else {
					echo "Password Change Failed.";
				}
				$query = "ALTER TABLE `login` ORDER BY `account_id`"; // resorts the login table
				$result = execute_query($query);
			}
		}
		else {
			echo "You have not repeated your old password correctly!";
		}
	}
}
elseif ($POST_action == "Change Gender") {
	$new_gender = $POST_gender;
	// Checks that you do not have bard/dancer on account
	$query = "SELECT * FROM `char` WHERE account_id = $account_id AND (class = 19 OR class = 20)";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		$query = "UPDATE login
			SET sex = '$new_gender'
			WHERE userid = '$STORED_login'";
		$result = execute_query($query);
		add_user_entry("Changed Account to $new_gender");
		redir("index.php","Account Updated! Bringing you to Home Page");
	}
	else {
		redir("index.php","You cannot change gender if you have a Bard/Dancer!");
	}
}
elseif ($POST_action == "Change Email") {
	$new_email = $POST_new_email;
	$query = "UPDATE login
		SET email = '$new_email'
		WHERE userid = '$STORED_login'";
	$result = execute_query($query);
	add_user_entry("Changed Email to $new_email");
	redir("index.php","Account Updated! Bringing you to Home Page");
}
require 'footer.inc';
?>