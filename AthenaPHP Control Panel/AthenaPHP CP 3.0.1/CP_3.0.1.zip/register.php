<?php

/*
Not your simple registration script, as this uses input validation, anti-bot security codes,
as well as email/admin validation, if desired.
Credits to Invision Power Board for their security codes.
*/

require 'memory.php';

if ($GET_rc != "") {
	// Displays the image, based on the arguements in the image
	$query = "SELECT reg_code FROM `anti_bot` WHERE reg_id = '$GET_rc'";
	$result = execute_query($query);
	$line = mysql_fetch_row($result);
	$this_number = substr($line[0], $GET_p - 2, 1);
	$numbers = array( 
		0 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIUDH5hiKsOnmqSPjtT1ZdnnjCUqBQAOw==',
		1 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIUjAEWyMqoXIprRkjxtZJWrz3iCBQAOw==',
		2 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIUDH5hiKubnpPzRQvoVbvyrDHiWAAAOw==',
		3 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIVDH5hiKbaHgRyUZtmlPtlfnnMiGUFADs=',
		4 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIVjAN5mLDtjFJMRjpj1Rv6v1SHN0IFADs=',
		5 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIUhA+Bpxn/DITL1SRjnps63l1M9RQAOw==',
		6 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIVjIEYyWwH3lNyrQTbnVh2Tl3N5wQFADs=',
		7 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIUhI9pwbztAAwP1napnFnzbYEYWAAAOw==',
		8 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIVDH5hiKubHgSPWXoxVUxC33FZZCkFADs=',
		9 => 'R0lGODlhCAANAJEAAAAAAP////4BAgAAACH5BAQUAP8ALAAAAAAIAA0AAAIVDA6hyJabnnISnsnybXdS73hcZlUFADs=',
	);
		
	flush();
	header("Content-type: image/gif");
	echo base64_decode($numbers[ $this_number ]);
	exit();
}
require 'header.inc';
				
if ($register == false) {
	redir("login.php", "Sorry, the Administrator has disabled registration.");
	exit();
}

if ($POST_action == "Register Account!") {
	$register_user = $POST_register_user;		//obtains data
	$register_password = $POST_register_pass;
	$register_gender = $POST_gender;
	$register_code = $POST_code;
	// oA can now support 100 character emails
	if ($athena == 0) {
		$max_email_length = 100;
	}
	else {
		$max_email_length = 24;
	}
	if ($email_type == 'user') {
		$register_email = $POST_register_email;
	}
	else {
		$register_email = $default_email;
	}
	
	// Makes sure that security code has been entered
	if ($POST_code == "") {
		display_error("You must enter a security code to register!");
	}
	// checks lengths of username and password
	elseif (strlen($register_user) < 4 or strlen($register_user) > 10) {
		display_error("Account Name must be between 4 and 10 letters.");
	}
	elseif (strlen($register_password) < 4) {
		display_error("Password has to be more than 4 letters.");
	}
	elseif (strlen($register_email) < 6 or strlen($register_email) > $max_email_length) {
		display_error("Your email must be between 6 and $max_email_length letters.");
	}
	elseif ($POST_register_pass != $POST_register_pass2) {
		display_error("Your two passwords do not match! Please try again.");
	}
	// checks if legal characters are in username/password
	if (!isalphanumeric($register_user) or !isalphanumeric($register_password)) {
		display_error("Illegal characters detected. Please use A-Z, a-z, 0-9 only.");
	}
	$query = "SELECT userid, user_pass FROM login WHERE userid = '$register_user'";	// searches if account already existss
	$result = execute_query($query);
	if (mysql_num_rows($result) > 0) {
		display_error("Account Already Exists, please choose another one.");
	}
	// Checks that security code entered is the same as code in DB
	$query = "SELECT reg_code FROM `anti_bot` WHERE reg_id = '$POST_reg_id' AND reg_code = '$POST_code'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		display_error("You did not enter the correct security code!");
	}
	// There is a match, delete the entry from the DB
	$query = "DELETE FROM `anti_bot` WHERE reg_id = '$POST_reg_id'";
	$result = execute_query($query);
	if ($use_md5) {
		// MD5 Support upon registration.
		$register_password = md5($register_password);
	}
	// Inserts the registered user to login table
	if ($email_type == "user") {
		$query = "INSERT into `login` (userid, user_pass, sex, email) VALUES('$register_user', '$register_password', '$register_gender', '$register_email')";
	}
	else {
		$query = "INSERT into `login` (userid, user_pass, sex) VALUES('$register_user', '$register_password', '$register_gender')";
	}
	$result = execute_query($query);
	if (mysql_affected_rows() == 0) {
		display_error("Account Signup Failed, please contact one of the gamemasters.");
	}
	
	// Inserts the ip, time, as well as account that was registered into register log.
	$ip = ip2long($_SERVER['REMOTE_ADDR']);
	$c_time = time();
	$query = "INSERT INTO `register_log` VALUES('$register_user', '$ip', '$c_time')";
	$result = execute_query($query);
	echo "Account Signup Sucessful!<br>\n";
	echo "Your email for character deletion is: " . $register_email;
	if ($forums_location != "") {
		echo "<br>Forums are located at: <a href=\"$forums_location\">$forums_location</a>\n";
	}
	if ($patch_location != "") {
		echo "<br>Patch is located at: <a href=\"$patch_location\">$patch_location</a>\n";
	}
	if ($irc != "") {
		echo "<br>IRC Channel: $irc\n";
	}
		
}
else {
	
	echo "Registration for $server_name<br>\n";
	echo "Note: Please click register ONLY ONCE!";
	
	echo "
    		<table align=\"center\" class=\"mytext\" border=\"0\">
    		<form action=\"\" method=\"POST\">
    		<tr>
    			<td>Account Name: </td>
    			<td><input type=\"text\" class=\"myctl\" name=\"register_user\"></td>
    		</tr>

    		<tr>
    			<td>Password: </td>
    			<td><input type=\"password\" class=\"myctl\" name=\"register_pass\"></td>
    		</tr>

		<tr>
			<td>Enter Password again: </td>
			<td><input type=\"password\" class=\"myctl\" name=\"register_pass2\"></td>
		</tr>

		<tr>
			<td>Gender: </td>
			<td>
				<select name=\"gender\" class=\"myctl\">
				<option value=M>Male
				<option value=F>Female
				</select>
			</td>
		</tr>
	";
	
	if ($email_type == 'user') {
		echo "<tr>
        	<td>Email: </td>
        	<td><input type=\"text\" class=\"myctl\" name=\"register_email\"></td>
        	</tr>";
	}
	echo "</table>";
	
	echo "
	<table align=\"center\" class=\"mytext\" border=\"0\">
		<tr>
			<td><b>By registering, you agree to the following rules:</b></td>
		</tr>
		<tr>
			<td><b>$server_rules</b></td>
		</tr>
	</table>
	";
	
	if ($secure_mode == true) {
		// Anti-bot registration
		
		// Clear out old register IDs older than 1 hour old.
		$del_time = time() - (60*60);
		// Remove old reg requests from the DB
		$query = "DELETE FROM `anti_bot` WHERE ctime < '$del_time'";
		$result = execute_query($query, 'register.php', true);
		
		$reg_id = md5(uniqid(microtime()) ); // set register id	
		// Generates the random number
		mt_srand ((double) microtime() * 1000000);
		$reg_code = mt_rand(100000, 999999);
		
		$c_time = time();
		// Stores the register ID into the DB
		$query = "INSERT INTO `anti_bot` VALUES('$reg_id', '$reg_code', '$c_time')";
		$result = execute_query($query);
		
		echo "<p>Please enter the numbers of the image below into the text box.<br>\n";
		echo "Note: They are all numbers, there are no letters.<p>\n";
		generate_random_number($reg_id);
		echo "<p>Security Code: <input type=\"text\" class=\"myctl\" name=\"code\"><p>";
	}
	echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Register Account!\">";
}
require 'footer.inc';

function generate_random_number ($reg_id) {
	echo "
	<img src='register.php?rc={$reg_id}&p=2' border='0' alt='Code Bit' />
	<img src='register.php?rc={$reg_id}&p=3' border='0' alt='Code Bit' />
	<img src='register.php?rc={$reg_id}&p=4' border='0' alt='Code Bit' />
	<img src='register.php?rc={$reg_id}&p=5' border='0' alt='Code Bit' />
	<img src='register.php?rc={$reg_id}&p=6' border='0' alt='Code Bit' />
	<img src='register.php?rc={$reg_id}&p=7' border='0' alt='Code Bit' />
	<input type=hidden  name=reg_id value=$reg_id>
	";
}
function display_error($error_message) {
	echo $error_message;
	require 'footer.inc';
	exit();
}
?>