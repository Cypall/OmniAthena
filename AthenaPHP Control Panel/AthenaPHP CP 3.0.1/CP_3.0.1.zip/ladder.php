<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

$max_display = $display_limit * 2; // Sets a reasonable limit to what can be selected.
if ($GET_action == "Sort") {
	switch ($GET_search_type) {
		case 1:
			$query = "SELECT account_id, name, class, base_level	 FROM `char` ORDER BY base_level DESC LIMIT $max_display";
			$limit_results = true;
			break;
		case 2:
			/*$query = "SELECT account_id, name, class, base_level FROM `char` ORDER BY zeny DESC LIMIT $max_display";
			$limit_results = true;*/
			break;
		case 3:
			$query = "SELECT account_id, name, class, base_level FROM `char` ORDER BY name";
			$limit_results = false;
			break;
	}
}
elseif ($GET_action == "Display") {
	$search_class = $GET_search_class;
	if (strlen($search_class) > 5) {
		add_exploit_entry('Possible SQL injection attempt in ladder.php');
		redir("index.php", "Invalid Class to search!");
		exit();
	}
	if ($search_class == 7 or $search_class == 14 or $search_class == 4008 or $search_class == 4015) {
		$multi = true;
	}
	if ($multi) {
		switch($search_class) {
			case 7:
				$search_class2 = 13;
				break;
			case 14:
				$search_class2 = 21;
				break;
			case 4008:
				$search_class2 = 4014;
				break;
			case 4015:
				$search_class2 = 4022;
				break;
		}
		$query = "SELECT account_id, name, class, base_level FROM `char`
	        WHERE class = $search_class
    		OR class = $search_class2
	        ORDER BY base_level DESC LIMIT $max_display";
	}
	else {
		$query = "SELECT account_id, name, class, base_level FROM `char`
	        WHERE class = $search_class
	        ORDER BY base_level DESC LIMIT $max_display";
	}
	$limit_results = true;
}
else {
	$query = "SELECT account_id, name, class, base_level FROM `char` ORDER BY base_level DESC LIMIT $max_display";
	$limit_results = true;
}

echo "
<form action=\"\" method=\"GET\">
	Sort Type: 
	<select name=\"search_type\" class=\"myctl\">
		<option value=1 selected>Level
		<option value=3>Display All (" . GetCharacterCount() . " chars)
	</select>
	<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Sort\"><br>
	Display Top: 
	<select name=\"search_class\" class=\"myctl\"5>
";

for ($i = 0; $i < 4023; $i++) {
	// Skip the peco classes
	if ($i == 13 or $i == 21 or $i == 4014 or $i == 4022) {
		continue;
	}
	if ($i == 24) {
		$i = 4000;
		continue;
	}
	echo "
		<option value=$i>" . determine_class($i) . "s
	";
}
echo "</select>
	<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Display\">
	<br>
</form>";
if ($limit_results == true) {
	display_ladder ($query, $display_limit);
}
else {
	set_time_limit(0);	// Disables the timeout limit for the large search
	display_ladder ($query, 10000);
}
require 'footer.inc';

function display_ladder($input_query, $input_display_limit) {
	global $server_name;
	// Displays the ladder with different queries as input
	$display_limit = $input_display_limit;
	$result = execute_query($input_query);
	$total_results = 0;
	
	for ($i = 0; $i < 24; $i++) {
		$total_class_count[$i] = 0;
	}
	if (mysql_num_rows($result) == 0) {
		echo "No characters can be displayed!";
	}
	else {
		echo "
<table align=\"center\" border=1 width=800 cellspacing=0 cellpadding=5 class=\"mytable\">
	<tr>
		<td class=mytitle colspan=6>$server_name Player Ladder Top $display_limit</td>
	</tr>
	<tr class=myheader>
		<td>Rank</td>
		<td>Name</td>
		<td>Class</td>
		<td>Level</td>
	</tr>
	    ";
		while ($line = mysql_fetch_row($result)) {
			$account_id = UserID_To_AccountID(account_of_character($line[1]));
			// Character is not on ignore list
			if (!is_ignored($account_id)) {
				$current_rank++;
				echo "<tr class=mycell>";
				echo "<td>$current_rank</td>\n";
				foreach ($line as $display_index => $col_value) {
					// if account_id is in the result
					if ($display_index == 0) {
						// skips printing out the column
						continue;
					}
					if ($display_index == 2) {
						$col_value = determine_class($col_value);  // prints out thier class
					}
					echo "<td>$col_value</td>";
					echo "</td>";
				}
				echo "</tr>";        // ends the row
				$total_results++;
				// Has the ladder limit been reached?
				if ($total_results == $display_limit) {
					break;
				}
			}
		}
		echo "</table>\n";
	}
}
?> 