<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
if (!$GET_action && !$POST_action) {
	$query = "SELECT account_id FROM `login` WHERE level = '-1'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "There are no banned accounts!";
	}
	else {
		echo "Unban a player! Enter the character name, and you can ban the account that it came from, or just ban the account.<br>
		There will be a confirmation screen if you make a mistake.
		<form action=\"unban.php\" method=\"GET\">
		Character Name: <input type=\"text\" class=\"myctl\" name=\"character_name\">\n
		<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Unban Character\"><br>\n
		Account Name: <input type=\"text\" class=\"myctl\" name=\"account_name\">\n
		<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Unban Account\"><br>\n
		</form>
		";
		echo "The following accounts are banned:<p>\n";
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$display = $line['account_id'];
			$account_to_clear = AccountID_To_UserID($display);
			echo $account_to_clear;
			echo "<br>";
		}
	}
}
elseif ($POST_action == "Unban This Account!") {
	$ban_id = UserID_To_AccountID($POST_account_name);
	$reason = $POST_reason;
	
	$query = "UPDATE `login`
        SET level = '0'
        WHERE account_id = '$ban_id'";        //unbans the login
	$result = execute_query($query);
	add_admin_entry('Unbanned ' . $POST_account_name, $reason);
	add_unban_entry($POST_account_name, $reason);
	redir("index.php", $POST_account_name . " Unbanned!");
}
else {
	if ($GET_character_name != "") {
		$unban_account = account_of_character($GET_character_name);
	}
	if ($GET_account_name != "") {
		$unban_account = $GET_account_name;
	}
	if ($unban_account != "") {
		display_unban($unban_account);
	}
}
require 'footer.inc';
?>