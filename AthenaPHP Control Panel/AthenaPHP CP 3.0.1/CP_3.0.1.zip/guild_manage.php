<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
// determines what page to visit if nothing is being searched

if (!$GET_page) {
	$page = 1;
}
else {
	$page = $GET_page;
}
$size = 30;
$start = ($page * $size) - $size;
if ($GET_option == "infoguild") {
	ShowGuildInfo($GET_guild_id);
}
// Searches for character if requested
if ($GET_search != "") {
	$search_guild = $GET_search;
	$query = "SELECT guild_id, name, master, guild_lv, connect_member, max_member, average_lv, exp
        FROM `guild`
        WHERE name LIKE '%" . $search_guild . "'";
	display_guild_table($query);
	$query = "SELECT guild_id, name, master, guild_lv, connect_member, max_member, average_lv, exp
        FROM `guild` LIMIT $start, $size";
	echo "<p>";
	display_guild_table($query);
	$display_table = true;
}
elseif ($GET_option == "deleteguild") {
	$delete_guild = GuildID_To_GuildName($GET_guild_id);
	echo "Are you sure you want to delete \"$delete_guild\"?<p>";
	echo "
	<form action=\"$PHP_SELF\" method=\"GET\">
	<input type=\"hidden\" name=\"deleteguild\" class=\"myctl\" value=\"$GET_guild_id\">
	<input type=\"submit\" name=\"delete\" class=\"myctl\" value=\"Delete\">
	</form>
        ";
}
elseif ($POST_finishedit == "Edit This Guild!") {
	$query = "UPDATE `guild`
        SET guild_id = '$POST_guild_id',
        name = '$POST_name',
        master = '$POST_master',
        guild_lv = '$POST_guild_lv',
        exp = '$POST_exp'
        WHERE guild_id = '$POST_editguild'
        ";
	$result = execute_query($query);
	add_admin_entry("Edited Guild Information for Guild ID $POST_editguild");
	redir("guild_manage.php","Guild Updated! Bringing you to Guild Management");
}
elseif ($POST_finishedit == "Edit This Castle!") {
	$query = "UPDATE `guild_castle`
        SET guild_id = '$POST_guild_id',
	economy = '$POST_economy',
	defense = '$POST_defense',
	visibleC = '$POST_visibleC',
	visibleG0 = '$POST_visibleG0',
	visibleG1 = '$POST_visibleG1',
	visibleG2 = '$POST_visibleG2',
	visibleG3 = '$POST_visibleG3',
	visibleG4 = '$POST_visibleG4',
	visibleG5 = '$POST_visibleG5',
	visibleG6 = '$POST_visibleG6',
	visibleG7 = '$POST_visibleG7'
        WHERE castle_id = '$POST_editcastle'
        ";
	$result = execute_query($query);
	add_admin_entry("Edited Castle Information for Castle $POST_editcastle");
	redir("guild_manage.php","Castle Updated! Bringing you to Guild Management");
}
elseif ($GET_delete == "Delete") {
	$delete_guild_id = $GET_guild_id;
	$delete_guild_name = GuildID_To_GuildName($delete_guild_id);
	echo "Deleting Guild " . $GET_deleteguild;
	echo "<br>";
	$query = "DELETE FROM `guild_alliance`
        WHERE guild_id = '$delete_guild_id'
        OR alliance_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Alliances Deleted!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild_castle`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Castles Cleared!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild_expulsion`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Expulsion History Cleared!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild_member`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Guild Member List Cleared!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild_position`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Guild Positions Cleared!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild_skill`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Guild Skills Cleared!";
		echo "<br>\n";
	}
	$query = "DELETE FROM `guild`
        WHERE guild_id = '$delete_guild_id'";
	$result = execute_query($query);
	if (mysql_affected_rows() > 0) {
		echo "Guild Deleted!";
		echo "<br>\n";
	}
	add_admin_entry("Deleted Guild $GET_deleteguild", "");
}
elseif ($GET_option == "editguild") {
	$query = "SELECT guild_id, name, master, guild_lv, exp
        FROM `guild` WHERE guild_id = '$GET_guild_id'";
	display_edit_table($query, $GET_guild_id);
}
elseif ($GET_option == "editcastle") {
	$query = "SELECT castle_id, guild_id, economy, defense, visibleC,
	visibleG0, visibleG1, visibleG2, visibleG3, visibleG4, visibleG5, visibleG6, visibleG7
	FROM guild_castle
	WHERE castle_id = '$GET_castle_id'
	";
	display_edit_castle($query, $GET_castle_id);
}
elseif ($GET_option == "emptycastle") {
	$query = "UPDATE `guild_castle`
	SET guild_id = 0, economy = 0, defense = 0, triggerE = 0,
	triggerD = 0, nextTime = 0, payTime = 0, createTime = 0,
	visibleC = 0, visibleG0 = 0,  visibleG1 = 0,  visibleG2 = 0, 
	visibleG3 = 0,  visibleG4 = 0,  visibleG5 = 0,  visibleG6 = 0, 
	visibleG7 = 0 WHERE castle_id = '$GET_castle_id'
	";
	$result = execute_query($query);
	add_admin_entry("Cleared Castle $GET_castle_id");
	redir("guild_manage.php","Castle Cleared! Bringing you to Guild Management");
}
else {
	$query = "SELECT guild_id, name, master, guild_lv, connect_member, max_member, average_lv, exp
        FROM `guild`
        ORDER BY `guild_id` ASC
        LIMIT $start, $size";
	display_guild_table($query);
	$display_table = true;
}

// Gets # of characters on server
$number_of_guilds = GetGuildCount();
$max_pages = intval($number_of_guilds / 30) + 1;
if ($display_table) {
	if ($max_pages > 1) {
		for ($i = 1; $i < $max_pages; $i++) {
			echo "<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>-";
		}
		echo "<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>";
	}
	echo "
	<form action=\"$PHP_SELF\" method=\"GET\">
		<table border=0 align=\"center\">
			<tr>
				<td class=\"mytext\" align=\"left\">Search: </td>
				<td><input type=\"text\" name=\"search\" class=\"myctl\"></td>
			</tr>
		</table>
		<table border=0>
			<tr>
				<td align=\"left\"><input type=\"submit\" class=\"myctl\" value=\"Search\"></td>
			</tr>
		</table>
	</form>
	";
}
require 'footer.inc';

function display_guild_table($input_query) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Guild Matching was found!";
		return;
	}
	EchoHead(100);
	echo "
	<tr class=myheader>    
		<td>Options</td>
		<td>Guild ID</td>
		<td>Guild Name</td>
		<td>Guild Master</td>
		<td>Guild Level</td>
		<td>Online Members</td>
		<td>Total Members</td>
		<td>Max Slots</td>
		<td>Average Level</td>
		<td>Total EXP</td>
	</tr>
	";
	
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>\n";
		echo "
	<td>
			<form action=\"guild_manage.php\" method=\"GET\">
				<select class=\"myctl\" name=\"option\">
					<option value=editguild>Edit
					<option value=infoguild>Information
					<option value=deleteguild>Delete
				</select>
				<input type=\"submit\" value=\"Go\" class=\"myctl\">
				<input type=\"hidden\" name=\"guild_id\" value=\"{$line[0]}\">
			</form>
	</td>
		";
		$current_row = 0;
		foreach ($line as $col_value) {
			$current_row++;
			if ($current_row == 3) {
				$col_value = "<a href=\"char_manage.php?search=" . $col_value . "\">$col_value</a>";
			}
			elseif ($current_row == 5) {
				echo "<td>$col_value</td>\n";
				$col_value = GetGuildMembers($line[0]);
			}
			echo "<td>$col_value</td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
	
	// Display Castle Status
	$query = "SELECT castle_id, guild_id, economy, defense, visibleC,
	visibleG0, visibleG1, visibleG2, visibleG3, visibleG4, visibleG5, visibleG6, visibleG7
	FROM guild_castle ORDER by castle_id";
	$result = execute_query($query);
	EchoHead(100);
	echo "
		<tr class=mytitle>
			<td colspan=14>Guild Castles</td>
		</tr>
		<tr class=myheader>
			<td>Options</td>
			<td>Castle</td>
			<td>Guild</td>
			<td>Economy</td>
			<td>Defense</td>
			<td>Kafra</td>
			<td colspan=8>Guardians</td>
	
		</tr>
	";
	if (mysql_num_rows($result) == 0) {
		echo "
		<tr class=mycell>
			<td colspan=3>No castles have been taken yet!</td>
		</tr>
	</table>";
	}
	else {
		while ($line = mysql_fetch_row($result)) {
			$display_emblem_id = $line[1];
			echo "<tr class=mycell>\n";
			echo "
			<td>
			<form action=\"guild_manage.php\" method=\"GET\">
				<select class=\"myctl\" name=\"option\">
					<option value=editcastle>Edit
					<option value=emptycastle>Empty
				</select>
				<input type=\"submit\" value=\"Go\" class=\"myctl\">
				<input type=\"hidden\" name=\"castle_id\" value=\"{$line[0]}\">
			</form>
			</td>
			";
			$display_index = 0;
			foreach ($line as $col_value) {
				$display_index++;
				if ($display_index == 1) {
					$col_value = determine_castle($col_value);
				}
				elseif ($display_index == 2) {
					if ($col_value == 0) {
						$col_value = "None";
					}
					else {
						$query2 = "SELECT name FROM guild WHERE guild_id = '$col_value'";
						$result2 = execute_query($query2);
						$line2 = mysql_fetch_array($result2);
						$col_value = $line2['name'];
					}
				}
				elseif ($display_index >= 5 and $display_index <= 13) {
					$col_value = $col_value == 1? "<font color=00ff00>On</font>" : "<font color=ff0000>Off</font>";
				}
				echo "<td>$col_value</td>\n";
			}
			echo "</tr>\n";
		}
		echo "</table>\n";
	}
	
}

function display_edit_table($input_query, $edit_guild) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Guild Matching was found!";
		return;
	}
	$line = mysql_fetch_row($result);
	$guild_id = $line[0];
	$name = $line[1];
	$master = $line[2];
	$guild_lv = $line[3];
	$exp = $line[4];
	echo "<b>Editing Guild: $edit_guild</b><p>";
	echo "
	<form action=\"guild_manage.php\" method=\"POST\">
		<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">
			<tr>
				<td>Guild ID</td>
				<td><input type=\"text\" name=\"guild_id\" class=\"myctl\" value=\"$guild_id\"></td>
			</tr>
			<tr>
				<td>Guild Name</td>
				<td><input type=\"text\" name=\"name\" class=\"myctl\" value=\"$name\"></td>
			</tr>
			<tr>
				<td>Guild Master</td>
				<td><input type=\"text\" name=\"master\" class=\"myctl\" value=\"$master\"></td>
			</tr>
			<tr>
				<td>Guild Level</td>
				<td><input type=\"text\" name=\"guild_lv\" class=\"myctl\" value=\"$guild_lv\"></td>
			</tr>
			<tr>
				<td>EXP</td>
				<td><input type=\"text\" name=\"exp\" class=\"myctl\" value=\"$exp\"></td>
			</tr>
		</table>
		<p>
		<input type=\"submit\" name=\"finishedit\" class=\"myctl\" value=\"Edit This Guild!\">
		<input type=\"hidden\" name=\"editguild\" class=\"myctl\" value=\"$edit_guild\">
	</form>
    ";
}

function display_edit_castle($input_query, $edit_castle) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Castle Matching was found!";
		return;
	}
	$line = mysql_fetch_row($result);
	echo "<b>Editing Castle: " . determine_castle($edit_castle) . "</b><p>";
	$castle_id = $line[0];
	$guild_id = $line[1];
	$economy = $line[2];
	$defense = $line[3];
	$visibleC = $line[4];
	for ($i = 0; $i < 8; $i++) {
		$visibleG[$i] = $line[5 + $i];
	}
	echo "
	<form action=\"guild_manage.php\" method=\"POST\">
		<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">
			<tr>
				<td>Guild ID</td>
				<td><input type=\"text\" name=\"guild_id\" class=\"myctl\" value=\"$guild_id\"></td>
			</tr>
	";
	echo "
			<tr>
				<td>Economy</td>
				<td><input type=\"text\" name=\"economy\" class=\"myctl\" value=\"$economy\"></td>
			</tr>
			<tr>
				<td>Defense Level</td>
				<td><input type=\"text\" name=\"defense\" class=\"myctl\" value=\"$defense\"></td>
			</tr>
			<tr>
				<td>Kafra</td>
				<td>
	";
	if ($visibleC == 0) {
		echo "
					<input type=\"radio\" name=\"visibleC\" class=\"myctl\" value=1> On
					<input type=\"radio\" name=\"visibleC\" class=\"myctl\" value=0 checked> Off
		";
	}
	else {
		echo "
					<input type=\"radio\" name=\"visibleC\" class=\"myctl\" value=1 checked> On
					<input type=\"radio\" name=\"visibleC\" class=\"myctl\" value=0> Off
		";
	}
					
	echo "
				</td>
			</tr>
	";
	
	for ($i = 0; $i < 8; $i++) {
		echo "
			<tr>
				<td>Guardian{$i}</td>
				<td>
		";
		if ($visibleG[$i] == 0) {
			echo "
			<input type=\"radio\" name=\"visibleG{$i}\" class=\"myctl\" value=1> On
			<input type=\"radio\" name=\"visibleG{$i}\" class=\"myctl\" value=0 checked> Off
			";
		}
		else {
			echo "
			<input type=\"radio\" name=\"visibleG{$i}\" class=\"myctl\" value=1 checked> On
			<input type=\"radio\" name=\"visibleG{$i}\" class=\"myctl\" value=0> Off
			";
		}
		echo "
				</td>
			</tr>
		";
	}
	echo "
		</table>
		<p>
		<input type=\"submit\" name=\"finishedit\" class=\"myctl\" value=\"Edit This Castle!\">
		<input type=\"hidden\" name=\"editcastle\" class=\"myctl\" value=\"$edit_castle\">		
	</form>
	";
}

function GetGuildMembers($guild_id) {
	$query = "SELECT * FROM `guild_member`
    	WHERE guild_id = '$guild_id'";
	$result = execute_query($query);
	return mysql_num_rows($result);
}
?>