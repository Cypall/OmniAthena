<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

// Displays Guild Ladder
$query = "SELECT name, master, guild_lv, average_lv, exp FROM guild ORDER by guild_lv DESC LIMIT $display_guild_limit";
$result = execute_query($query);
EchoHead(80);
echo "
	<tr class=mytitle>
		<td colspan=6>$server_name Guild Ladder</td>
	</tr>
	<tr class=myheader>
		<td>Emblem</td>
		<td>Guild</td>
		<td>Master</td>
		<td>Guild Level</td>
		<td>Average Level</td>
		<td>Total EXP</td>
	</tr>
";
if (mysql_num_rows($result) == 0) {
	echo "<tr class=mycell><td colspan=6>No guilds exist yet!</td></tr>";
}
else {
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$display_emblem_id = GuildName_To_GuildID($line['name']);
		echo "
		<tr class=mycell>
		";
		$emblem_location = "emblem\\$display_emblem_id.bmp";
		if (file_exists($emblem_location)) {
			echo "<td><img src=\"$emblem_location\"></td>";
		}
		else {
			echo "<td></td>";
		}
		$display_index = 0;
		foreach ($line as $col_value) {
			$display_index++;
			if ($display_index == 1) {
				$col_value = "<a href=\"guild_standings.php?guild=$display_emblem_id\">$col_value</a>";
			}
			echo "
			<td>$col_value</td>";
		}
		echo "
		</tr>";
	}
}
echo "
</table>
<p>";
// Display Castle Status
$query = "SELECT castle_id, guild_id FROM guild_castle ORDER by castle_id";
$result = execute_query($query);
EchoHead(80);
echo "
	<tr class=mytitle>
		<td colspan=3>$server_name Guild Castle Standings</td>
	</tr>
	<tr class=myheader>
		<td>Castle</td>
		<td>Guild</td>
		<td>Emblem</td>
	</tr>
";
if (mysql_num_rows($result) == 0) {
	echo "
	<tr class=mycell>
		<td colspan=3>No castles have been taken yet!</td>
	</tr>
</table>";
}
else {
	while ($line = mysql_fetch_row($result)) {
		$display_emblem_id = $line[1];
		echo "<tr class=mycell>\n";
		$display_index = 0;
		foreach ($line as $col_value) {
			$display_index++;
			if ($display_index == 1) {
				$col_value = determine_castle($col_value);
			}
			if ($display_index == 2) {
				if ($col_value == 0) {
					$col_value = "None";
				}
				else {
					$query2 = "SELECT name FROM guild WHERE guild_id = '$col_value'";
					$result2 = execute_query($query2);
					$line2 = mysql_fetch_array($result2);
					$col_value = $line2['name'];
				}
			}
			echo "<td>$col_value</td>\n";
		}
		$emblem_location = "emblem\\$display_emblem_id.bmp";
		if (file_exists($emblem_location)) {
			echo "<td><img src=\"$emblem_location\"></td>";
		}
		else {
			echo "<td></td>";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
}

if ($GET_guild != "") {
	ShowGuildInfo($GET_guild);
}
require 'footer.inc';
?>