<?php
/* 
Query Executor for users who have the mysql username/password. 
Be careful who you give this to, as there are no logs to track what is being executed.
Make sure that you only give this to whom you trust, as an entire server could get wiped
with a few commandds.
It would be helpful to watch the permissions that you give each SQL login, or better yet,
make a new SQL login that this query will use, and give it only the basic queries
(SELECT, INSERT, UPDATE, DELETE).
With that being said, enjoy this alternatve to a remote MySQL client.
*/

require 'memory.php';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

// Check that the mysql cookie is set

if (md5("1" . $passphrase) != $STORED_mysql) {
	// Cookie doesn't work, or not set
	if ($POST_login) {
		$connect = mysql_connect($db_host, $POST_login, $POST_password);
		if (!$connect) {
			redir("index.php", "Login to MySQL Database Failed!");
			add_admin_entry("Failed MySQL Login");
			exit();
		}
		setcookie('mysql', md5("1" . $passphrase), time()+86400);
		require 'header.inc';
		display_text();
	}
	else {
		// Display Login form
		require 'header.inc';
		EchoHead(80);
		echo "
			<form action=\"query.php\" method=\"POST\">
				<tr class=mytitle>
					<td>Log in to MySQL Databases:<br>Note: All Failed logins will be logged.<br></td>
				</tr>
				<tr class=mycell>
					<td>Login: <input type=\"text\" class=\"myctl\" name=\"login\"></td>
				</tr>
				<tr class=mycell>
					<td>Password: <input type=\"password\" class=\"myctl\" name=\"password\"></td>
				</tr>
				<tr>
					<td><center><input type=submit class=\"myctl\" value=\"login\"></center></td>
				</tr>
			</form>
		";
	}
}
else {
	// Valid Cookie
	require 'header.inc';
	if ($POST_query) {
		$execute_query = $POST_query;
		$result = mysql_query($execute_query);
		// Determine if query is a SELECT statement
		if (mysql_num_rows($result) > 0) {
			echo "
			<table width='100%' class=mytable cellspacing=5 cellpadding=5 align='center' style='border-collapse:collapse;'>
				<tr class=myheader>";
			while ($line = mysql_fetch_field($result)) {
				echo $line['name'];
				foreach ($line as $index => $col_value) {
					if ($index != "name") {
						continue;
					}
					echo "<td>$col_value</td>";
				}
			}
			echo "	
				</tr>";
			while ($line = mysql_fetch_row($result)) {
				// Print out columns
				echo "<tr class=mycell>";
				foreach ($line as $col_value) {
					echo "<td>$col_value</td>";
				}
				echo "</tr>";
			}
			echo "
			</table>";
			$message = "Query Successful!";
		}
		elseif (mysql_affected_rows($result) > 0) {
			$affected = mysql_affected_rows($result);
			$message = "Query Executed: ($affected rows affected)";
		}
		else {
			$message = "Illegal Query ($execute_query): " . mysql_error();
		}
		display_text($message);
	}
	else {
		display_text();
	}
}
require 'footer.inc';

function display_text($input_message = "") {
	EchoHead(80);
	echo "
		<tr class=mytitle>
			<td>Query Executor</td>
		</tr>";
	if ($input_message != "") {
		echo "
		<tr class=myheader>
			<td>$input_message</td>
		</tr>";
	}
	echo "
		<tr class=mycell>
			<td>
				You may execute queries here, please be sure to follow MySQL Syntax.
			</td>
		</tr>
		<form action=\"query.php\" method=\"POST\">
			<tr class=mycell>
				<td>
					<textarea rows=10 cols=80 name=\"query\" class=\"myctl\"></textarea>
				</td>
			</tr>
			<tr>
				<td>
					<center><input type=\"submit\" name=\"finish\" class=\"myctl\" value=\"Execute Query\"></center>
				</td>
			</tr>
		</form>
	</table>
	";
}
?>