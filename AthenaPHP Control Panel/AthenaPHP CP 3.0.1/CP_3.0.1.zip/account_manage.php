<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

// determines what page to visit if nothing is being searched
if (!$GET_page) {
	$page = 1;
}
else {
	$page = $GET_page;
}
$size = 30;
$start = ($page * $size) - $size;
// Searches for character if requested
if ($GET_search != "") {
	$search_account = $GET_search;
	$query = "SELECT account_id, userid, user_pass, sex, email, level
	FROM `login`
	WHERE userid LIKE '%" . $search_account . "%'";
	display_account_table($query);
	$query = "SELECT account_id, userid, user_pass, sex, email, level
	FROM `login` ORDER BY `account_id` ASC LIMIT $start, $size";
	echo "<p>";
	display_account_table($query);
	$display_table = true;
}
elseif ($GET_deleteaccount != "" & !$GET_delete) {
	$name_of_account = AccountID_To_UserID($GET_deleteaccount);
	echo "Are you sure you want to delete $name_of_account?<p>";
	echo "
	<form action=\"account_manage.php\" method=\"GET\">
	<input type=\"hidden\" name=\"deleteaccount\" class=\"myctl\" value=\"$name_of_account\">
	<input type=\"submit\" name=\"delete\" class=\"myctl\" value=\"Delete\">
	</form>
        ";
}
elseif ($POST_finishedit == "Edit This Account!") {
	$query = "UPDATE `login`
        SET account_id = '$POST_account_id',
        userid = '$POST_userid',
        user_pass = '$POST_user_pass',
        sex = '$POST_sex',
        email = '$POST_email',
        level = '$POST_level'
        WHERE account_id = '$POST_editaccount'
        ";
	$result = execute_query($query);
	add_admin_entry("Edited Account Information for $POST_editaccount");
	redir("account_manage.php","Account Updated! Bringing you to Account Management");
}
elseif ($GET_delete == "Delete") {
	echo "Deleting Account Information related to " . $GET_deleteaccount;
	echo "<br>";
	clear_account(UserID_To_AccountID($GET_deleteaccount));
}
elseif ($GET_editaccount != "") {
	$query = "SELECT account_id, userid, user_pass, sex, email, level
        FROM `login` WHERE account_id = '$GET_editaccount'";
	display_edit_table($query, $GET_editaccount);
}
elseif ($GET_option == "addignore") {
	$query = "INSERT INTO `ladder_ignore` VALUES ('$GET_account_id')";
	$result = execute_query($query);
	add_admin_entry("Added Account $GET_account_id to Ladder Ignored List");
	redir("account_manage.php", "Added Account $GET_account_id to Ladder Ignored List");
	exit();
}
elseif ($GET_option == "delignore") {
	$query = "DELETE FROM `ladder_ignore` WHERE account_id = '$GET_account_id'";
	$result = execute_query($query);
	add_admin_entry("Removed Account $GET_account_id to Ladder Ignored List");
	redir("account_manage.php", "Removed Account $GET_account_id to Ladder Ignored List");
	exit();
}
elseif ($GET_option == "ban") {
	display_ban(AccountID_To_UserID($GET_account_id));
	exit();
}
elseif ($GET_option == "unban") {
	display_unban(AccountID_To_UserID($GET_account_id));
	exit();
}
else {
	$query = "SELECT account_id, userid, user_pass, sex, email, level
        FROM `login`
        ORDER BY `account_id` ASC
        LIMIT $start, $size";
	display_account_table($query);
	$display_table = true;
}

// Gets # of characters on server
$number_of_accounts = GetAccountCount();
$max_pages = intval($number_of_accounts / 30) + 1;
if ($display_table) {
	for ($i = 1; $i < $max_pages; $i++) {
		echo "<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>-";
	}
	echo "
	<a href=\"$PHP_SELF?page=$i&search=$GET_search\">$i</a>
	<form action=\"$PHP_SELF\" method=\"GET\">
		<table border=0 align=\"center\">
			<tr>
				<td class=\"mytext\" align=\"left\">Search: </td>
				<td><input type=\"text\" name=\"search\" class=\"myctl\"></td>
			</tr>
		</table>
		<table border=0>
			<tr>
				<td align=\"left\"><input type=\"submit\" class=\"myctl\" value=\"Search\"></td>
			</tr>
		</table>
	</form>
	";
}
require 'footer.inc';

function display_account_table($input_query) {
	global $admin_colour, $gm_colour;
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Account Matching was found!";
		return 0;
	}
	EchoHead(80);
	echo "
	<tr class=myheader>    
		<td>Options</td>
		<td>Account ID</td>
		<td>Account Name</td>
		<td>Password</td>
		<td>Gender</td>
		<td>Email</td>
		<td>Status</td>
	</tr>
    ";
	while ($line = mysql_fetch_row($result)) {
		$account_id = $line[0];
		if (is_admin($account_id)) {
			$account_type = 'Admin';
		}
		elseif (is_gm($account_id)) {
			$account_type = 'GM';
		}
		else {
			$account_type = 'Normal';
		}
		
		echo "
	<tr class=mycell>
		";
		
		echo "
		<td>
		<form action=\"account_manage.php\" method=\"GET\">
			<select class=\"myctl\" name=\"option\">
				<option value=editaccount>Edit
				<option value=deleteaccount>Delete
				<option value=search>Items
		";
		if (is_ignored($account_id)) {
			echo "<option value=delignore>Show on Ladder";
		}
		else {
			echo "<option value=addignore>Ignore on Ladder";
		}
		if (is_banned($account_id)) {
			echo "<option value=unban>Unban";
		}
		else {
			echo "<option value=ban>Ban";
		}
		echo "
			</select>
			<input type=\"submit\" value=\"Go\" class=\"myctl\">
			<input type=\"hidden\" name=\"account_id\" value=\"{$line[0]}\">
		</form>
        	</td>
        	";
		$current_row = 0;
		foreach ($line as $col_value) {
			$current_row++;
			if ($account_type == 'Admin' OR $account_type == 'GM') {
				if ($current_row == 3) {
					if ($STORED_level == 2) {
						// Censors the password
						$col_value = '***********';
					}
				}
				elseif ($current_row == 6) {
					switch ($col_value) {
						case 0:
						$col_value = 'Active';
						break;
						case 1:
						$col_value = 'Active';
						break;
						case -1:
						$col_value = 'Banned';
						break;
					}
				}
				if ($account_type == 'Admin') {
					echo "
	<td>
		<font color=#$admin_colour>$col_value</font>
	</td>
                	";
				}
				if ($account_type == 'GM') {
					echo "
	<td>
		<font color=#$gm_colour>$col_value</font>
	</td>
                	";
				}
			}
			else {
				if ($current_row == 6) {
					switch ($col_value) {
						case 0:
						echo "<td>Active</td>\n";
						break;
						case 1:
						echo "<td>Active</td>\n";
						break;
						case -1:
						echo "<td>Banned</td>\n";
						break;
					}
					
				}
				else {
					echo "
		<td>
			$col_value
		</td>
			";
				}
			}
		}
		echo "
	</tr>
		";
	}
	echo "
</table>
    ";
}

function display_edit_table($input_query, $edit_account) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "No Account Matching was found!";
		return;
	}
	$line = mysql_fetch_row($result);
	$account_id = $line[0];
	$userid = $line[1];
	$user_pass = $line[2];
	$sex = $line[3];
	$email = $line[4];
	$level = $line[5];
	echo "
	<form action=\"account_manage.php\" method=\"POST\">
		<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">
		<tr>
			<td class=myheader colspan=2>Editing Account: $edit_account</td>
		</tr>
		<tr>
			<td>Account ID</td>
			<td><input type=\"text\" name=\"account_id\" class=\"myctl\" value=\"$account_id\"></td>
		</tr>
		<tr>
			<td>Account Name</td>
			<td><input type=\"text\" name=\"userid\" class=\"myctl\" value=\"$userid\"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type=\"text\" name=\"user_pass\" class=\"myctl\" value=\"$user_pass\"></td>
		</tr>
		<tr>
			<td>Gender</td>
			<td><input type=\"text\" name=\"sex\" class=\"myctl\" value=\"$sex\"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type=\"text\" name=\"email\" class=\"myctl\" value=\"$email\"></td>
		</tr>
		<tr>
			<td>Status</td>
			<td>
    ";
	echo "<select class=\"myctl\" name=\"level\">";
	if ($level == 0 OR $level == 1) {
		echo "<option value=\"0\" selected>Active";
		echo "<option value=\"-1\">Banned";
	}
	elseif ($level == -1) {
		echo "<option value=\"0\">Active";
		echo "<option value=\"-1\" selected>Banned";
	}
	echo "
    				</select>
			</td>
			</tr>
		</table>
		<p>
		<input type=\"submit\" name=\"finishedit\" class=\"myctl\" value=\"Edit This Account!\">
		<input type=\"hidden\" name=\"editaccount\" class=\"myctl\" value=\"$edit_account\">
	</form>
    	";
}

?>