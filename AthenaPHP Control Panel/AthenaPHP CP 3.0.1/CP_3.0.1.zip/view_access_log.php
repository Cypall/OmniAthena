<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
$query = "SELECT * FROM access_log";
$result = execute_query($query);
if (mysql_num_rows($result) == 0) {
	echo "No actions have been taken!";
}
else {
	EchoHead(80);
	echo "
	<tr class=mytitle>
		<td colspan=4>Access Log for $server_name</td>
	</tr>
	<tr class=myheader>
		<td>Action #</td>
		<td>Time/Date</td>
		<td>User</td>
		<td>Action</td>
	</tr>
        ";
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr class=mycell>\n";
		foreach ($line as $display_index => $col_value) {
			if ($display_index == 'Date') {
				$col_value = convert_date($col_value);
			}
			echo "<td>$col_value</td>\n";
		}
		echo "</tr>\n";
	}
	echo "</table>\n";
}
require 'footer.inc';
?>