<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

if (!$GET_ip) {
	$query = "SELECT * FROM register_log ORDER BY reg_time";
}
else {
	$query = "SELECT * FROM register_log WHERE ip = '$GET_ip' ORDER BY reg_time";
}

$result = execute_query($query);
if (mysql_num_rows($result) == 0) {
	echo "No actions have been taken!";
}
else {
	EchoHead(80);
	echo "
	<tr class=mytitle>
		<td colspan=3>Registration Log for $server_name</td>
	</tr>
	<tr class=myheader>
		<td>Account</td>
		<td>IP</td>
		<td>Time</td>
	</tr>
        ";
	while ($line = mysql_fetch_row($result)) {
		echo "<tr class=mycell>";
		foreach ($line as $display_index => $col_value) {
			if ($display_index == 0) {
				$col_value = "<a href=\"account_manage.php?search=$col_value\">$col_value</a>";
			}
			elseif ($display_index == 1) {
				$ip = long2ip($col_value);
				$col_value = "<a href=\"view_register_log.php?ip=$col_value\">$ip</a>";
			}
			elseif ($display_index == 2) {
				$col_value = convert_date($col_value);
			}
			echo "<td>$col_value</td>\n";
		}
		echo "</tr>";
	}
	echo "</table>\n";
}
require 'footer.inc';
?>