<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

$query = "SELECT name FROM `char`";
$result = execute_query($query);

$total_chars = mysql_num_rows($result);

EchoHead(50);

echo "
	<tr class=mytitle>
		<td colspan=2>Server Information</td>
	</tr>
	<td>
		<tr class=mycell>
			<td>Website: <a href=\"$website\">$website</a></td>
		</tr>
		<tr class=mycell>
			<td>Forums: <a href=\"$forums_location\">$forums_location</a></td>
		</tr>
		<tr class=mycell>
			<td>Patch: <a href=\"$patch_location\">$patch_location</a></td>
		</tr>
		<tr class=mycell>
			<td>IRC Channel: $irc</td>
		</tr>
	   	<tr class=mycell>
		   	<td>
		   		Total Accounts: " . GetAccountCount() . "
		   	</td>
	   	</tr>
	   	<tr class=mycell>
		   	<td>
		   		Total Characters: $total_chars
		   	</td>
	   	</tr>
		<tr class=mycell>
		   	<td>
		   		Server Rates: $exp_rate/$jexp_rate/$drop_rate
		   	</td>
	   	</tr>
		<tr class=mycell>
		   	<td>
		   		Guild Wars: $agit_start to $agit_end
		   	</td>
	   	</tr>
	</td>
	<tr class=mytitle>
		<td colspan=2>Server Rules</td>
	</tr>
	<tr class=mycell>
		<td>$server_rules</td>
	</tr>
</table>
";

$query = "SELECT class FROM `char`";
$result = execute_query($query);

for ($i = 0; $i < 4023; $i++) {
	if ($i == 24) {
		$i = 4000;
	}
	$total_class_count[$i] = 0;
}
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	foreach ($line as $col_value) {
		// Adds the peco class to the original class count
		if ($col_value == 13) {
			$col_value = 7; 
		}
		elseif ($col_value == 21) {
			$col_value = 14; 
		}
		elseif ($col_value == 4014) {
			$col_value = 4008; 
		}
		elseif ($col_value == 4022) {
			$col_value = 4015; 
		}
		$total_class_count[$col_value]++;
	}
}
echo "<p>";
echo "
<table cellspacing=0 align=\"center\">
	<td>";


for ($i = 0; $i < 4023; $i++) {
	if ($i == 13 or $i == 21 or $i == 4014 or $i == 4022) {
		continue;
	}
	if ($i == 0) {
		// First Table
		echo "
		<table class=mytable cellspacing=0>
			<tr class=\"mytitle\">
				<td>Class</td>
				<td>Amount</td>
			</tr>";
	}
	if ($i == 22) {
		// Start of second table
		echo "
		</table>
	</td>
	<td valign=top>
		<table class=mytable cellspacing=0>
			<tr class=\"mytitle\">
				<td>Class</td>
				<td>Amount</td>
			</tr>
			";
		$i = 4000;
		continue;
	}
	else {
		$currentrow++;
	}
	$col_value = determine_class($i);
	echo "
			<tr class=mycell>
				<td>$col_value</td>
				<td>{$total_class_count[$i]}</td>
			</tr>
	";
}

echo "
		</table>
	</td>
	<td valign=top>
		<table class=mytable cellspacing=0>
			<tr class=\"mytitle\">
				<td>Class</td>
				<td>Amount</td>
			</tr>
			<tr class=mycell>
				<td>Wedding</td>
				<td>{$total_class_count[22]}</td>
			</tr>
			<tr class=mycell>
				<td>Super Novice</td>
				<td>{$total_class_count[23]}</td>
			</tr>
		</table>
	</td>	
</table>
";
EchoHead(50);
echo "
	<tr class=mytitle>
		<td colspan=2>GMs of $server_name</td>
	</tr>
	<tr class=myheader>
		<td>Account Name</td>
		<td>Character Name</td>
	</tr>
";
$query = "SELECT account_id FROM `gm`";
$result = execute_query($query, "server_info.php");
while ($line = mysql_fetch_row($result)) {
	$output = "";
	$display_account_name = AccountID_To_UserID($line[0]);
	$query2 = "SELECT name FROM `char` WHERE account_id = '{$line[0]}'";
	$result2 = execute_query($query2, "server_info.php");
	echo "
	<tr class=mycell>	
		<td>{$display_account_name}</td>
	";
	while ($line2 = mysql_fetch_row($result2)) {
		$output .= $line2[0] . "<br>";
	}
	echo "
		<td>$output</td>
	</tr>
	";
}

$query = "SELECT account_id FROM `admin`";
$result = execute_query($query, "server_info.php");
while ($line = mysql_fetch_row($result)) {
	$output = "";
	$display_account_name = AccountID_To_UserID($line[0]);
	$query2 = "SELECT name FROM `char` WHERE account_id = '{$line[0]}'";
	$result2 = execute_query($query2, "server_info.php");
	echo "
	<tr class=mycell>	
		<td>{$display_account_name}</td>
	";
	while ($line2 = mysql_fetch_row($result2)) {
		$output .= $line2[0] . "<br>";
	}
	echo "
		<td>$output</td>
	</tr>
	";
}

echo "
</table>
";

require 'footer.inc';
?>