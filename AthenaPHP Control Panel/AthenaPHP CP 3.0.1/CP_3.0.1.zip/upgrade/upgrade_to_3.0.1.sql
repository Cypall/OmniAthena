CREATE TABLE `register_log` (
  `account_name` text NOT NULL,
  `ip` int(11) NOT NULL default '0',
  `reg_time` int(11) NOT NULL default '0'
) TYPE=MyISAM; 