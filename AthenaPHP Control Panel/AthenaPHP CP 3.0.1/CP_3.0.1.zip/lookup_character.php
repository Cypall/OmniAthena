<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
echo "
	<form action=\"lookup_character.php\" method=\"GET\">
		<table align=\"center\" border=\"0\">
			<tr>
				<td class=\"mytext\">Search Character:</td>
				<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"character\"></td>\n
				<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Search Character\"></td>\n
			</tr>
			<tr>
				<td class=\"mytext\">Search Character ID:</td>
				<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"characterid\" size=20></td>\n
				<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Search Character ID\"
			</tr>
		</table>
	</form>
";
if ($GET_action == "Search Character") {
	$search_character = $GET_character;
	$search_character_id = CharName_To_CharID($GET_character);
}
elseif ($GET_action == "Search Character ID") {
	$search_character = CharID_To_CharName($GET_characterid);
	$search_character_id = $GET_characterid;
}
if ($search_character != "") {
	$search_account = account_of_character($search_character);
	$search_account_id = UserID_To_AccountID($search_account);
	$account_text = "<a href='account_manage.php?search=$search_account'>$search_account</a>";
	echo "<p>\n";
	if (characters_on_account($search_account_id, 0) != "") {
		EchoHead(80);
		echo "
	<tr class=myheader>
		<td colspan=5>Account: " . $account_text . " (Account #:$search_account_id)</td>
	</tr>
	<tr class=myheader>
		<td>Character Name</td>
		<td>Character Class</td>
		<td>Base Level</td>
		<td>Job Level</td>
		<td>Zeny</td>
	</tr>
            ";
		for ($i = 0; $i < 6; $i++) {
			$char[$i] = characters_on_account($search_account_id, $i);
			if ($char[$i] != "") {
				display_character_data($char[$i]);
			}
		}
		echo "</table>\n";
	}
}
require 'footer.inc';
?>