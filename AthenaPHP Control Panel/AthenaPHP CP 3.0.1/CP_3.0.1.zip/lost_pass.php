<?php
// Doesn't work
require 'memory.php';
require 'header.inc';

if ($GET_action == "Reset My Password!") {
	$retrieve_account = $GET_retrieve_account;
	$retrieve_email = $GET_retrieve_email;
	$query = "SELECT userid, email FROM `login`
		WHERE userid = '$retrieve_account'
		AND email = '$retrieve_email'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "There were no results matching those criteria! Please check your information again.";
	}
	else {
		// Generate a random password
		$alphanum = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
		'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3',
		'4', '5', '6', '7', '8', '9');
		$seed = time();
		mt_srand($seed);
		for ($i = 1; $i <= 20; $i++) {
			$randnum = intval(mt_rand(0, 36));
			$new_password .= $alphanum[$randnum];
		}
		if ($use_md5) {
			$stored_password = md5($new_password);
		}
		else {
			$stored_password = $new_password;
		}
		// Store Encrypted Password in database
		$query = "UPDATE `login`
			SET user_pass = '$stored_password'
			WHERE userid = '$retrieve_account'";
		$result = execute_query($query);
		
		if (mysql_affected_rows() >= 0) {
			// If query was successful
			$to = $retrieve_email;
			$from = "";
			$subject = "Password Reset";
			
			$msg = <<< EOMSG
You have requested a password change for $server_name. Your new password is $new_password.
Please log into the control panel at $cp_location and change your password.

Thank you,

GMs of $server_name
EOMSG;
			// Email the original password
			mail($to, $subject, $msg);
			echo "Your new password has been sent to $to. If you do not get the password within 10 minutes,
	                please contact a gamemaster.";
		}
		else {
			echo "There was an error with your request, please contact one of the gamemasters.";
		}
	}
}
else {
	echo "
		Forgot your password? Enter your account and email, and a new one will be sent to you.<p>\n
		<form action=\"lost_pass.php\" method=\"GET\">
    		<table align=\"center\" border=\"0\">
        		<tr>
        			<td class=\"mytext\">Account Name: </td>
        			<td><input type=\"text\" class=\"myctl\" name=\"retrieve_account\" value=\"\"></td>
        	   	</tr>
        	   	<tr>
        	   	<td class=\"mytext\">Email: </td>
        	   	<td><input type=\"text\" class=\"myctl\" name=\"retrieve_email\" value=\"\"></td>
        		</tr>
    	   	</table>
    	   <input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Reset My Password!\">
	   </form>
	   ";
}
require 'footer.inc';
?>