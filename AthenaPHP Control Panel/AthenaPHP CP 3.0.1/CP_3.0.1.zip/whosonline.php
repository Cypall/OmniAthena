<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

// Checks guild war times
$time_string = date("Hi");
if ($time_string > $agit_start && $time_string < $agit_end) {
	redir("index.php", "You cannot use this page when guild wars are on!");
	exit();
}

//Who's Online
if (!$GET_map) {
	// I guess eAthena doesn't have this working after all.
	if ($athena == 0) {
		$query = "SELECT char_id, class, base_level, job_level, account_id, last_map, online FROM `char` WHERE online = '1'";	//obtains all account ids online
		EchoHead(80);
		echo "
		<tr class=mytitle>
			<td colspan=5>Users Online</td>
		</tr>
				";
		display_online($query);
	}
}
else {
	EchoHead(80);
	echo "
	<tr class=myheader>
		<td colspan=5>
			Users Online In $GET_map
		</td>
	</tr>
		";
	if (strlen($GET_map) > 15) {
		redir("index.php", "Invalid Map!");
		add_user_entry("Possible SQL injection attempt in whosonline.php");
	}
	$query = "SELECT char_id, class, base_level, job_level, account_id, last_map, online FROM `char` WHERE last_map = '$GET_map' and online = '1'";	//obtains all account ids online
	display_online($query);
}
require 'footer.inc';

function display_online($input_query) {
	$result = execute_query($input_query);
	if (mysql_num_rows($result) == 0) {
		echo "<tr class=mytext><td>None</td></tr>\n";
	}
	else {
		echo "
	<tr class=myheader>
		<td>Character Name</td>
		<td>Class</td>
		<td>Base Level</td>
		<td>Job Level</td>
		<td>Map</td>
	</tr>
		";
		while ($line = mysql_fetch_row($result)) {
			echo "
	<tr class=mycell>
			";
			for ($i = 0; $i < 7; $i++) {
				if ($i == 0) {
					$col_value = CharID_To_CharName($line[$i]);
					if (is_a_gm($col_value)) {
						echo "
						<td><b>$col_value</b></td>
                    	";
					}
					else {
						echo "
						<td>$col_value</td>";		// prints out user
					}
				}
				if ($i == 1) {
					$col_value = determine_class($line[$i]);
					echo "
						<td>$col_value</td>";
				}
				if ($i == 5) {
					echo "
					<td><a href=whosonline.php?map={$line[$i]}>{$line[$i]}</a></td>";		// prints out map
				}
				if ($i == 2 or $i == 3) {
					echo "
						<td>{$line[$i]}</td>";	
				}
			}
			echo "
	</tr>
			";
		}
		
	}
	echo "</table>";
}
?>