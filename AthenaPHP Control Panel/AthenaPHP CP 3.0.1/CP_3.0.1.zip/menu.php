<LINK HREF='style.css' TYPE=text/css REL=stylesheet>
<body bgcolor="#F9F2E8">
<?php
require 'memory.php';

$logged_in = c_logged_in();
if ($logged_in == 1)	{
	echo "
<table align=center border=0 width=100%>
	<tr class=mytext>
		<b>User Options:</b>
	</tr>
	<tr class=mytext>		
		<a target=\"home\" href=home.php> - Home</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=server_info.php> - Server Information</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=whosonline.php> - Who's Online</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=ladder.php> - Ladder</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=guild_standings.php> - Guild Standings</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=account.php> - Account Options</a>
	</tr>
			";
	$display_account_id = UserID_To_AccountID($STORED_login);
	$query = "SELECT name FROM `char` WHERE account_id = '$display_account_id' ORDER by char_num";	//searches for name of that char #
	$result = execute_query($query, 'menu.php');
	while ($line = mysql_fetch_array($result)) {
		echo "
	<tr class=mytext>
		<a target=\"home\" href=hairstyle.php?char=$i> - Edit " . $line['name'] . "'s Hairstyle</a>\n
	</tr>
			";
	}
	echo "
	<tr class=mytext>
		<a target=\"home\" href=money_transfer.php> - Transfer Money</a>\n
	</tr>
        ";
	
	for ($i = 0; $i < 4; $i++) {
		$char = CharID_To_CharName(characters_on_account(UserID_To_AccountID($STORED_login), $i));
		if ($char != "") {
			$query = "SELECT guild_id, name FROM guild WHERE master = '$char'";
			$result = execute_query($query, 'menu.php');
			$line = mysql_fetch_array($result);
			if (mysql_num_rows($result) == 1) {
				$guild_name = $line['name'];
				$guild_id = $line['guild_id'];
				echo "
	<tr class=mytext>
		<a target=\"home\" href=upload_emblem.php?guild_id=$guild_id> - Upload $guild_name Emblem</a>\n
	</tr>
					";
			}
		}
	}
	
	if ($STORED_level > 1) {
		echo "
	<br>
	<tr class=mytext>
		<b>GM/Admin Options:</b>
	</tr>
	<tr class=mytext>
        	<u>Management Tools</u>
	</tr>
		
	<tr class=mytext>
		<a target=\"home\" href=account_manage.php> - Account Management</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=char_manage.php> - Character Management</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=guild_manage.php> - Guild Management</a>
	</tr>

	<tr class=mytext>
    		<u>Ban Controls</u>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=ban.php> - Ban</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=unban.php> - Unban</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=clear_temp_banned.php> - Clear Temp Bans</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=clear_banned.php> - Clear Banned Account</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=clear_all_banned.php> - Clear All Banned Accounts</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=view_ban_list.php> - View Ban List</a>
	</tr>

	<tr class=mytext>
    		<u>GM Tools</u>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=add_announcement.php> - Add Announcement</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=edit_announcement.php> - Edit Announcement</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=add_account.php> - Add Account</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=lookup_account.php> - Account Information</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=lookup_character.php> - Character Information</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=ladder_ignore.php> - Ladder Ignored</a>
	</tr>

	<tr class=mytext>
    		<u>Admin Tools</u>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=item_search.php> - Item Search</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=clear.php> - Clear Accounts/Characters</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=backup_server.php?> - Full Server Backup</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=query.php?> - SQL Query Executor</a>
	</tr>
	<tr class=mytext>
	    	<a target=\"home\" href=gm_privilege.php?> - GM Privileges</a>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=admin_privilege.php?> - Admin Privileges</a>
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=privileges.php?> - Page Privileges</a>
	</tr>

	<tr class=mytext>
    		<u>Logs</u>
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=view_access_log.php> - View Access Logs  
	</tr> 
	<tr class=mytext>
    		<a target=\"home\" href=view_admin_log.php> - View Admin Logs
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=view_ban_log.php> - View Ban Logs
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=view_exploit_log.php> - View Exploit Logs
	</tr>
	<tr class=mytext>
		<a target=\"home\" href=view_money_log.php> - View Money Transfer Logs
	</tr>
	<tr class=mytext>
    		<a target=\"home\" href=view_user_log.php> - View User Logs
	</tr>

</table>
        	";
	}
}

?>