<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
if (!$GET_action) {
	echo "Clear an account! Enter the account name, and it will delete all data associated with it.<br>\n";
	echo "There will be a confirmation screen if you make a mistake.<br>\n";
	
	$query = "SELECT account_id FROM `login` WHERE level = '-1'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "There are no banned accounts!";
	}
	else {
		echo "The following accounts are banned:<p>\n";
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$display = $line['account_id'];
			$account_to_clear = AccountID_To_UserID($display);
			echo $account_to_clear;
			echo "<br>";
		}
		echo "<form action=\"\" method=\"GET\">";
		echo "Account Name: <input type=\"text\" class=\"myctl\" name=\"account_name\">\n";
		echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Clear Account\"><br>\n";
		echo "</form>";
	}
}
elseif ($GET_action == "Clear Account") {
	$clear_account_name = $GET_account_name;
	$query = "SELECT * FROM `login`
        WHERE userid = '$clear_account_name'
        AND level = -1
        ";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Account isn't banned!";
	}
	else {
		echo "You are going to clear $clear_account_name.<br>\n";
		echo "<form action=\"\" method=\"GET\">";
		echo "There will be no confirmation screen, be absolutely sure that you are going to clear this account.<p>\n";
		echo "<input type=\"submit\" class=\"myctl\" name=\"action\" value=\"Clear This Account!\"><br>\n";
		echo "<input type=\"hidden\" class=\"myctl\" name=\"clear_account\" value=\"$GET_account_name\"><br>\n";
		echo "</form>";
	}
}
elseif ($GET_action == "Clear This Account!") {
	$clear_account_name = $GET_clear_account;
	$query = "SELECT account_id FROM `login` WHERE userid = '$clear_account_name'";
	$result = execute_query($query);
	$line = mysql_fetch_array($result, MYSQL_ASSOC);
	$display = $line['account_id'];
	$clear_account_name = AccountID_To_UserID($display);
	echo "Deleting Information for: " . $clear_account_name . " account<br>\n";
	clear_account($display);
	$action = "Cleared all information for " . $clear_account_name;
	$misc = "None";
	add_admin_entry($action, $misc);
}
require 'footer.inc';
?>