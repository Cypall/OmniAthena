<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in

switch ($GET_viewtype) {
	case 1:
	$table = "user_announce";
	$announce_string = "User";
	break;
	case 2:
	$table = "gm_announce";
	$announce_string = "GM";
	break;
	case 3:
	$table = "admin_announce";
	$announce_string = "Admin";
	break;
}

if ($GET_viewtype > $STORED_level) {
	redir("index.php", "You cannot view these announcements!");
}
else {
	// Displays User announcement options
	EchoHead(80);
	echo "
		<tr class=mytitle>
			<td colspan=4>$announce_string Announcements</td>
		</tr>
		<tr class=myheader>
			<td>Post ID</td>
			<td>Date</td>
			<td width=50%>Message</td>
			<td>Poster</td>
		</tr>
    	";
	$query = "SELECT * FROM $table";
	$result = execute_query($query);
	while ($line = mysql_fetch_row($result)) {
		echo "
    	<tr class=mycell>
    		";
		foreach ($line as $display_index => $col_value) {
			if ($display_index == 1) {
				$col_value = convert_date($col_value);
			}
			echo "
    		<td>
    			$col_value 
    		</td>
    			";
		}
		echo "
   	</tr>
    		";
	}
	echo "
</table>
    	";
}
require 'footer.inc';
?>