<?php
// Accessed when the user goes to the home page
require 'memory.php';	// calls memory functions
require 'header.inc';	// brings in header
logged_in();  // checks if user is logged in
if ($STORED_login == 'CP') {
	redir("admin_privilege.php","Setting Up Administrator Account");
	exit();
}
else {
	echo "
<table align='center' style='border-collapse:collapse;' cellpadding='0' cellspacing='0' width='600' bgcolor='#F7EBDB'>
	<tr>
		<td class=\'mytext\' style='border-top-width:1px; border-right-width:1px; border-left-width:1px; border-top-color:rgb(231,214,192); border-right-color:rgb(231,214,192); border-left-color:rgb(231,214,192); border-top-style:dashed; border-right-style:dashed; border-left-style:dashed;'>
		</td>
	</tr>
	<tr>
		<td class=\'mytext\' style='border-right-width:1px; border-bottom-width:1px; border-left-width:1px; border-right-color:rgb(231,214,192); border-bottom-color:rgb(231,214,192); border-left-color:rgb(231,214,192); border-right-style:dashed; border-bottom-style:dashed; border-left-style:dashed;'>
			<p align='center'><font face='Verdana'><span style='font-size:8pt;'>Welcome to the Athena Control Panel, please select an option.</span></font>
		</td>
	</tr>
</table>
	"; 
	
	EchoHead(80);
	echo "
	<tr class=mytitle>
		<td colspan=3>Announcements for All Users</td>
	</tr>
	<tr class=myheader>
		<td>Poster</td>
		<td>Message</td>
		<td>Date</td>
	</tr>
        ";
	
	$BGOne = "F6E5CF"; $BGTwo = "F7EBDB";
	$CurrentBG = $BGOne;
	for ($i = 1; $i <= $max_announce; $i++) {
		$message = get_announcement("user_announce", $i, "message");
		$message2 = substr($message, 0, 50);
		
		echo "
	<tr bgcolor=$CurrentBG class=mycell>
		<td>
			" . get_announcement("user_announce", $i, "poster") . "
		</td>
		<td>
			" . get_announcement("user_announce", $i, "message") . "
		</td>
		<td>
			" . get_announcement("user_announce", $i, "date") . "
		</td>
	</tr>
		";
		if ($CurrentBG==$BGOne) { $CurrentBG=$BGTwo; } else { $CurrentBG=$BGOne; }
	}
	echo "
	<tr>
		<td colspan=3 class=mycell bgcolor='#F5E3CC'>
            		<p align='right'><a href='view_announcement.php?viewtype=1'>View More...&nbsp;</a>
		</td>
	</tr>
</table>
	";
	
	if ($STORED_level > 1) {
		EchoHead(80);
		echo "
	<tr class=mytitle>
		<td colspan=3>Announcements for All GMs</td>
	</tr>
	<tr class=myheader>
		<td>Poster</td>
		<td>Message</td>
		<td>Date</td>
	</tr>
		";
		$BGOne = "F6E5CF"; $BGTwo = "F7EBDB";
		$CurrentBG = $BGOne;
		for ($i = 1; $i <= $max_announce; $i++) {
			echo "
	<tr bgcolor=$CurrentBG class=mycell>
		<td>
			" . get_announcement("gm_announce", $i, "poster") . "
		</td>
		<td>
			" . get_announcement("gm_announce", $i, "message") . "
		</td>
		<td>
			" . get_announcement("gm_announce", $i, "date") . "
		</td>
	</tr>
			";
			if ($CurrentBG==$BGOne) { $CurrentBG=$BGTwo; } else { $CurrentBG=$BGOne; }
		}
		echo "
	<tr>
		<td colspan=3 class=mycell bgcolor='#F5E3CC'>
            		<p align='right'><a href='view_announcement.php?viewtype=2'>View More...&nbsp;</a>
		</td>
	</tr>
</table>
		";
	}
	
	if ($STORED_level > 2) {
		EchoHead(80);
		echo "
	<tr>
		<td colspan=3 class=mytitle>Announcements for All Admins</td>
	</tr>
	<tr class=myheader>
		<td>Poster</td>
		<td>Message</td>
		<td>Date</td>
	</tr>
		";
		$BGOne = "F6E5CF"; $BGTwo = "F7EBDB";
		$CurrentBG = $BGOne;
		for ($i = 1; $i <= $max_announce; $i++) {
			echo "
	<tr bgcolor=$CurrentBG class=mycell>
		<td>
			" . get_announcement("admin_announce", $i, "poster") . "
		</td>
		<td>
			" . get_announcement("admin_announce", $i, "message") . "
		</td>
		<td>
			" . get_announcement("admin_announce", $i, "date") . "
		</td>
	</tr>
			";
			if ($CurrentBG==$BGOne) { $CurrentBG=$BGTwo; } else { $CurrentBG=$BGOne; }
		}
		echo "
	<tr>
		<td colspan=3 class=mycell bgcolor='#F5E3CC'>
			<p align='right'><a href='view_announcement.php?viewtype=3'>View More...&nbsp;</a>
		</td>
	</tr>
</table>
		";
	}
	$query = "SELECT name, class, base_level, job_level, zeny FROM `char`
	    	WHERE account_id = '$account_id'";	//searches for name of that char #
	$result = execute_query($query, 'home.php');
	if (mysql_num_rows($result) == 0) {
		echo "<br>You have no characters!";
	}
	else {
		EchoHead(80);
		echo "
	<tr>
		<td colspan=5 class=mytitle>
	        	Your Characters Are:
		</td>
	</tr>
	<tr class=myheader>
        	<td>Name</td>
        	<td>Class</td>
        	<td>Base Level</td>
        	<td>Job Level</td>
        	<td>Zeny</td>
	</tr>
	        ";
		while ($line = mysql_fetch_row($result)) {
			echo "<tr class=mycell>";
			foreach ($line as $display_index => $col_value) {
				if ($display_index == 1) {
					$col_value = determine_class($col_value);
				}
				echo "<td>$col_value</td>";
			}
			echo "</tr>";
		}
	}
	EchoFoot();
}
require 'footer.inc';   // displays the header
?>