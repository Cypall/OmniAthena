<?php
require 'memory.php';
require 'header.inc';
require 'item_functions.php';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access
echo "
	<form action=\"item_manage.php\" method=\"GET\">
		<table align=\"center\" border=\"0\">
			<tr>
				<td class=\"mytext\">Search Account:</td>
				<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"account\"></td>\n
				<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"s_action\" value=\"Search Account\"></td>\n
			</tr>
			<tr>
				<td class=\"mytext\">Search Character:</td>
				<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"char\" size=20></td>\n
				<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"s_action\" value=\"Search Character\"
			</tr>
			<tr>
				<td class=\"mytext\">Search Item:</td>
				<td class=\"mytext\"><input type=\"text\" class=\"myctl\" name=\"item\" size=20></td>\n
				<td class=\"mytext\"><input type=\"submit\" class=\"myctl\" name=\"s_action\" value=\"Search Item\"
			</tr>
		</table>
	</form>
        ";
require 'footer.inc';
?>