<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

if (!$GET_action) {
	// Clear Database of banned information
	echo "This allows you to clean up banned accounts. This will delete the account, as well as anything associated with it.<br>\n";
	echo "There will be no confirmation screen.<br>\n";
	$query = "SELECT account_id FROM `login` WHERE level = '-1'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "There are no banned accounts!";
	}
	else {
		echo "The following accounts will be cleared:<p>\n";
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$display = $line['account_id'];
			$account_to_clear = AccountID_To_UserID($display);
			echo $account_to_clear;
			echo "<br>";
		}
	}
	echo "<form action=\"\" method=\"GET\">";
	echo "<input type=\"submit\" name=\"action\" class=\"myctl\" value=\"Clear Information\"><br>\n";
	echo "</form>";
}
else {
	$query = "SELECT account_id FROM `login` WHERE level = '-1'";
	$result = execute_query($query);
	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$display = $line['account_id'];
		echo "Deleting Information for Account " . AccountID_To_UserID($display) . " account<br>\n";
		clear_account($display);
		$action = "Cleared all information for " . AccountID_To_UserID($display);
		$misc = "None";
		add_admin_entry($action, $misc);
	}
}
require 'footer.inc';
?>