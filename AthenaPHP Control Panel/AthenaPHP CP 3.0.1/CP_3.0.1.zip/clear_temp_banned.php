<?php
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
check_auth($_SERVER['PHP_SELF']); // checks for required access

if (!$GET_action) {
	echo "If you have many users who are banned from hammering the server, and you wish to clear these bans, use this.";
	echo "<p>";
	$query = "SELECT * FROM `ipbanlist` WHERE reason LIKE '%Password error ban:'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "Nobody is banned for hammering the server.<br>\n";
	}
	else {
		echo "Banned for Hammering the Server<p>\n";
		echo "<table border=1 class=\"mytext\">\n";
		echo "<td>Ban ID</td>";
		echo "<td>IP</td>";
		echo "<td>Ban Time</td>";
		echo "<td>Unban Time</td>";
		echo "<td>Reason</td>";
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "<tr>\n";
			foreach ($line as $col_value) {
				echo "<td>$col_value</td>\n";
			}
			echo "</tr>\n";
		}
		echo "</table>\n";
		echo "<form action=\"\" method=\"GET\">";
		echo "<input type=\"submit\" name=\"action\" class=\"myctl\" value=\"Clear Bans\"><br>\n";
		echo "</form>";
	}
}
else {
	$query = "SELECT * FROM `ipbanlist` WHERE reason LIKE '%Password error ban:'";
	$result = execute_query($query);
	if (mysql_num_rows($result) == 0) {
		echo "There are no bans to clear!";
		add_admin_entry("Cleared Temp Bans", "");
	}
	else {
		$query = "DELETE FROM `ipbanlist` WHERE reason LIKE '%Password error ban:'";
		$result = execute_query($query);
		echo "Bans cleared!";
	}
}
require 'footer.inc';
?>