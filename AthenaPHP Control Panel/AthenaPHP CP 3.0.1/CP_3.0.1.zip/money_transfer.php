<?php
// Credits to Nucleo, most of the code is his
require 'memory.php';
require 'header.inc';
logged_in();  // checks if user is logged in
$transfer_account_id = UserID_To_AccountID($STORED_login);
$transfer = true;

// Checks that everything is okay for now

// Checks that eA is not being used
if ($athena != 0) {
	redir("index.php", "This feature does not work with eAthena at the moment.");
	$transfer = false;
}

// Check that they are offline
if (is_online($transfer_account_id)) {
	redir("index.php" ,"You must be logged off in-game to use this feature.");
	$transfer = false;
}
// Check that they have 2+ characters
elseif (CharCount($transfer_account_id) < 2) {
	redir("index.php", "You must have more than one character to transfer money");
	$transfer = false;
}
// Check that server is online
elseif (is_server_online() == false) {
	redir("index.php", "You cannot transfer money when server is offline!");
	$transfer = false;
}

if ($transfer) {
	if ($GET_step == "1") {
		$query = "SELECT * from `char` WHERE account_id = '$transfer_account_id' ORDER BY char_num";
		$result = execute_query($query);
		echo "<br>Select the character you would like to take money from.";
		echo "<br><br>";
		echo "<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">\n";
		echo "<input type=\"hidden\" name=\"charnum\" value=\"$CharNum\">";
		echo "    <tr>";
		echo "<TH><font color=#000000>Slot</TH>";
		echo "<TH><font color=#000000>Name</TH>";
		echo "<TH><font color=#000000>Class</TH>";
		echo "<TH><font color=#000000>Level</TH>";
		echo "<TH><font color=#000000>Zeny</TH>";
		echo "<TH><font color=#000000>Select</TH>";
		echo "    </tr>";
		
		while ($char_array = mysql_fetch_array($result)) {
			$GID = $char_array['char_id'];
			$charname = $char_array['name'];
			$CharNum = $char_array['char_num'];
			$class = determine_class($char_array['class']);
			$clevel = $char_array['base_level'];
			$joblevel = $char_array['job_level'];
			$money = $char_array['zeny'];
			$slot = $CharNum + 1;
			
			echo "    <tr>";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$slot</td>";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$charname</td>";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$class</td>";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$clevel/$joblevel</td>";
			echo "        <form action=\"$PHP_SELF\" method=\"GET\">";
			echo "        <input type=\"hidden\" name=\"action\" value=\"money\">";
			echo "        <input type=\"hidden\" name=\"step\" value=\"2\">";
			echo "        <input type=\"hidden\" name=\"GID1\" value=\"$GID\">";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$money</td>";
			echo "        <td bgcolor=#b6b6b6 class=\"mytext\" align=center valign=center>";
			echo "            <input type=\"submit\" value=\"Select\" class=\"myctl\">";
			echo "        </td>";
			echo "    </tr>";
			echo "    </form>";
			
		}
		echo "</table>";
	}
	elseif ($GET_step == "2") {
		$query = "SELECT * FROM `char` WHERE account_id = '$transfer_account_id' ORDER BY char_num";
		$result = execute_query($query);
		echo "<br>Select the character you would like to send money to";
		echo "<br><br>";
		echo "<table border=1 cellspacing=0 cellpadding=2 class=\"mytext\">\n";
		echo "<input type=\"hidden\" name=\"charnum\" value=\"$CharNum\">";
		echo "    <tr>";
		echo "<TH><font color=#000000>Slot</TH>";
		echo "<TH><font color=#000000>Name</TH>";
		echo "<TH><font color=#000000>Class</TH>";
		echo "<TH><font color=#000000>Level</TH>";
		echo "<TH><font color=#000000>Zeny</TH>";
		echo "<TH><font color=#000000>Select</TH>";
		echo "    </tr>";
		while ($char_array = mysql_fetch_array($result)) {
			$GID = $char_array['char_id'];
			$charname = $char_array['name'];
			$CharNum = $char_array['char_num'];
			$class = determine_class($char_array['class']);
			$clevel = $char_array['base_level'];
			$joblevel = $char_array['job_level'];
			$money = $char_array['zeny'];
			$slot = $CharNum + 1;
			
			if ($GID != $GET_GID1) {
				echo "
                        <tr>
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$slot</td>
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$charname</td>
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$class</td>
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$clevel/$joblevel</td>

                            <form action=\"$PHP_SELF\" method=\"GET\">
                            <input type=\"hidden\" name=\"action\" value=\"money\">
                            <input type=\"hidden\" name=\"step\" value=\"3\">
                            <input type=\"hidden\" name=\"GID1\" value=\"$GET_GID1\">
                            <input type=\"hidden\" name=\"GID2\" value=\"$GID\">
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center>$money</td>
                            <td bgcolor=#b6b6b6 class=\"mytext\" align=center valign=center>
                                <input type=\"submit\" value=\"Select\" class=\"myctl\">
                            </td>
                        </tr>
                        </form>
                    ";
			}
		}
		echo "</table>";
	}
	elseif ($GET_step == "3") {
		$char1 = CharID_To_CharName($GET_GID1);
		$char2 = CharID_To_CharName($GET_GID2);
		$money1 = MoneyOnChar($GET_GID1);
		$money2 = MoneyOnChar($GET_GID2);
		
		echo "<br>Please enter the the amount of money you wish to transfer<br>";
		echo "<br>You are transfering money from <b>$char1</b> to <b>$char2</b><br>";
		echo "There is $money1 zeny on $char1, and $money2 zeny on $char2<br>";
		echo "<br><form action=\"$PHP_SELF\">";
		echo "    <input type=\"hidden\" name=\"action\" value=\"money\">";
		echo "    <input type=\"hidden\" name=\"step\" value=\"4\">";
		echo "    <input type=\"hidden\" name=\"GID1\" value=\"$GET_GID1\">";
		echo "    <input type=\"hidden\" name=\"GID2\" value=\"$GET_GID2\">";
		echo "    <input type=\"text\" name=\"amount\" value=\"0\" class=\"myctl\" size=\"10\"><br><br>";
		echo "    <input type=\"submit\" value=\"Send Money\" class=\"myctl\">";
		echo "</form>";
	}
	elseif ($GET_step == "4") {
		$char1 = CharID_To_CharName($GET_GID1);	// Gets Character Name
		$char2 = CharID_To_CharName($GET_GID2);
		$acc1 = UserID_To_AccountID(account_of_character($char1));
		$acc2 = UserID_To_AccountID(account_of_character($char2));
		if ($acc1 != $acc2) {
			// User has tried to steal from an account that isn't theirs!
			redir("index.php","Cannot trade with a character that is not yours!");
			add_exploit_entry("Tried to steal zeny from another account!");
		}
		if (CharName_To_CharID($char1) == 0 OR CharName_To_CharID($char2) == 0) {
			redir("index.php", "Character(s) involved in the transaction do not exist! Please try again.");
			add_exploit_entry("Tried to transfer with non-existent character");
		}
		else {
			$money1 = MoneyOnChar($GET_GID1); // money to be taken
			$money2 = MoneyOnChar($GET_GID2); // money to be given
			
			if ($GET_amount >= $money1) {
				redir("index.php", "You do not have enough money on $char1!");
				add_exploit_entry("Tried to transfer more than they owned");
			}
			elseif (LevelOfChar($GET_GID1) < $minimum_transfer) {
				redir("index.php", "$char1 must be level $minimum_transfer or above to transfer zeny!");
			}
			else {
				if (strlen($GET_GID1) > 10 OR strlen($GET_GID2) > 10) {
					redir("index.php", "Invalid character ID(s)!");
					add_exploit_entry('Possible SQL injection attempt in money_transfer.php');
				}
				if ($GET_amount > 1) {
					if (strlen($GET_amount) > 7) {
						redir("index.php", "Invalid transfer amount!");
						add_exploit_entry('Possible SQL injection attempt in money_transfer.php');
					}
					$money1 = $money1 - $GET_amount;
					$money2 = $money2 + $GET_amount;
					$query = "UPDATE `char` SET zeny = '$money1' WHERE char_id = '$GET_GID1'";
					$result = execute_query($query);
					$query = "UPDATE `char` SET zeny = '$money2' WHERE char_id = '$GET_GID2'";
					$result = execute_query($query);
					redir("index.php", "$GET_amount zeny has been transfered from $char1 to $char2");
					add_money_entry($GET_GID1, $GET_GID2, "Transferred $GET_amount zeny");
				}
				else {
					redir("index.php", "You can't transfer $GET_amount zeny!");
					add_exploit_entry("Tried to transfer less than 1 zeny");
				}
			}
		}
	}
}


require 'footer.inc';

function MoneyOnChar($input_char_id) {
	$query = "SELECT zeny FROM `char` WHERE char_id = '$input_char_id'";
	$result = execute_query($query);
	$char_array = mysql_fetch_array($result);
	return $char_array['zeny'];
}

function LevelOfChar($input_char_id) {
	$query = "SELECT base_level FROM `char` WHERE char_id = '$input_char_id'";
	$result = execute_query($query);
	$char_array = mysql_fetch_array($result);
	return $char_array['base_level'];
}
?>