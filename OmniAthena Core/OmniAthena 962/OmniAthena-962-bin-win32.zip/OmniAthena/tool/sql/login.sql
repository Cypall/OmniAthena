# --------------------------------------------------------
# This file is under BSD License.
# Encoded in UTF-8
# --------------------------------------------------------
#
# athena login server - SQL dump
# - by Jioh L. Jung (ziozzang@4wish.net)
#
# database : `ragnarok`
# 
# --------------------------------------------------------
#
# = User Level =
#
# user level is ban and GM check.
# -1 : banned
# 0 : normal
# 1 or more : GM level
#
# you can handle bad user and unknown user by this flag.
# set your server sign up page default as '-1'
# that protect your server secure from bad guyz.
#
# = Login data format =
#
# login date data format
# use now() function to update lastlogin time
# and send client time as 
# sprintf("%s.%d3" , lastlogin , rand(0.999))
#
# = Password protection =
#
# and md5 is no need when you use mysql.
# cause password() and md5() functions are in mysql.
#
# = About E-mail =
#
# e-mail can be used for many purpose.
#
# = Add account =
#
# Athena-db does not support dynamic account add via
# login-server. you can add account direct to mysql.
# it's more safe and more stable, even if your server
# be a bigger one.
#
# and you can change password.
#
# * basic login server works well - but login server does not work on account making,deleting, modifing.
#   use PHP script with mysql.
# * connection log with mysql.
# * ip base ban.
#
# It's good idea to run with login server on *NIX. anyway nowadays, login server works well and stable.
# so PHP + WEB is good idea to manage login server.
#
# blah blah. sorry for my bad english. :P
#
# --------------------------------------------------------
#
# Table structure `ipbanlist`
#

CREATE TABLE `ipbanlist` (
  `list` varchar(255) NOT NULL default '',
  `btime` datetime NOT NULL default '0000-00-00 00:00:00',
  `rtime` datetime NOT NULL default '0000-00-00 00:00:00',
  `reason` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure `login`
#

CREATE TABLE `login` (
  `account_id` int(10) unsigned NOT NULL auto_increment,
  `userid` varchar(24) NOT NULL default '',
  `user_pass` varchar(24) NOT NULL default '000000',
  `lastlogin` datetime NOT NULL default '0000-00-00 00:00:00',
  `sex` char(1) NOT NULL default 'M',
  `logincount` mediumint(9) NOT NULL default '0',
  `email` varchar(100) NOT NULL default 'user@athena',
  `level` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`account_id`),
  KEY `userid` (`userid`)
) TYPE=MyISAM AUTO_INCREMENT=1000057 ;

# --------------------------------------------------------

#
# Table structure `loginlog`
#

CREATE TABLE `loginlog` (
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ip` varchar(64) NOT NULL default '',
  `user` varchar(32) NOT NULL default '',
  `rcode` tinyint(4) NOT NULL default '0',
  `log` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure `ragsrvinfo`
#

CREATE TABLE `ragsrvinfo` (
  `index` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `exp` int(11) NOT NULL default '0',
  `jexp` int(11) NOT NULL default '0',
  `drop` int(11) NOT NULL default '0',
  `type` tinyint(4) NOT NULL default '0',
  `text1` varchar(255) NOT NULL default '',
  `text2` varchar(255) NOT NULL default '',
  `text3` varchar(255) NOT NULL default '',
  `text4` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure `sstatus`
#

CREATE TABLE `sstatus` (
  `index` tinyint(4) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `user` int(11) NOT NULL default '0'
) TYPE=MyISAM;
    