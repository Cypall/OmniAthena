# Upgrade file for mysql021

# Clear old info, if you are using mysql021, no need to run this part
# --------------------------------------------------------------
DROP TABLE `charlog`;
DROP TABLE `interlog`;
DROP TABLE `guild_storage`;
ALTER TABLE `global_reg_value` DROP COLUMN `type`;
ALTER TABLE `global_reg_value` DROP COLUMN `account_id`;

# --------------------------------------------------------------
# Fix the bug that some fields cannot exceed 127
ALTER TABLE `char` MODIFY `str` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `agi` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `vit` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `int` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `dex` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `luk` TINYINT(4) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `base_level` TINYINT(4) unsigned NOT NULL default '1';
ALTER TABLE `char` MODIFY `job_level` TINYINT(4) unsigned NOT NULL default '1';

# --------------------------------------------------------------------
# Bug fix : wrong index
ALTER TABLE `storage` DROP INDEX `char_id`, ADD INDEX (`account_id`);

# ----------------------------------------------------------------
# Add log tables


# Table: `charlog`
#
CREATE TABLE `charlog` (
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `char_msg` varchar(255) NOT NULL default 'char select',
  `account_id` int(11) NOT NULL default '0',
  `char_num` tinyint(4) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `str` tinyint(4) NOT NULL default '0',
  `agi` tinyint(4) NOT NULL default '0',
  `vit` tinyint(4) NOT NULL default '0',
  `int` tinyint(4) NOT NULL default '0',
  `dex` tinyint(4) NOT NULL default '0',
  `luk` tinyint(4) NOT NULL default '0',
  `hair` tinyint(4) NOT NULL default '0',
  `hair_color` int(11) NOT NULL default '0'
) TYPE=MyISAM;

# Table: 'interlog'
# 
CREATE TABLE `interlog` (
  `time` datetime NOT NULL default '0000-00-00 00:00:00',
  `log` varchar(255) NOT NULL default ''
) TYPE=MyISAM; 

# ----------------------------------------------------------
# Add new table guild_storage


# Table: 'guild_storage'
# 
CREATE TABLE `guild_storage` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `guild_id` int(11) NOT NULL default '0',
  `nameid` int(11) NOT NULL default '0',
  `amount` int(11) NOT NULL default '0',
  `equip` mediumint(8) unsigned NOT NULL default '0',
  `identify` smallint(6) NOT NULL default '0',
  `refine` tinyint(3) unsigned NOT NULL default '0',
  `attribute` tinyint(4) NOT NULL default '0',
  `card0` int(11) NOT NULL default '0',
  `card1` int(11) NOT NULL default '0',
  `card2` int(11) NOT NULL default '0',
  `card3` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `guild_id` (`guild_id`)
) TYPE=MyISAM; 

# -------------------------------------------------------------------
# Change global_reg_value table
# type = 1   account_reg for all connected map-server ( like Chaos Loki Sakary )
# type = 2   account_reg for current map-server
# type = 3   char_reg for current map-server

ALTER TABLE `global_reg_value` ADD `type` int(11) NOT NULL default '3';
ALTER TABLE `global_reg_value` ADD `account_id` int(11) NOT NULL default '0', ADD INDEX (`account_id`);


