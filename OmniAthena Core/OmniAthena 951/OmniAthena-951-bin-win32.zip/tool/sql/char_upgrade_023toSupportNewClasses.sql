# Upgrade file for mysql023 to support new classes and such

# --------------------------------------------------------------
# Make table able to handle the new classes
ALTER TABLE `char` MODIFY `class` int(11) unsigned NOT NULL;
# --------------------------------------------------------------
# Fix the bug that some fields cannot exceed 255
ALTER TABLE `char` MODIFY `str` int(11) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `agi` int(11) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `vit` int(11) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `int` int(11) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `dex` int(11) unsigned NOT NULL;
ALTER TABLE `char` MODIFY `luk` int(11) unsigned NOT NULL;

